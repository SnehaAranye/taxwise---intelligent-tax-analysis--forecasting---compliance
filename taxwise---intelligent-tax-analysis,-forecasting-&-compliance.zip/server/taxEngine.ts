import { TaxCalculation, DeductionItem, TaxConfiguration } from './types';

export const DEFAULT_TAX_CONFIG: TaxConfiguration = {
  corporateTaxRate: 22.0, // Section 115BAA baseline rate
  surchargeRate: 10.0, // 10% surcharge on base corporate tax
  cessRate: 4.0, // 4% Health & Education Cess
  matRate: 15.0, // Minimum Alternate Tax rate (if applicable under 115JB)
  financialYear: 'FY 2026-27',
  deductionRules: [
    {
      section: 'Section 80JJAA',
      title: 'Employment Generation Deduction',
      maxLimit: 30000000,
      description: '30% additional deduction on emoluments paid to new qualifying employees for 3 assessment years.',
    },
    {
      section: 'Section 35(2AB)',
      title: 'In-house Scientific R&D Deduction',
      maxLimit: 50000000,
      description: 'Weighted deduction for capital and revenue expenditure incurred on approved scientific research.',
    },
    {
      section: 'Section 32(1)(iia)',
      title: 'Additional Depreciation',
      maxLimit: 20000000,
      description: '20% additional depreciation allowance on new plant and machinery installed during the fiscal year.',
    },
    {
      section: 'Section 80G',
      title: 'CSR & Approved Donations',
      maxLimit: 10000000,
      description: '50% to 100% deduction on qualifying charitable donations and eligible relief funds.',
    },
  ],
  lastUpdated: '2026-09-15',
};

export function calculateTax(
  params: {
    companyId: string;
    financialYear: string;
    revenue: number;
    operatingExpenses: number;
    employeeExpenses: number;
    depreciation: number;
    otherExpenses: number;
    deductions: DeductionItem[];
    advanceTaxPaid?: number;
    tdsCredit?: number;
    matCreditUtilized?: number;
    customBaseTaxRate?: number;
    customSurchargeRate?: number;
    customCessRate?: number;
    notes?: string;
  },
  config: TaxConfiguration = DEFAULT_TAX_CONFIG
): TaxCalculation {
  const {
    companyId,
    financialYear,
    revenue = 0,
    operatingExpenses = 0,
    employeeExpenses = 0,
    depreciation = 0,
    otherExpenses = 0,
    deductions = [],
    advanceTaxPaid = 0,
    tdsCredit = 0,
    matCreditUtilized = 0,
    customBaseTaxRate,
    customSurchargeRate,
    customCessRate,
    notes,
  } = params;

  const totalExpenses =
    operatingExpenses + employeeExpenses + depreciation + otherExpenses;
  const profitBeforeTax = Math.max(0, revenue - totalExpenses);

  const totalDeductions = deductions.reduce(
    (acc, item) => acc + (Number(item.amount) || 0),
    0
  );
  const taxableIncome = Math.max(0, profitBeforeTax - totalDeductions);

  const baseRate = customBaseTaxRate ?? config.corporateTaxRate;
  const surchargeRate = customSurchargeRate ?? config.surchargeRate;
  const cessRate = customCessRate ?? config.cessRate;

  // Statutory effective rate computation: Base * (1 + Surcharge%) * (1 + Cess%)
  // e.g. 22% * 1.10 = 24.2%; 24.2% * 1.04 = 25.168% (~25.17%)
  const rateWithSurcharge = baseRate * (1 + surchargeRate / 100);
  const effectiveStatutoryRate = rateWithSurcharge * (1 + cessRate / 100);

  const grossTax = taxableIncome * (effectiveStatutoryRate / 100);

  const totalTaxCredits = advanceTaxPaid + tdsCredit + matCreditUtilized;
  const estimatedTaxPayable = Math.max(0, grossTax - totalTaxCredits);

  const effectiveTaxRate =
    profitBeforeTax > 0 ? (grossTax / profitBeforeTax) * 100 : 0;
  const netProfitAfterTax = profitBeforeTax - grossTax;

  return {
    id: `calc_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    companyId,
    financialYear,
    calculationDate: new Date().toISOString(),
    revenue,
    operatingExpenses,
    employeeExpenses,
    depreciation,
    otherExpenses,
    totalExpenses,
    profitBeforeTax,
    deductions,
    totalDeductions,
    taxableIncome,
    taxRate: Number(effectiveStatutoryRate.toFixed(2)),
    surcharge: Number((taxableIncome * (baseRate / 100) * (surchargeRate / 100)).toFixed(2)),
    cess: Number(
      (
        (taxableIncome * (baseRate / 100) +
          taxableIncome * (baseRate / 100) * (surchargeRate / 100)) *
        (cessRate / 100)
      ).toFixed(2)
    ),
    grossTax: Number(grossTax.toFixed(2)),
    taxCredits: Number(totalTaxCredits.toFixed(2)),
    advanceTaxPaid,
    tdsCredit,
    matCreditUtilized,
    estimatedTaxPayable: Number(estimatedTaxPayable.toFixed(2)),
    effectiveTaxRate: Number(effectiveTaxRate.toFixed(2)),
    netProfitAfterTax: Number(netProfitAfterTax.toFixed(2)),
    notes: notes || 'Standard corporate assessment under Section 115BAA with statutory surcharge and cess.',
  };
}

export function computeTaxEfficiency(
  revenue: number,
  profitBeforeTax: number,
  grossTax: number,
  deductions: number,
  complianceCost: number = 850000
) {
  const effectiveTaxRate = profitBeforeTax > 0 ? (grossTax / profitBeforeTax) * 100 : 0;
  const taxToRevenue = revenue > 0 ? (grossTax / revenue) * 100 : 0;
  const taxToProfit = profitBeforeTax > 0 ? (grossTax / profitBeforeTax) * 100 : 0;
  const netProfitAfterTax = profitBeforeTax - grossTax;

  // Potential allowable optimization through Section 80JJAA employment incentives,
  // Section 35 R&D spend, and accelerated capital allowances.
  const identifiedOpportunities = [
    {
      title: 'Section 80JJAA New Workforce Incentive',
      potentialSavings: 1250000,
      description: '30% additional deduction on qualifying software engineer salaries added during FY2026-27.',
      horizon: 'Short-Term' as const,
      feasibility: 'High' as const,
      riskLevel: 'Low' as const,
    },
    {
      title: 'Capital Expenditure vs Lease Restructuring',
      potentialSavings: 860000,
      description: 'Optimizing IT hardware capital asset depreciation at 40% vs operating lease charges.',
      horizon: 'Short-Term' as const,
      feasibility: 'High' as const,
      riskLevel: 'Low' as const,
    },
    {
      title: 'Section 35 In-house R&D Tech Infrastructure Allowance',
      potentialSavings: 1840000,
      description: 'Substantiating technical architecture R&D expenses under DSIR recognized R&D center guidelines.',
      horizon: 'Long-Term' as const,
      feasibility: 'Medium' as const,
      riskLevel: 'Medium' as const,
    },
    {
      title: 'Cross-Border TDS Treaty Benefit Re-Assessment',
      potentialSavings: 550000,
      description: 'Applying DTAA Article 12 lower withholding rate (10% vs 20%) on overseas cloud licensing.',
      horizon: 'Short-Term' as const,
      feasibility: 'High' as const,
      riskLevel: 'Low' as const,
    },
  ];

  const totalOpportunitySavings = identifiedOpportunities.reduce(
    (sum, item) => sum + item.potentialSavings,
    0
  );

  const improvedGrossTax = Math.max(0, grossTax - totalOpportunitySavings);
  const improvedEffectiveTaxRate =
    profitBeforeTax > 0 ? (improvedGrossTax / profitBeforeTax) * 100 : 0;
  const improvedNPAT = profitBeforeTax - improvedGrossTax;

  return {
    effectiveTaxRate: Number(effectiveTaxRate.toFixed(2)),
    taxToRevenueRatio: Number(taxToRevenue.toFixed(2)),
    taxToProfitRatio: Number(taxToProfit.toFixed(2)),
    complianceCost,
    taxSavingsOpportunity: totalOpportunitySavings,
    netProfitAfterTax: Number(netProfitAfterTax.toFixed(2)),
    currentPractice: {
      effectiveTaxRate: Number(effectiveTaxRate.toFixed(2)),
      grossTax: Number(grossTax.toFixed(2)),
      npat: Number(netProfitAfterTax.toFixed(2)),
    },
    improvedPractice: {
      effectiveTaxRate: Number(improvedEffectiveTaxRate.toFixed(2)),
      grossTax: Number(improvedGrossTax.toFixed(2)),
      npat: Number(improvedNPAT.toFixed(2)),
    },
    opportunities: identifiedOpportunities,
    disclaimer:
      'Results are analytical estimates based on configured statutory assumptions and should not be treated as formal legal or tax counsel.',
  };
}
