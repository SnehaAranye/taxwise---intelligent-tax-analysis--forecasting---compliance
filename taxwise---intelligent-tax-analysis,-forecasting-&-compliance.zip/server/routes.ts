import { Router, Request, Response } from 'express';
import { store } from './store';
import { calculateTax, computeTaxEfficiency } from './taxEngine';
import { runTaxForecast } from './forecastEngine';

export const apiRouter = Router();

// ==================== AUTHENTICATION ====================

apiRouter.post('/auth/login', (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required.' });
    }

    const user = store.findUserByEmail(email);
    if (!user || !store.verifyPassword(user, password)) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    const { passwordHash, ...userSafe } = user;
    return res.json({
      user: userSafe,
      token: `token_${user.id}_${Date.now()}`,
      message: 'Logged in successfully.',
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Internal server error.' });
  }
});

apiRouter.post('/auth/register', (req: Request, res: Response) => {
  try {
    const { name, email, password, role } = req.body;
    if (!name || !email || !password) {
      return res.status(400).json({ error: 'Name, email, and password are required.' });
    }

    if (password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters long.' });
    }

    const newUser = store.createUser({ name, email, password, role });
    const { passwordHash, ...userSafe } = newUser;
    return res.status(201).json({
      user: userSafe,
      token: `token_${newUser.id}_${Date.now()}`,
      message: 'Account registered successfully.',
    });
  } catch (err: any) {
    return res.status(400).json({ error: err.message || 'Registration failed.' });
  }
});

apiRouter.post('/auth/logout', (_req: Request, res: Response) => {
  return res.json({ message: 'Logged out successfully.' });
});

apiRouter.get('/auth/me', (req: Request, res: Response) => {
  // Returns demo user by default or token-matched user
  const user = store.findUserByEmail('analyst@taxwise.io');
  if (!user) return res.status(404).json({ error: 'User not found.' });
  const { passwordHash, ...userSafe } = user;
  return res.json({ user: userSafe });
});

// ==================== COMPANIES ====================

apiRouter.get('/companies', (_req: Request, res: Response) => {
  const companies = store.getCompanies();
  return res.json(companies);
});

apiRouter.get('/companies/:id', (req: Request, res: Response) => {
  const comp = store.getCompany(req.params.id);
  if (!comp) return res.status(404).json({ error: 'Company not found.' });
  return res.json(comp);
});

apiRouter.post('/companies', (req: Request, res: Response) => {
  try {
    const { name, industry, businessType, pan, gstin, state, city, financialYear, revenue, expenses, baseTaxRate } = req.body;
    if (!name || !pan || !gstin) {
      return res.status(400).json({ error: 'Company Name, PAN, and GSTIN are required.' });
    }

    const newCompany = store.createCompany({
      name,
      industry: industry || 'Technology & Financial Services',
      businessType: businessType || 'Private Limited',
      pan: pan.toUpperCase(),
      gstin: gstin.toUpperCase(),
      state: state || 'Maharashtra',
      city: city || 'Mumbai',
      financialYear: financialYear || 'FY 2026-27',
      revenue: Number(revenue) || 0,
      expenses: Number(expenses) || 0,
      baseTaxRate: Number(baseTaxRate) || 25.17,
      isDemo: false,
    });
    return res.status(201).json(newCompany);
  } catch (err: any) {
    return res.status(400).json({ error: err.message });
  }
});

apiRouter.put('/companies/:id', (req: Request, res: Response) => {
  try {
    const updated = store.updateCompany(req.params.id, req.body);
    return res.json(updated);
  } catch (err: any) {
    return res.status(404).json({ error: err.message });
  }
});

apiRouter.delete('/companies/:id', (req: Request, res: Response) => {
  const ok = store.deleteCompany(req.params.id);
  if (!ok) return res.status(404).json({ error: 'Company not found or cannot be deleted.' });
  return res.json({ message: 'Company removed successfully.' });
});

// ==================== DASHBOARD STATS ====================

apiRouter.get('/dashboard/stats', (req: Request, res: Response) => {
  try {
    const companyId = (req.query.companyId as string) || 'comp_apex_tech';
    const fy = req.query.fy as string;
    const stats = store.getDashboardStats(companyId, fy);
    return res.json(stats);
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// ==================== TRANSACTIONS ====================

apiRouter.get('/transactions', (req: Request, res: Response) => {
  const companyId = (req.query.companyId as string) || 'comp_apex_tech';
  const search = req.query.search as string;
  const category = req.query.category as string;
  const type = req.query.type as string;
  const page = parseInt(req.query.page as string) || 1;
  const limit = parseInt(req.query.limit as string) || 10;

  const result = store.getTransactions({ companyId, search, category, type, page, limit });
  return res.json(result);
});

apiRouter.post('/transactions', (req: Request, res: Response) => {
  try {
    const { companyId, date, description, category, type, amount, taxCategory, taxAmount, paymentStatus, referenceNo } = req.body;
    if (!description || !amount || !category) {
      return res.status(400).json({ error: 'Description, Category, and Amount are required.' });
    }

    if (Number(amount) <= 0) {
      return res.status(400).json({ error: 'Amount must be greater than zero.' });
    }

    const tx = store.createTransaction({
      companyId: companyId || 'comp_apex_tech',
      date: date || new Date().toISOString().substring(0, 10),
      description,
      category,
      type: type || 'debit',
      amount: Number(amount),
      taxCategory: taxCategory || 'GST 18%',
      taxAmount: Number(taxAmount) || 0,
      paymentStatus: paymentStatus || 'Paid',
      referenceNo: referenceNo || `TX-${Date.now().toString().slice(-6)}`,
    });
    return res.status(201).json(tx);
  } catch (err: any) {
    return res.status(400).json({ error: err.message });
  }
});

apiRouter.put('/transactions/:id', (req: Request, res: Response) => {
  try {
    const updated = store.updateTransaction(req.params.id, req.body);
    return res.json(updated);
  } catch (err: any) {
    return res.status(404).json({ error: err.message });
  }
});

apiRouter.delete('/transactions/:id', (req: Request, res: Response) => {
  const ok = store.deleteTransaction(req.params.id);
  if (!ok) return res.status(404).json({ error: 'Transaction not found.' });
  return res.json({ message: 'Transaction deleted successfully.' });
});

// ==================== TAX CALCULATOR ====================

apiRouter.post('/tax/calculate', (req: Request, res: Response) => {
  try {
    const {
      companyId = 'comp_apex_tech',
      financialYear = 'FY 2026-27',
      revenue,
      operatingExpenses,
      employeeExpenses,
      depreciation,
      otherExpenses,
      deductions = [],
      advanceTaxPaid,
      tdsCredit,
      matCreditUtilized,
      customBaseTaxRate,
      notes,
    } = req.body;

    if (revenue === undefined || revenue < 0) {
      return res.status(400).json({ error: 'Revenue must be greater than or equal to 0.' });
    }

    const config = store.getTaxConfig();
    const result = calculateTax(
      {
        companyId,
        financialYear,
        revenue: Number(revenue) || 0,
        operatingExpenses: Number(operatingExpenses) || 0,
        employeeExpenses: Number(employeeExpenses) || 0,
        depreciation: Number(depreciation) || 0,
        otherExpenses: Number(otherExpenses) || 0,
        deductions,
        advanceTaxPaid: Number(advanceTaxPaid) || 0,
        tdsCredit: Number(tdsCredit) || 0,
        matCreditUtilized: Number(matCreditUtilized) || 0,
        customBaseTaxRate: customBaseTaxRate ? Number(customBaseTaxRate) : undefined,
        notes,
      },
      config
    );

    // Save calculation into memory history
    store.saveTaxCalculation(result);

    return res.json(result);
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

apiRouter.get('/tax/calculations', (req: Request, res: Response) => {
  const companyId = (req.query.companyId as string) || 'comp_apex_tech';
  const calcs = store.getTaxCalculations(companyId);
  return res.json(calcs);
});

apiRouter.delete('/tax/calculations/:id', (req: Request, res: Response) => {
  const ok = store.deleteTaxCalculation(req.params.id);
  if (!ok) return res.status(404).json({ error: 'Calculation not found.' });
  return res.json({ message: 'Calculation deleted.' });
});

// ==================== TAX SCENARIOS (PLANNING) ====================

apiRouter.get('/tax/scenarios', (req: Request, res: Response) => {
  const companyId = (req.query.companyId as string) || 'comp_apex_tech';
  const scenarios = store.getTaxScenarios(companyId);
  return res.json(scenarios);
});

apiRouter.post('/tax/scenarios', (req: Request, res: Response) => {
  try {
    const {
      companyId = 'comp_apex_tech',
      name,
      description,
      revenue,
      expenses,
      depreciation = 0,
      deductions = 0,
      taxCredits = 0,
      taxRate = 25.17,
      assumptions = [],
      isOptimized = false,
    } = req.body;

    if (!name || revenue === undefined || expenses === undefined) {
      return res.status(400).json({ error: 'Scenario Name, Revenue, and Expenses are required.' });
    }

    const revNum = Number(revenue);
    const expNum = Number(expenses);
    const dedNum = Number(deductions);
    const credNum = Number(taxCredits);
    const rateNum = Number(taxRate);

    const taxableIncome = Math.max(0, revNum - expNum - dedNum);
    const grossTax = taxableIncome * (rateNum / 100);
    const estimatedTax = Math.max(0, grossTax - credNum);
    const pbt = Math.max(0, revNum - expNum);
    const effectiveTaxRate = pbt > 0 ? (grossTax / pbt) * 100 : 0;
    const netProfitAfterTax = pbt - grossTax;

    // Check baseline comparison
    const baseline = store.getTaxScenarios(companyId).find((s) => !s.isOptimized) || { estimatedTax };
    const taxSavingsVsBaseline = Math.max(0, baseline.estimatedTax - estimatedTax);

    const newScenario = store.createTaxScenario({
      companyId,
      name,
      description: description || 'Alternative tax operational modeling.',
      revenue: revNum,
      expenses: expNum,
      depreciation: Number(depreciation),
      deductions: dedNum,
      taxCredits: credNum,
      taxRate: rateNum,
      taxableIncome,
      estimatedTax: Number(estimatedTax.toFixed(2)),
      effectiveTaxRate: Number(effectiveTaxRate.toFixed(2)),
      netProfitAfterTax: Number(netProfitAfterTax.toFixed(2)),
      taxSavingsVsBaseline: Number(taxSavingsVsBaseline.toFixed(2)),
      isOptimized: Boolean(isOptimized),
      assumptions,
    });

    return res.status(201).json(newScenario);
  } catch (err: any) {
    return res.status(400).json({ error: err.message });
  }
});

apiRouter.post('/tax/scenarios/:id/duplicate', (req: Request, res: Response) => {
  try {
    const copy = store.duplicateTaxScenario(req.params.id);
    return res.json(copy);
  } catch (err: any) {
    return res.status(404).json({ error: err.message });
  }
});

apiRouter.put('/tax/scenarios/:id', (req: Request, res: Response) => {
  try {
    const updated = store.updateTaxScenario(req.params.id, req.body);
    return res.json(updated);
  } catch (err: any) {
    return res.status(404).json({ error: err.message });
  }
});

apiRouter.delete('/tax/scenarios/:id', (req: Request, res: Response) => {
  const ok = store.deleteTaxScenario(req.params.id);
  if (!ok) return res.status(404).json({ error: 'Scenario not found.' });
  return res.json({ message: 'Scenario deleted.' });
});

// ==================== TAX FORECASTING ====================

apiRouter.get('/tax/forecast', (req: Request, res: Response) => {
  const companyId = (req.query.companyId as string) || 'comp_apex_tech';
  const forecast = store.getTaxForecast(companyId);
  return res.json(forecast);
});

apiRouter.post('/tax/forecast', (req: Request, res: Response) => {
  try {
    const {
      companyId = 'comp_apex_tech',
      financialYear = 'FY 2026-27',
      methodology = 'linear_regression',
      forecastHorizonMonths = 6,
      historicalData,
      baseTaxRate,
    } = req.body;

    const dataPoints = historicalData && historicalData.length >= 3
      ? historicalData
      : store.generateHistoricalData(companyId);

    const forecast = runTaxForecast({
      companyId,
      financialYear,
      methodology,
      forecastHorizonMonths: Number(forecastHorizonMonths) as 3 | 6 | 12,
      historicalData: dataPoints,
      baseTaxRate: baseTaxRate ? Number(baseTaxRate) : 25.17,
    });

    store.saveTaxForecast(forecast);
    return res.json(forecast);
  } catch (err: any) {
    return res.status(400).json({ error: err.message });
  }
});

// ==================== COMPLIANCE ====================

apiRouter.get('/compliance', (req: Request, res: Response) => {
  const companyId = (req.query.companyId as string) || 'comp_apex_tech';
  const items = store.getComplianceItems(companyId);
  const completed = items.filter((i) => i.status === 'Completed').length;
  const pending = items.filter((i) => i.status === 'Pending').length;
  const overdue = items.filter((i) => i.status === 'Overdue').length;
  const underReview = items.filter((i) => i.status === 'Under Review').length;

  const score = items.length
    ? Math.min(100, Math.max(0, Math.round((completed * 100 + underReview * 70 - overdue * 40) / items.length)))
    : 92;

  return res.json({
    items,
    stats: {
      score,
      completed,
      pending,
      overdue,
      underReview,
      total: items.length,
    },
  });
});

apiRouter.post('/compliance', (req: Request, res: Response) => {
  try {
    const { companyId = 'comp_apex_tech', title, category, dueDate, status, priority, owner, filingPeriod, penaltyRisk } = req.body;
    if (!title || !dueDate || !category) {
      return res.status(400).json({ error: 'Title, Due Date, and Category are required.' });
    }

    const item = store.createComplianceItem({
      companyId,
      title,
      category,
      dueDate,
      status: status || 'Pending',
      priority: priority || 'Medium',
      owner: owner || 'Financial Analyst',
      filingPeriod: filingPeriod || 'FY 2026-27',
      penaltyRisk: penaltyRisk || 'Statutory late filing interest & penalties',
    });
    return res.status(201).json(item);
  } catch (err: any) {
    return res.status(400).json({ error: err.message });
  }
});

apiRouter.put('/compliance/:id', (req: Request, res: Response) => {
  try {
    const updated = store.updateComplianceItem(req.params.id, req.body);
    return res.json(updated);
  } catch (err: any) {
    return res.status(404).json({ error: err.message });
  }
});

apiRouter.post('/compliance/:id/mark-complete', (req: Request, res: Response) => {
  try {
    const updated = store.updateComplianceItem(req.params.id, { status: 'Completed' });
    return res.json(updated);
  } catch (err: any) {
    return res.status(404).json({ error: err.message });
  }
});

apiRouter.delete('/compliance/:id', (req: Request, res: Response) => {
  const ok = store.deleteComplianceItem(req.params.id);
  if (!ok) return res.status(404).json({ error: 'Compliance item not found.' });
  return res.json({ message: 'Compliance item deleted.' });
});

// ==================== RISKS ====================

apiRouter.get('/risks', (req: Request, res: Response) => {
  const companyId = (req.query.companyId as string) || 'comp_apex_tech';
  const stats = store.getRiskStats(companyId);
  return res.json(stats);
});

apiRouter.post('/risks', (req: Request, res: Response) => {
  try {
    const { companyId = 'comp_apex_tech', riskName, category, description, probability, financialImpact, mitigation, owner, status } = req.body;
    if (!riskName || !category || !description) {
      return res.status(400).json({ error: 'Risk Name, Category, and Description are required.' });
    }

    const probNum = Math.min(5, Math.max(1, Number(probability) || 1));
    const impactNum = Math.min(5, Math.max(1, Number(financialImpact) || 1));

    const newRisk = store.createRisk({
      companyId,
      riskName,
      category,
      description,
      probability: probNum,
      financialImpact: impactNum,
      mitigation: mitigation || 'Continuous audit monitoring and reconciliation.',
      owner: owner || 'Tax Analyst',
      status: status || 'Open',
    });
    return res.status(201).json(newRisk);
  } catch (err: any) {
    return res.status(400).json({ error: err.message });
  }
});

apiRouter.put('/risks/:id', (req: Request, res: Response) => {
  try {
    const updated = store.updateRisk(req.params.id, req.body);
    return res.json(updated);
  } catch (err: any) {
    return res.status(404).json({ error: err.message });
  }
});

apiRouter.delete('/risks/:id', (req: Request, res: Response) => {
  const ok = store.deleteRisk(req.params.id);
  if (!ok) return res.status(404).json({ error: 'Risk not found.' });
  return res.json({ message: 'Risk deleted.' });
});

// ==================== AUDIT CENTER ====================

apiRouter.get('/audit', (req: Request, res: Response) => {
  const companyId = (req.query.companyId as string) || 'comp_apex_tech';
  const data = store.getAuditDocuments(companyId);
  return res.json(data);
});

apiRouter.post('/audit/upload', (req: Request, res: Response) => {
  try {
    const { id, fileName, fileSize, status = 'Uploaded', notes } = req.body;
    if (!id || !fileName) {
      return res.status(400).json({ error: 'Document ID and File Name are required.' });
    }

    const updated = store.updateAuditDocument(id, {
      fileName,
      fileSize: Number(fileSize) || 2400000,
      status: status as any,
      uploadedAt: new Date().toISOString(),
      notes: notes || 'Uploaded and verified against statutory audit index.',
    });
    return res.json(updated);
  } catch (err: any) {
    return res.status(404).json({ error: err.message });
  }
});

apiRouter.put('/audit/:id', (req: Request, res: Response) => {
  try {
    const updated = store.updateAuditDocument(req.params.id, req.body);
    return res.json(updated);
  } catch (err: any) {
    return res.status(404).json({ error: err.message });
  }
});

// ==================== TAX EFFICIENCY ====================

apiRouter.get('/tax-efficiency', (req: Request, res: Response) => {
  const companyId = (req.query.companyId as string) || 'comp_apex_tech';
  const comp = store.getCompany(companyId) || store.getCompanies()[0];
  const calc = store.getTaxCalculations(companyId)[0];

  const revenue = calc ? calc.revenue : comp.revenue;
  const pbt = calc ? calc.profitBeforeTax : comp.revenue - comp.expenses;
  const grossTax = calc ? calc.grossTax : pbt * 0.2517;
  const deductions = calc ? calc.totalDeductions : 4200000;

  const result = computeTaxEfficiency(revenue, pbt, grossTax, deductions);
  return res.json(result);
});

// ==================== REPORTS ====================

apiRouter.get('/reports', (req: Request, res: Response) => {
  const companyId = (req.query.companyId as string) || 'comp_apex_tech';
  const reports = store.getReports(companyId);
  return res.json(reports);
});

apiRouter.post('/reports', (req: Request, res: Response) => {
  try {
    const { companyId = 'comp_apex_tech', reportType, title, summary, data } = req.body;
    if (!reportType || !title) {
      return res.status(400).json({ error: 'Report Type and Title are required.' });
    }

    const newReport = store.createReport({
      companyId,
      reportType,
      title,
      financialYear: 'FY 2026-27',
      summary: summary || `Standard financial report generated for ${reportType}.`,
      generatedBy: 'Aditya Sharma (Junior Financial Analyst)',
      data: data || {},
    });
    return res.status(201).json(newReport);
  } catch (err: any) {
    return res.status(400).json({ error: err.message });
  }
});

// ==================== NOTIFICATIONS ====================

apiRouter.get('/notifications', (req: Request, res: Response) => {
  const companyId = (req.query.companyId as string) || 'comp_apex_tech';
  const notifs = store.getNotifications(companyId);
  return res.json(notifs);
});

apiRouter.post('/notifications/:id/read', (req: Request, res: Response) => {
  const ok = store.markNotificationAsRead(req.params.id);
  if (!ok) return res.status(404).json({ error: 'Notification not found.' });
  return res.json({ message: 'Notification marked as read.' });
});

apiRouter.post('/notifications/read-all', (req: Request, res: Response) => {
  const companyId = (req.body.companyId as string) || 'comp_apex_tech';
  store.markAllNotificationsAsRead(companyId);
  return res.json({ message: 'All notifications marked as read.' });
});

// ==================== SEARCH (Ctrl + K) ====================

apiRouter.get('/search', (req: Request, res: Response) => {
  const q = (req.query.q as string) || '';
  const companyId = (req.query.companyId as string) || 'comp_apex_tech';
  const results = store.globalSearch(q, companyId);
  return res.json(results);
});

// ==================== SETTINGS & TAX CONFIG ====================

apiRouter.get('/settings', (_req: Request, res: Response) => {
  const config = store.getTaxConfig();
  const user = store.findUserByEmail('analyst@taxwise.io');
  return res.json({
    taxConfig: config,
    user: user ? { id: user.id, name: user.name, email: user.email, role: user.role } : null,
  });
});

apiRouter.put('/settings/tax-config', (req: Request, res: Response) => {
  try {
    const updated = store.updateTaxConfig(req.body);
    return res.json(updated);
  } catch (err: any) {
    return res.status(400).json({ error: err.message });
  }
});

// ==================== FILE UPLOAD PARSING ====================

apiRouter.post('/upload/dataset', (req: Request, res: Response) => {
  try {
    const { fileName, fileSize, rows, columns } = req.body;
    if (!fileName || !rows || !Array.isArray(rows)) {
      return res.status(400).json({ error: 'File name and rows array are required.' });
    }

    // Validate financial headers
    const detectedCols = columns || (rows.length > 0 ? Object.keys(rows[0]) : []);
    const rowCount = rows.length;

    return res.json({
      status: 'success',
      fileName,
      fileSize: fileSize || '1.4 MB',
      rowCount,
      columns: detectedCols,
      uploadedAt: new Date().toISOString(),
      message: `Parsed ${rowCount} records successfully from ${fileName}.`,
      samplePreview: rows.slice(0, 5),
    });
  } catch (err: any) {
    return res.status(400).json({ error: err.message });
  }
});

// ==================== DEMO RESET ====================

apiRouter.post('/demo/reset', (_req: Request, res: Response) => {
  store.seedInitialData();
  return res.json({ message: 'Demo environment reset to baseline state successfully.' });
});
