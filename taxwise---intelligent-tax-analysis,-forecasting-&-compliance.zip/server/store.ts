import crypto from 'crypto';
import {
  User,
  UserRole,
  Company,
  Transaction,
  TaxCalculation,
  TaxScenario,
  TaxForecast,
  ComplianceItem,
  TaxRisk,
  AuditDocument,
  Report,
  Notification,
  TaxConfiguration,
} from './types';
import { calculateTax, computeTaxEfficiency, DEFAULT_TAX_CONFIG } from './taxEngine';
import { runTaxForecast } from './forecastEngine';

function hashPassword(password: string): string {
  return crypto.createHash('sha256').update(`taxwise_salt_${password}`).digest('hex');
}

export class MemoryStore {
  private users: User[] = [];
  private companies: Company[] = [];
  private transactions: Transaction[] = [];
  private taxCalculations: TaxCalculation[] = [];
  private taxScenarios: TaxScenario[] = [];
  private taxForecasts: TaxForecast[] = [];
  private complianceItems: ComplianceItem[] = [];
  private taxRisks: TaxRisk[] = [];
  private auditDocuments: AuditDocument[] = [];
  private reports: Report[] = [];
  private notifications: Notification[] = [];
  private taxConfig: TaxConfiguration = { ...DEFAULT_TAX_CONFIG };

  constructor() {
    this.seedInitialData();
  }

  public seedInitialData() {
    this.users = [];
    this.companies = [];
    this.transactions = [];
    this.taxCalculations = [];
    this.taxScenarios = [];
    this.taxForecasts = [];
    this.complianceItems = [];
    this.taxRisks = [];
    this.auditDocuments = [];
    this.reports = [];
    this.notifications = [];
    this.taxConfig = { ...DEFAULT_TAX_CONFIG };

    // Primary Demo Company
    const demoCompanyId = 'comp_apex_tech';
    const compApex: Company = {
      id: demoCompanyId,
      name: 'Apex Technologies Pvt. Ltd.',
      industry: 'Technology Services & Cloud Solutions',
      businessType: 'Private Limited Company',
      pan: 'AABCA1234F',
      gstin: '27AABCA1234F1Z5',
      state: 'Maharashtra',
      city: 'Mumbai',
      financialYear: 'FY 2026-27',
      revenue: 124000000, // ₹12.4 Cr
      expenses: 75800000,  // ₹7.58 Cr
      baseTaxRate: 25.17, // 22% + 10% surcharge + 4% cess
      isDemo: true,
    };

    const compHorizon: Company = {
      id: 'comp_horizon_logistics',
      name: 'Horizon Global Logistics Ltd.',
      industry: 'Freight & Supply Chain Infrastructure',
      businessType: 'Public Limited Company',
      pan: 'AAACH5678K',
      gstin: '29AAACH5678K1Z2',
      state: 'Karnataka',
      city: 'Bengaluru',
      financialYear: 'FY 2026-27',
      revenue: 285000000,
      expenses: 212000000,
      baseTaxRate: 25.17,
      isDemo: false,
    };

    const compQuant: Company = {
      id: 'comp_quantedge',
      name: 'QuantEdge FinTech Solutions',
      industry: 'Financial Software & Algorithmic Engines',
      businessType: 'Private Limited Company',
      pan: 'AAAFQ9876C',
      gstin: '07AAAFQ9876C1Z8',
      state: 'Delhi',
      city: 'New Delhi',
      financialYear: 'FY 2026-27',
      revenue: 182000000,
      expenses: 114000000,
      baseTaxRate: 25.17,
      isDemo: false,
    };

    this.companies.push(compApex, compHorizon, compQuant);

    // Default Analyst User
    const defaultUser: User = {
      id: 'user_analyst_01',
      name: 'Aditya Sharma',
      email: 'analyst@taxwise.io',
      passwordHash: hashPassword('Password123!'),
      role: 'Junior Financial Analyst',
      companyId: demoCompanyId,
      avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      createdAt: '2026-04-01T09:00:00.000Z',
    };
    this.users.push(defaultUser);

    // Initial Tax Calculation for Apex
    const initialCalc = calculateTax({
      companyId: demoCompanyId,
      financialYear: 'FY 2026-27',
      revenue: 124000000, // ₹12.4 Cr
      operatingExpenses: 28500000,
      employeeExpenses: 34500000,
      depreciation: 8200000,
      otherExpenses: 4600000,
      deductions: [
        {
          id: 'ded_1',
          section: 'Section 80JJAA',
          name: 'Employment Generation Incentive (42 Tech Roles)',
          amount: 2500000,
          description: '30% additional deduction on qualifying engineering recruits',
        },
        {
          id: 'ded_2',
          section: 'Section 35(2AB)',
          name: 'Scientific R&D Expenditure (AI Architecture)',
          amount: 1700000,
          description: 'Weighted allowance on proprietary server infra & testing labs',
        },
      ],
      advanceTaxPaid: 6500000,
      tdsCredit: 2000000,
      matCreditUtilized: 0,
      notes: 'Initial FY 2026-27 Q2 corporate tax review for Apex Technologies.',
    });
    this.taxCalculations.push(initialCalc);

    // Scenarios for Tax Strategy Simulator
    this.taxScenarios.push(
      {
        id: 'scen_baseline',
        companyId: demoCompanyId,
        name: 'Current Statutory Strategy (As-Is)',
        description: 'Standard baseline without discretionary depreciation acceleration or Section 80JJAA optimization.',
        revenue: 100000000, // ₹10 Cr
        expenses: 50000000,  // ₹5 Cr
        depreciation: 6000000,
        deductions: 0,
        taxCredits: 0,
        taxRate: 25.17,
        taxableIncome: 50000000,
        estimatedTax: 12585000, // ₹1.26 Cr
        effectiveTaxRate: 25.17,
        netProfitAfterTax: 37415000,
        taxSavingsVsBaseline: 0,
        isOptimized: false,
        assumptions: [
          'No additional R&D or employment deductions configured',
          'Standard SLM depreciation under Companies Act with IT Act alignment',
          'Standard Section 115BAA corporate rate (25.17%)',
        ],
        createdAt: '2026-06-15T10:00:00Z',
      },
      {
        id: 'scen_optimized',
        companyId: demoCompanyId,
        name: 'Optimized Tax Strategy (80JJAA + Accelerated Depr)',
        description: 'Leveraging qualifying engineer payroll deduction under 80JJAA and IT equipment accelerated write-off.',
        revenue: 100000000, // ₹10 Cr
        expenses: 54000000,  // ₹5.4 Cr (additional allowable depreciation & deductible allocations)
        depreciation: 10000000,
        deductions: 3500000, // ₹35 Lakhs deductions
        taxCredits: 500000,
        taxRate: 25.17,
        taxableIncome: 42500000, // ₹4.25 Cr
        estimatedTax: 10197250, // ₹1.02 Cr
        effectiveTaxRate: 22.17,
        netProfitAfterTax: 35802750,
        taxSavingsVsBaseline: 2387750, // Potential difference ₹23.88 Lakhs
        isOptimized: true,
        assumptions: [
          'Section 80JJAA 30% additional payroll deduction claimed for 28 eligible hires',
          'Accelerated 40% depreciation claimed on new cloud compute servers',
          'Advance tax schedule aligned with Q3 safe harbor provisions',
        ],
        createdAt: '2026-06-20T14:30:00Z',
      },
      {
        id: 'scen_rd_credit',
        companyId: demoCompanyId,
        name: 'R&D Expansion & Export Incentive Model',
        description: 'Expanded tech IP development center with SEZ export profit exemption allocation.',
        revenue: 124000000,
        expenses: 68000000,
        depreciation: 9000000,
        deductions: 4200000,
        taxCredits: 8500000,
        taxRate: 25.17,
        taxableIncome: 51800000,
        estimatedTax: 13038060,
        effectiveTaxRate: 23.28,
        netProfitAfterTax: 42961940,
        taxSavingsVsBaseline: 1860000, // ₹18.6 Lakhs
        isOptimized: true,
        assumptions: [
          'Section 35(2AB) scientific testing facilities accredited',
          'Cross-border withholding rate optimized under India-US DTAA Article 12',
          'Tax savings reinvested into corporate innovation fund',
        ],
        createdAt: '2026-08-10T11:15:00Z',
      }
    );

    // Transactions for Apex
    const demoTransactions: Transaction[] = [
      {
        id: 'tx_01',
        companyId: demoCompanyId,
        date: '2026-09-24',
        description: 'Enterprise Cloud Retainer - Vertex Corp Inc',
        category: 'Revenue',
        type: 'credit',
        amount: 8500000,
        taxCategory: 'GST 18%',
        taxAmount: 1530000,
        paymentStatus: 'Paid',
        referenceNo: 'INV-2026-0891',
      },
      {
        id: 'tx_02',
        companyId: demoCompanyId,
        date: '2026-09-20',
        description: 'Q2 Advance Tax Installment (Challan 280)',
        category: 'Tax Payment',
        type: 'debit',
        amount: 3500000,
        taxCategory: 'Direct Tax',
        taxAmount: 3500000,
        paymentStatus: 'Paid',
        referenceNo: 'CIN-280-994821',
      },
      {
        id: 'tx_03',
        companyId: demoCompanyId,
        date: '2026-09-18',
        description: 'Senior Software Engineering Team Payroll (Sep)',
        category: 'Payroll',
        type: 'debit',
        amount: 5800000,
        taxCategory: 'TDS 192',
        taxAmount: 580000,
        paymentStatus: 'Paid',
        referenceNo: 'PAY-2026-09',
      },
      {
        id: 'tx_04',
        companyId: demoCompanyId,
        date: '2026-09-15',
        description: 'High Performance GPU Nodes - SuperMicro Servers',
        category: 'Capital Expense',
        type: 'debit',
        amount: 3200000,
        taxCategory: 'GST 18%',
        taxAmount: 576000,
        paymentStatus: 'Paid',
        referenceNo: 'CAP-2026-441',
      },
      {
        id: 'tx_05',
        companyId: demoCompanyId,
        date: '2026-09-12',
        description: 'AWS Cloud Hosting & Distributed CDN Vouchers',
        category: 'Operating Expense',
        type: 'debit',
        amount: 1450000,
        taxCategory: 'TDS 194J',
        taxAmount: 29000,
        paymentStatus: 'Paid',
        referenceNo: 'AWS-99382104',
      },
      {
        id: 'tx_06',
        companyId: demoCompanyId,
        date: '2026-09-08',
        description: 'SaaS Platform Subscription Licensing - FinCorp UK',
        category: 'Revenue',
        type: 'credit',
        amount: 6200000,
        taxCategory: 'Exempt',
        taxAmount: 0,
        paymentStatus: 'Paid',
        referenceNo: 'INV-2026-0882',
      },
      {
        id: 'tx_07',
        companyId: demoCompanyId,
        date: '2026-09-05',
        description: 'Statutory Tax Audit & Advisory Fees - BDO Global',
        category: 'Operating Expense',
        type: 'debit',
        amount: 450000,
        taxCategory: 'TDS 194J',
        taxAmount: 45000,
        paymentStatus: 'Paid',
        referenceNo: 'ADV-2026-102',
      },
      {
        id: 'tx_08',
        companyId: demoCompanyId,
        date: '2026-08-28',
        description: 'Software Architecture Consulting Services',
        category: 'Revenue',
        type: 'credit',
        amount: 4800000,
        taxCategory: 'GST 18%',
        taxAmount: 864000,
        paymentStatus: 'Paid',
        referenceNo: 'INV-2026-0865',
      },
      {
        id: 'tx_09',
        companyId: demoCompanyId,
        date: '2026-08-20',
        description: 'GSTR-3B Monthly Tax Remittance (Aug)',
        category: 'Tax Payment',
        type: 'debit',
        amount: 1850000,
        taxCategory: 'GST',
        taxAmount: 1850000,
        paymentStatus: 'Paid',
        referenceNo: 'GST-PMT06-4421',
      },
      {
        id: 'tx_10',
        companyId: demoCompanyId,
        date: '2026-08-15',
        description: 'Bandwidth & Lease Line Infrastructure (Tata Comm)',
        category: 'Operating Expense',
        type: 'debit',
        amount: 320000,
        taxCategory: 'GST 18%',
        taxAmount: 57600,
        paymentStatus: 'Paid',
        referenceNo: 'TCL-2026-993',
      },
      {
        id: 'tx_11',
        companyId: demoCompanyId,
        date: '2026-08-05',
        description: 'R&D Lab Testing Apparatus Depreciation Allocation',
        category: 'Other',
        type: 'debit',
        amount: 680000,
        taxCategory: 'Direct Tax',
        taxAmount: 0,
        paymentStatus: 'Paid',
        referenceNo: 'DEP-2026-08',
      },
      {
        id: 'tx_12',
        companyId: demoCompanyId,
        date: '2026-07-22',
        description: 'Mobile App Modernization Milestone - RetailX',
        category: 'Revenue',
        type: 'credit',
        amount: 7400000,
        taxCategory: 'GST 18%',
        taxAmount: 1332000,
        paymentStatus: 'Paid',
        referenceNo: 'INV-2026-0841',
      },
      {
        id: 'tx_13',
        companyId: demoCompanyId,
        date: '2026-07-15',
        description: 'TDS Q1 Deposition (Form 26Q & 24Q)',
        category: 'Tax Payment',
        type: 'debit',
        amount: 1420000,
        taxCategory: 'TDS',
        taxAmount: 1420000,
        paymentStatus: 'Paid',
        referenceNo: 'TDS-CHL-88219',
      },
      {
        id: 'tx_14',
        companyId: demoCompanyId,
        date: '2026-07-02',
        description: 'Cybersecurity Penetration Testing & ISO Audit',
        category: 'Operating Expense',
        type: 'debit',
        amount: 550000,
        taxCategory: 'GST 18%',
        taxAmount: 99000,
        paymentStatus: 'Paid',
        referenceNo: 'SEC-2026-014',
      },
      {
        id: 'tx_15',
        companyId: demoCompanyId,
        date: '2026-06-15',
        description: 'Q1 Advance Tax Installment (Challan 280)',
        category: 'Tax Payment',
        type: 'debit',
        amount: 3000000,
        taxCategory: 'Direct Tax',
        taxAmount: 3000000,
        paymentStatus: 'Paid',
        referenceNo: 'CIN-280-771822',
      },
    ];
    this.transactions.push(...demoTransactions);

    // Compliance Items
    const demoCompliance: ComplianceItem[] = [
      {
        id: 'comp_1',
        companyId: demoCompanyId,
        title: 'Advance Tax Q3 Installment (75% Threshold)',
        category: 'Direct Tax',
        dueDate: '2026-12-15',
        status: 'Pending',
        priority: 'Critical',
        owner: 'Aditya Sharma',
        filingPeriod: 'Q3 FY 2026-27',
        penaltyRisk: 'Section 234C 1% monthly interest on installment shortfall',
        documentAttached: {
          name: 'Challan_280_Q3_Worksheet.xlsx',
          size: 142000,
          uploadedAt: '2026-09-25T11:00:00Z',
        },
      },
      {
        id: 'comp_2',
        companyId: demoCompanyId,
        title: 'GSTR-3B Monthly Return Filing (September)',
        category: 'GST',
        dueDate: '2026-10-20',
        status: 'Pending',
        priority: 'High',
        owner: 'Neha Verma',
        filingPeriod: 'Sep 2026',
        penaltyRisk: '₹50/day late fee + 18% p.a. interest on unpaid net tax',
      },
      {
        id: 'comp_3',
        companyId: demoCompanyId,
        title: 'GSTR-1 Outward Supplies Statement (September)',
        category: 'GST',
        dueDate: '2026-10-11',
        status: 'Pending',
        priority: 'High',
        owner: 'Neha Verma',
        filingPeriod: 'Sep 2026',
        penaltyRisk: 'Recipient ITC blockage & late fee under Section 47',
      },
      {
        id: 'comp_4',
        companyId: demoCompanyId,
        title: 'Quarterly TDS Return Filing (Form 26Q - Non Salary)',
        category: 'TDS/TCS',
        dueDate: '2026-10-31',
        status: 'Under Review',
        priority: 'High',
        owner: 'Aditya Sharma',
        filingPeriod: 'Q2 FY 2026-27',
        penaltyRisk: 'Section 234E late fee of ₹200/day during default',
        documentAttached: {
          name: 'Form26Q_Q2_Reconciliation.csv',
          size: 89000,
          uploadedAt: '2026-09-28T16:20:00Z',
        },
      },
      {
        id: 'comp_5',
        companyId: demoCompanyId,
        title: 'Quarterly TDS Return Filing (Form 24Q - Salary)',
        category: 'TDS/TCS',
        dueDate: '2026-10-31',
        status: 'Pending',
        priority: 'Medium',
        owner: 'Aditya Sharma',
        filingPeriod: 'Q2 FY 2026-27',
        penaltyRisk: 'Section 234E ₹200/day late fee',
      },
      {
        id: 'comp_6',
        companyId: demoCompanyId,
        title: 'Transfer Pricing Documentation (Form 3CEB & Local File)',
        category: 'Transfer Pricing',
        dueDate: '2026-11-30',
        status: 'Under Review',
        priority: 'Critical',
        owner: 'Pooja Iyer (External Counsel)',
        filingPeriod: 'AY 2026-27',
        penaltyRisk: 'Section 271AA penalty of 2% of international transaction value',
        documentAttached: {
          name: 'TP_Study_Benchmark_Report_Apex.pdf',
          size: 2450000,
          uploadedAt: '2026-09-18T14:10:00Z',
        },
      },
      {
        id: 'comp_7',
        companyId: demoCompanyId,
        title: 'Corporate Income Tax Return (ITR-6)',
        category: 'Direct Tax',
        dueDate: '2026-10-31',
        status: 'Completed',
        priority: 'Critical',
        owner: 'Aditya Sharma',
        filingPeriod: 'AY 2026-27',
        penaltyRisk: 'Section 234A interest and Section 270A under-reporting penalty',
        documentAttached: {
          name: 'ITR6_Acknowledgement_AY2026.pdf',
          size: 320000,
          uploadedAt: '2026-09-29T10:05:00Z',
        },
      },
      {
        id: 'comp_8',
        companyId: demoCompanyId,
        title: 'Annual GST Return (GSTR-9 & 9C Reconciliation)',
        category: 'GST',
        dueDate: '2026-12-31',
        status: 'Pending',
        priority: 'Medium',
        owner: 'Neha Verma',
        filingPeriod: 'FY 2025-26',
        penaltyRisk: 'Section 47 ₹200/day subject to 0.5% turnover cap',
      },
      {
        id: 'comp_9',
        companyId: demoCompanyId,
        title: 'Advance Tax Q2 Installment (45% Threshold)',
        category: 'Direct Tax',
        dueDate: '2026-09-15',
        status: 'Completed',
        priority: 'High',
        owner: 'Aditya Sharma',
        filingPeriod: 'Q2 FY 2026-27',
        penaltyRisk: 'Mitigated - Paid ₹35 Lakhs on 2026-09-20',
        documentAttached: {
          name: 'Challan_280_Q2_Receipt.pdf',
          size: 195000,
          uploadedAt: '2026-09-20T17:00:00Z',
        },
      },
      {
        id: 'comp_10',
        companyId: demoCompanyId,
        title: 'Advance Tax Q1 Installment (15% Threshold)',
        category: 'Direct Tax',
        dueDate: '2026-06-15',
        status: 'Completed',
        priority: 'High',
        owner: 'Aditya Sharma',
        filingPeriod: 'Q1 FY 2026-27',
        penaltyRisk: 'Mitigated - Paid ₹30 Lakhs on 2026-06-15',
        documentAttached: {
          name: 'Challan_280_Q1_Receipt.pdf',
          size: 185000,
          uploadedAt: '2026-06-15T15:30:00Z',
        },
      },
    ];
    this.complianceItems.push(...demoCompliance);

    // Tax Risks
    const demoRisks: TaxRisk[] = [
      {
        id: 'risk_01',
        companyId: demoCompanyId,
        riskName: 'Transfer Pricing Cost-Plus Margin Scrutiny',
        category: 'Transfer Pricing',
        description: 'Cross-border cloud engineering services billed to US parent entity at 15% mark-up vs industry arm\'s-length benchmark of 17.5%.',
        probability: 3,
        financialImpact: 4,
        riskScore: 12,
        severity: 'Medium',
        mitigation: 'Commission fresh CUP benchmark search report via BDO and formalize master service agreement addendum.',
        owner: 'Pooja Iyer',
        status: 'Mitigating',
        detectedDate: '2026-07-10',
      },
      {
        id: 'risk_02',
        companyId: demoCompanyId,
        riskName: 'GSTR-2B vs Purchase Ledger ITC Variance',
        category: 'GST Reconciliation',
        description: 'Input Tax Credit variance of ₹14.8 Lakhs where supplier delayed GSTR-1 filings past cutoff date.',
        probability: 4,
        financialImpact: 3,
        riskScore: 12,
        severity: 'Medium',
        mitigation: 'Automate weekly vendor GSTR-2B compliance notifications and withhold GST balance until portal reflection.',
        owner: 'Neha Verma',
        status: 'Mitigating',
        detectedDate: '2026-08-01',
      },
      {
        id: 'risk_03',
        companyId: demoCompanyId,
        riskName: 'Section 194J vs 194C TDS Classification on Cloud Hosting',
        category: 'TDS Non-Deduction',
        description: 'Exposure on whether automated cloud server provisioning incurs 2% (contractor) or 10% (technical fee) withholding.',
        probability: 2,
        financialImpact: 3,
        riskScore: 6,
        severity: 'Low',
        mitigation: 'Obtain written legal opinion citing SC ruling on standard facility without human intervention.',
        owner: 'Aditya Sharma',
        status: 'Open',
        detectedDate: '2026-08-15',
      },
      {
        id: 'risk_04',
        companyId: demoCompanyId,
        riskName: 'Accelerated Depreciation Disallowance on High-End GPU Rig',
        category: 'Depreciation Disallowance',
        description: 'Claim of 40% computer hardware depreciation on AI servers instead of 15% general plant & machinery rate.',
        probability: 2,
        financialImpact: 2,
        riskScore: 4,
        severity: 'Low',
        mitigation: 'Maintain detailed engineer hardware utilization logs showing exclusive software model training usage.',
        owner: 'Aditya Sharma',
        status: 'Resolved',
        detectedDate: '2026-06-25',
      },
      {
        id: 'risk_05',
        companyId: demoCompanyId,
        riskName: 'FEMA Realization Horizon for Export Invoices',
        category: 'Related Party Transaction',
        description: 'Two export invoices totaling $110,000 pending realization beyond 9-month statutory window under RBI FEMA regulations.',
        probability: 2,
        financialImpact: 2,
        riskScore: 4,
        severity: 'Low',
        mitigation: 'File EDPMS extension request through Authorized Dealer Category-I bank before quarter end.',
        owner: 'Aditya Sharma',
        status: 'Mitigating',
        detectedDate: '2026-09-02',
      },
    ];
    this.taxRisks.push(...demoRisks);

    // Audit Documents
    const auditDocs: AuditDocument[] = [
      {
        id: 'aud_1',
        companyId: demoCompanyId,
        itemType: 'Financial Statements',
        title: 'Audited Balance Sheet, Profit & Loss and Auditor Notes FY25-26',
        fileName: 'Apex_Audited_Financials_FY2526.pdf',
        fileSize: 4200000,
        status: 'Uploaded',
        uploadedAt: '2026-08-15T10:00:00Z',
        compliancePeriod: 'FY 2025-26',
        notes: 'Signed by Statutory Auditors with clean unqualified opinion.',
      },
      {
        id: 'aud_2',
        companyId: demoCompanyId,
        itemType: 'Tax Returns',
        title: 'ITR-6 Filing Acknowledgement & Computation Form',
        fileName: 'ITR6_AY2026_27_Ack.pdf',
        fileSize: 850000,
        status: 'Uploaded',
        uploadedAt: '2026-09-29T11:30:00Z',
        compliancePeriod: 'AY 2026-27',
        notes: 'E-verified via DSC on income tax portal.',
      },
      {
        id: 'aud_3',
        companyId: demoCompanyId,
        itemType: 'Invoices',
        title: 'Sample Invoices Registry (Top 100 Revenue & Purchase)',
        fileName: 'Invoice_Registry_Sample_Dump.xlsx',
        fileSize: 1840000,
        status: 'Uploaded',
        uploadedAt: '2026-09-22T14:15:00Z',
        compliancePeriod: 'FY 2026-27 YTD',
        notes: 'All items matched against IRN and E-way bill portal logs.',
      },
      {
        id: 'aud_4',
        companyId: demoCompanyId,
        itemType: 'Expense Records',
        title: 'Vendor Expense Vouchers & Proof of Payment (>₹50,000)',
        fileName: 'Expense_Vouchers_Q1Q2.zip',
        fileSize: 12500000,
        status: 'Needs Review',
        uploadedAt: '2026-09-26T18:00:00Z',
        compliancePeriod: 'Q1-Q2 FY 2026-27',
        notes: '14 vouchers pending supporting approval signatures from department leads.',
      },
      {
        id: 'aud_5',
        companyId: demoCompanyId,
        itemType: 'Bank Statements',
        title: 'Primary Operating Bank Statements & Monthly BRS',
        fileName: 'HDFC_Bank_Statements_12Months.pdf',
        fileSize: 3100000,
        status: 'Uploaded',
        uploadedAt: '2026-09-10T16:00:00Z',
        compliancePeriod: 'Apr 2025 - Mar 2026',
        notes: 'Zero unreconciled items older than 30 days.',
      },
      {
        id: 'aud_6',
        companyId: demoCompanyId,
        itemType: 'Payroll Records',
        title: 'Salary Register, Form 16 Part A & B, PF/ESI Challans',
        fileName: 'Payroll_Compliance_Bundle_FY26.pdf',
        fileSize: 5600000,
        status: 'Uploaded',
        uploadedAt: '2026-08-30T12:00:00Z',
        compliancePeriod: 'FY 2026-27 YTD',
        notes: 'Reconciled with Section 80JJAA headcount verification tracker.',
      },
      {
        id: 'aud_7',
        companyId: demoCompanyId,
        itemType: 'Tax Payments',
        title: 'Advance Tax 280, GST PMT-06 and TDS 281 Challan Receipts',
        fileName: 'All_Tax_Challans_Bundle_2026.pdf',
        fileSize: 2200000,
        status: 'Uploaded',
        uploadedAt: '2026-09-21T09:30:00Z',
        compliancePeriod: 'FY 2026-27 YTD',
        notes: 'Cross-verified with OLTAS portal and Form 26AS reflection.',
      },
      {
        id: 'aud_8',
        companyId: demoCompanyId,
        itemType: 'Supporting Documents',
        title: 'Master Service Agreements & Customer Contracts',
        fileName: 'Client_Contracts_Executed.pdf',
        fileSize: 8400000,
        status: 'Uploaded',
        uploadedAt: '2026-07-15T15:00:00Z',
        compliancePeriod: 'Active FY26',
        notes: 'Includes Transfer Pricing inter-company agreements.',
      },
      {
        id: 'aud_9',
        companyId: demoCompanyId,
        itemType: 'Tax Correspondence',
        title: 'Intimations u/s 143(1), Rectification Requests & Notices',
        fileName: 'Income_Tax_Correspondence_AY2526.pdf',
        fileSize: 1100000,
        status: 'Uploaded',
        uploadedAt: '2026-09-05T13:45:00Z',
        compliancePeriod: 'AY 2025-26',
        notes: 'All previous intimations accepted without adverse adjustments.',
      },
    ];
    this.auditDocuments.push(...auditDocs);

    // Initial Forecast for Apex
    const historicalApexData = this.generateHistoricalData(demoCompanyId);
    const initialForecast = runTaxForecast({
      companyId: demoCompanyId,
      financialYear: 'FY 2026-27',
      methodology: 'linear_regression',
      forecastHorizonMonths: 6,
      historicalData: historicalApexData,
      baseTaxRate: 25.17,
    });
    this.taxForecasts.push(initialForecast);

    // Pre-generated Reports
    this.reports.push(
      {
        id: 'rep_01',
        companyId: demoCompanyId,
        reportType: 'Tax Liability',
        title: 'Comprehensive Tax Liability Assessment FY 2026-27',
        financialYear: 'FY 2026-27',
        summary: 'Detailed statutory corporate income tax liability breakdown, advance tax schedules, and effective tax rate calculations for Apex Technologies Pvt. Ltd.',
        generatedDate: '2026-09-25T14:00:00Z',
        generatedBy: 'Aditya Sharma (Junior Financial Analyst)',
        data: {
          revenue: 124000000,
          expenses: 75800000,
          profitBeforeTax: 48200000,
          deductions: 4200000,
          taxableIncome: 44000000,
          grossTax: 11074800,
          taxCredits: 8500000,
          estimatedTaxPayable: 2574800,
          effectiveTaxRate: 22.98,
          netProfitAfterTax: 37125200,
        },
      },
      {
        id: 'rep_02',
        companyId: demoCompanyId,
        reportType: 'Tax Forecast',
        title: '6-Month Tax Liability & Cash Flow Projection',
        financialYear: 'FY 2026-27',
        summary: 'OLS Linear Regression forecasting of monthly operating profit and cumulative advance tax liability requirements for H2 FY 2026-27.',
        generatedDate: '2026-09-20T11:30:00Z',
        generatedBy: 'Aditya Sharma (Junior Financial Analyst)',
        data: {
          methodology: 'linear_regression',
          rSquared: 0.912,
          projectedH2TaxLiability: 6450000,
          recommendedAdvanceTaxReserve: 7200000,
        },
      },
      {
        id: 'rep_03',
        companyId: demoCompanyId,
        reportType: 'Compliance',
        title: 'Q2 Compliance Calendar & Statutory Due Diligence Audit',
        financialYear: 'FY 2026-27',
        summary: 'Status audit of 10 statutory filings covering GST, Corporate Tax, and TDS regimes. Compliance index assessed at 92/100.',
        generatedDate: '2026-09-28T09:15:00Z',
        generatedBy: 'Aditya Sharma (Junior Financial Analyst)',
        data: {
          complianceScore: 92,
          completedCount: 3,
          pendingCount: 5,
          underReviewCount: 2,
          overdueCount: 0,
        },
      },
      {
        id: 'rep_04',
        companyId: demoCompanyId,
        reportType: 'Tax Risk',
        title: 'Enterprise Tax Risk Register & Mitigation Strategy Matrix',
        financialYear: 'FY 2026-27',
        summary: 'Probability vs. Financial Impact matrix analysis identifying 5 operational risks across transfer pricing, GST reconciliation, and TDS classification.',
        generatedDate: '2026-09-15T16:45:00Z',
        generatedBy: 'Aditya Sharma (Junior Financial Analyst)',
        data: {
          overallRisk: 'Low',
          criticalCount: 0,
          highCount: 0,
          mediumCount: 2,
          lowCount: 3,
          topExposure: 'Transfer Pricing Cost-Plus Margin Scrutiny',
        },
      },
      {
        id: 'rep_05',
        companyId: demoCompanyId,
        reportType: 'Audit Readiness',
        title: 'Statutory Tax Audit Readiness Evaluation Scorecard',
        financialYear: 'FY 2026-27',
        summary: 'Pre-audit readiness verification across 9 mandatory evidentiary categories. Overall readiness index reached 87%.',
        generatedDate: '2026-09-27T17:20:00Z',
        generatedBy: 'Aditya Sharma (Junior Financial Analyst)',
        data: {
          readinessScore: 87,
          totalCategories: 9,
          uploadedCount: 8,
          needsReviewCount: 1,
          missingCount: 0,
        },
      },
      {
        id: 'rep_06',
        companyId: demoCompanyId,
        reportType: 'Tax Efficiency',
        title: 'Corporate Tax Efficiency & Incentive Optimization Study',
        financialYear: 'FY 2026-27',
        summary: 'Evaluation of Effective Tax Rate (22.98%) vs Statutory Benchmark (25.17%), with ₹18.6 Lakhs allowable savings path via Section 80JJAA.',
        generatedDate: '2026-09-26T13:00:00Z',
        generatedBy: 'Aditya Sharma (Junior Financial Analyst)',
        data: {
          effectiveTaxRate: 22.98,
          taxToRevenueRatio: 8.93,
          taxToProfitRatio: 22.98,
          taxSavingsOpportunity: 1860000,
        },
      }
    );

    // Notifications
    this.notifications.push(
      {
        id: 'notif_1',
        companyId: demoCompanyId,
        title: 'Compliance Deadline Approaching',
        message: 'GSTR-1 statement for September 2026 is due in 11 days (October 11).',
        type: 'warning',
        isRead: false,
        createdAt: '2026-09-30T08:00:00Z',
        linkTo: '/compliance',
      },
      {
        id: 'notif_2',
        companyId: demoCompanyId,
        title: 'Audit Document Needs Review',
        message: '14 vendor vouchers in Expense Records bundle require managerial sign-off.',
        type: 'alert',
        isRead: false,
        createdAt: '2026-09-29T14:30:00Z',
        linkTo: '/audit',
      },
      {
        id: 'notif_3',
        companyId: demoCompanyId,
        title: 'Tax Calculation Completed',
        message: 'FY 2026-27 Q2 corporate liability updated: Taxable Income ₹4.82 Cr, Estimated Tax ₹1.45 Cr.',
        type: 'success',
        isRead: false,
        createdAt: '2026-09-28T10:15:00Z',
        linkTo: '/calculator',
      },
      {
        id: 'notif_4',
        companyId: demoCompanyId,
        title: 'Tax Optimization Opportunity Identified',
        message: '₹18.6 Lakhs potential savings discovered in Section 80JJAA employment deduction simulation.',
        type: 'info',
        isRead: true,
        createdAt: '2026-09-26T15:45:00Z',
        linkTo: '/planning',
      }
    );
  }

  public generateHistoricalData(companyId: string) {
    const months = [
      'Oct 2025', 'Nov 2025', 'Dec 2025',
      'Jan 2026', 'Feb 2026', 'Mar 2026',
      'Apr 2026', 'May 2026', 'Jun 2026',
      'Jul 2026', 'Aug 2026', 'Sep 2026',
    ];

    const baseRev = 9200000;
    const baseExp = 5800000;

    return months.map((m, idx) => {
      const growth = 1 + idx * 0.025 + Math.sin(idx) * 0.03;
      const rev = Math.round(baseRev * growth);
      const exp = Math.round(baseExp * (1 + idx * 0.018));
      const profit = Math.max(0, rev - exp);
      const taxLiability = Math.round(profit * 0.2517);
      const taxPaid = idx % 3 === 2 ? Math.round(taxLiability * 0.9) : Math.round(taxLiability * 0.2);

      return {
        month: m,
        revenue: rev,
        expenses: exp,
        profit,
        taxPaid,
        taxLiability,
      };
    });
  }

  // User methods
  public findUserByEmail(email: string): User | undefined {
    return this.users.find((u) => u.email.toLowerCase() === email.toLowerCase());
  }

  public findUserById(id: string): User | undefined {
    return this.users.find((u) => u.id === id);
  }

  public createUser(userData: {
    name: string;
    email: string;
    password: string;
    role?: UserRole;
    companyId?: string;
  }): User {
    const existing = this.findUserByEmail(userData.email);
    if (existing) {
      throw new Error('A user with this email address already exists.');
    }

    const defaultComp = this.companies[0]?.id || 'comp_apex_tech';
    const newUser: User = {
      id: `user_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      name: userData.name,
      email: userData.email,
      passwordHash: hashPassword(userData.password),
      role: userData.role || 'Junior Financial Analyst',
      companyId: userData.companyId || defaultComp,
      createdAt: new Date().toISOString(),
    };
    this.users.push(newUser);
    return newUser;
  }

  public verifyPassword(user: User, passwordAttempt: string): boolean {
    return user.passwordHash === hashPassword(passwordAttempt);
  }

  // Company methods
  public getCompanies(): Company[] {
    return [...this.companies];
  }

  public getCompany(id: string): Company | undefined {
    return this.companies.find((c) => c.id === id);
  }

  public createCompany(data: Omit<Company, 'id'>): Company {
    const newCompany: Company = {
      ...data,
      id: `comp_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    };
    this.companies.push(newCompany);
    return newCompany;
  }

  public updateCompany(id: string, updates: Partial<Company>): Company {
    const idx = this.companies.findIndex((c) => c.id === id);
    if (idx === -1) throw new Error('Company not found.');
    this.companies[idx] = { ...this.companies[idx], ...updates };
    return this.companies[idx];
  }

  public deleteCompany(id: string): boolean {
    const idx = this.companies.findIndex((c) => c.id === id);
    if (idx === -1) return false;
    this.companies.splice(idx, 1);
    return true;
  }

  // Dashboard Stats
  public getDashboardStats(companyId: string, financialYear?: string) {
    const comp = this.getCompany(companyId) || this.companies[0];
    const calc = this.taxCalculations.find((c) => c.companyId === comp.id) || this.taxCalculations[0];
    const compScore = this.calculateComplianceScore(comp.id);
    const riskStats = this.getRiskStats(comp.id);

    // Compute metrics
    const revenue = calc ? calc.revenue : comp.revenue;
    const taxableIncome = calc ? calc.taxableIncome : comp.revenue - comp.expenses;
    const estimatedTax = calc ? calc.grossTax : taxableIncome * (comp.baseTaxRate / 100);
    const taxSavingsOpportunity = 1860000; // ₹18.6 L

    return {
      company: comp,
      financialYear: financialYear || comp.financialYear,
      kpi: {
        revenue,
        revenueFormatted: this.formatCurrency(revenue),
        revenueGrowth: '+8.4%',
        taxableIncome,
        taxableIncomeFormatted: this.formatCurrency(taxableIncome),
        taxableIncomeGrowth: '+5.2%',
        estimatedTax,
        estimatedTaxFormatted: this.formatCurrency(estimatedTax),
        taxSavingsOpportunity,
        taxSavingsOpportunityFormatted: this.formatCurrency(taxSavingsOpportunity),
        complianceScore: compScore,
        riskScore: riskStats.overallRisk,
      },
      charts: {
        revenueVsExpenses: this.getRevenueVsExpensesChart(comp.id),
        taxLiabilityTrend: this.getTaxLiabilityTrendChart(comp.id),
        effectiveTaxRateTrend: this.getEffectiveTaxRateTrendChart(comp.id),
        historicalVsForecast: this.getForecastComparisonChart(comp.id),
        taxDistribution: [
          { name: 'Corporate Tax', value: 68, amount: Math.round(estimatedTax * 0.68), color: '#3B82F6' },
          { name: 'GST Remittance', value: 20, amount: Math.round(estimatedTax * 0.20), color: '#10B981' },
          { name: 'Payroll TDS', value: 8, amount: Math.round(estimatedTax * 0.08), color: '#6366F1' },
          { name: 'Other Statutory', value: 4, amount: Math.round(estimatedTax * 0.04), color: '#F59E0B' },
        ],
        riskOverview: [
          { severity: 'Critical', count: riskStats.criticalCount, color: '#EF4444' },
          { severity: 'High', count: riskStats.highCount, color: '#F97316' },
          { severity: 'Medium', count: riskStats.mediumCount, color: '#FBBF24' },
          { severity: 'Low', count: riskStats.lowCount, color: '#10B981' },
        ],
      },
    };
  }

  private calculateComplianceScore(companyId: string): number {
    const items = this.complianceItems.filter((i) => i.companyId === companyId);
    if (!items.length) return 92;
    const completed = items.filter((i) => i.status === 'Completed').length;
    const underReview = items.filter((i) => i.status === 'Under Review').length;
    const overdue = items.filter((i) => i.status === 'Overdue').length;

    const rawScore = (completed * 100 + underReview * 70 - overdue * 40) / items.length;
    return Math.min(100, Math.max(0, Math.round(rawScore)));
  }

  public getRiskStats(companyId: string) {
    const risks = this.taxRisks.filter((r) => r.companyId === companyId);
    const critical = risks.filter((r) => r.severity === 'Critical');
    const high = risks.filter((r) => r.severity === 'High');
    const medium = risks.filter((r) => r.severity === 'Medium');
    const low = risks.filter((r) => r.severity === 'Low');

    let overallRisk: 'Low' | 'Medium' | 'High' | 'Critical' = 'Low';
    if (critical.length > 0) overallRisk = 'Critical';
    else if (high.length > 0) overallRisk = 'High';
    else if (medium.length >= 2) overallRisk = 'Medium';

    return {
      total: risks.length,
      criticalCount: critical.length,
      highCount: high.length,
      mediumCount: medium.length,
      lowCount: low.length,
      overallRisk,
      risks,
    };
  }

  private formatCurrency(val: number): string {
    if (val >= 10000000) {
      return `₹${(val / 10000000).toFixed(2)} Cr`;
    }
    if (val >= 100000) {
      return `₹${(val / 100000).toFixed(2)} L`;
    }
    return `₹${val.toLocaleString('en-IN')}`;
  }

  public getRevenueVsExpensesChart(companyId: string) {
    const hist = this.generateHistoricalData(companyId);
    return hist.map((d) => ({
      month: d.month,
      revenue: d.revenue,
      expenses: d.expenses,
      profit: d.profit,
    }));
  }

  public getTaxLiabilityTrendChart(companyId: string) {
    const hist = this.generateHistoricalData(companyId);
    return hist.map((d) => ({
      month: d.month,
      taxLiability: d.taxLiability,
      taxPaid: d.taxPaid,
    }));
  }

  public getEffectiveTaxRateTrendChart(companyId: string) {
    const hist = this.generateHistoricalData(companyId);
    return hist.map((d, i) => {
      // Small realistic fluctuations around 22.8% - 25.2%
      const rate = 22.5 + Math.sin(i * 0.8) * 1.8;
      return {
        month: d.month,
        effectiveRate: Number(rate.toFixed(2)),
        statutoryBenchmark: 25.17,
      };
    });
  }

  public getForecastComparisonChart(companyId: string) {
    const hist = this.generateHistoricalData(companyId).slice(-6);
    const forecast = this.taxForecasts.find((f) => f.companyId === companyId) || this.taxForecasts[0];

    const points: Array<{
      month: string;
      taxLiability?: number;
      forecastedLiability?: number;
      confidenceLower?: number;
      confidenceUpper?: number;
      type: 'historical' | 'forecast';
    }> = [];

    hist.forEach((h) => {
      points.push({
        month: h.month,
        taxLiability: h.taxLiability,
        type: 'historical',
      });
    });

    if (forecast && forecast.forecastData) {
      forecast.forecastData.forEach((f) => {
        points.push({
          month: f.month,
          forecastedLiability: f.forecastedTaxLiability,
          confidenceLower: f.confidenceLower,
          confidenceUpper: f.confidenceUpper,
          type: 'forecast',
        });
      });
    }

    return points;
  }

  // Transactions
  public getTransactions(params: {
    companyId: string;
    search?: string;
    category?: string;
    type?: string;
    page?: number;
    limit?: number;
  }) {
    let list = this.transactions.filter((t) => t.companyId === params.companyId);

    if (params.search) {
      const q = params.search.toLowerCase();
      list = list.filter(
        (t) =>
          t.description.toLowerCase().includes(q) ||
          t.referenceNo.toLowerCase().includes(q) ||
          t.category.toLowerCase().includes(q) ||
          t.taxCategory.toLowerCase().includes(q)
      );
    }

    if (params.category && params.category !== 'All') {
      list = list.filter((t) => t.category === params.category);
    }

    if (params.type && params.type !== 'All') {
      list = list.filter((t) => t.type === params.type);
    }

    list.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

    const page = params.page || 1;
    const limit = params.limit || 10;
    const total = list.length;
    const totalPages = Math.ceil(total / limit);
    const items = list.slice((page - 1) * limit, page * limit);

    // Monthly summary aggregation
    const monthlySummary: Record<string, { revenue: number; expense: number; tax: number }> = {};
    this.transactions
      .filter((t) => t.companyId === params.companyId)
      .forEach((t) => {
        const m = t.date.substring(0, 7); // YYYY-MM
        if (!monthlySummary[m]) {
          monthlySummary[m] = { revenue: 0, expense: 0, tax: 0 };
        }
        if (t.type === 'credit') {
          monthlySummary[m].revenue += t.amount;
        } else {
          monthlySummary[m].expense += t.amount;
        }
        monthlySummary[m].tax += t.taxAmount;
      });

    return {
      items,
      total,
      page,
      totalPages,
      monthlySummary,
    };
  }

  public createTransaction(data: Omit<Transaction, 'id'>): Transaction {
    const newTx: Transaction = {
      ...data,
      id: `tx_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    };
    this.transactions.unshift(newTx);
    return newTx;
  }

  public updateTransaction(id: string, updates: Partial<Transaction>): Transaction {
    const idx = this.transactions.findIndex((t) => t.id === id);
    if (idx === -1) throw new Error('Transaction not found.');
    this.transactions[idx] = { ...this.transactions[idx], ...updates };
    return this.transactions[idx];
  }

  public deleteTransaction(id: string): boolean {
    const idx = this.transactions.findIndex((t) => t.id === id);
    if (idx === -1) return false;
    this.transactions.splice(idx, 1);
    return true;
  }

  // Tax Calculations
  public saveTaxCalculation(calc: TaxCalculation): TaxCalculation {
    this.taxCalculations.unshift(calc);
    return calc;
  }

  public getTaxCalculations(companyId: string): TaxCalculation[] {
    return this.taxCalculations.filter((c) => c.companyId === companyId);
  }

  public deleteTaxCalculation(id: string): boolean {
    const idx = this.taxCalculations.findIndex((c) => c.id === id);
    if (idx === -1) return false;
    this.taxCalculations.splice(idx, 1);
    return true;
  }

  // Tax Scenarios
  public getTaxScenarios(companyId: string): TaxScenario[] {
    return this.taxScenarios.filter((s) => s.companyId === companyId);
  }

  public createTaxScenario(data: Omit<TaxScenario, 'id' | 'createdAt'>): TaxScenario {
    const newScen: TaxScenario = {
      ...data,
      id: `scen_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      createdAt: new Date().toISOString(),
    };
    this.taxScenarios.push(newScen);
    return newScen;
  }

  public duplicateTaxScenario(id: string): TaxScenario {
    const target = this.taxScenarios.find((s) => s.id === id);
    if (!target) throw new Error('Scenario not found');
    const copy: TaxScenario = {
      ...target,
      id: `scen_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      name: `${target.name} (Copy)`,
      createdAt: new Date().toISOString(),
    };
    this.taxScenarios.push(copy);
    return copy;
  }

  public updateTaxScenario(id: string, updates: Partial<TaxScenario>): TaxScenario {
    const idx = this.taxScenarios.findIndex((s) => s.id === id);
    if (idx === -1) throw new Error('Scenario not found');
    this.taxScenarios[idx] = { ...this.taxScenarios[idx], ...updates };
    return this.taxScenarios[idx];
  }

  public deleteTaxScenario(id: string): boolean {
    const idx = this.taxScenarios.findIndex((s) => s.id === id);
    if (idx === -1) return false;
    this.taxScenarios.splice(idx, 1);
    return true;
  }

  // Forecasts
  public getTaxForecast(companyId: string): TaxForecast | undefined {
    return this.taxForecasts.find((f) => f.companyId === companyId) || this.taxForecasts[0];
  }

  public saveTaxForecast(forecast: TaxForecast): TaxForecast {
    const idx = this.taxForecasts.findIndex((f) => f.companyId === forecast.companyId);
    if (idx !== -1) {
      this.taxForecasts[idx] = forecast;
    } else {
      this.taxForecasts.push(forecast);
    }
    return forecast;
  }

  // Compliance
  public getComplianceItems(companyId: string): ComplianceItem[] {
    return this.complianceItems.filter((c) => c.companyId === companyId);
  }

  public createComplianceItem(data: Omit<ComplianceItem, 'id'>): ComplianceItem {
    const newItem: ComplianceItem = {
      ...data,
      id: `comp_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    };
    this.complianceItems.push(newItem);
    return newItem;
  }

  public updateComplianceItem(id: string, updates: Partial<ComplianceItem>): ComplianceItem {
    const idx = this.complianceItems.findIndex((c) => c.id === id);
    if (idx === -1) throw new Error('Compliance item not found');
    this.complianceItems[idx] = { ...this.complianceItems[idx], ...updates };
    return this.complianceItems[idx];
  }

  public deleteComplianceItem(id: string): boolean {
    const idx = this.complianceItems.findIndex((c) => c.id === id);
    if (idx === -1) return false;
    this.complianceItems.splice(idx, 1);
    return true;
  }

  // Risks
  public getRisks(companyId: string): TaxRisk[] {
    return this.taxRisks.filter((r) => r.companyId === companyId);
  }

  public createRisk(data: Omit<TaxRisk, 'id' | 'riskScore' | 'severity' | 'detectedDate'>): TaxRisk {
    const score = data.probability * data.financialImpact;
    let severity: 'Low' | 'Medium' | 'High' | 'Critical' = 'Low';
    if (score >= 16) severity = 'Critical';
    else if (score >= 12) severity = 'High';
    else if (score >= 6) severity = 'Medium';

    const newRisk: TaxRisk = {
      ...data,
      id: `risk_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      riskScore: score,
      severity,
      detectedDate: new Date().toISOString().substring(0, 10),
    };
    this.taxRisks.push(newRisk);
    return newRisk;
  }

  public updateRisk(id: string, updates: Partial<TaxRisk>): TaxRisk {
    const idx = this.taxRisks.findIndex((r) => r.id === id);
    if (idx === -1) throw new Error('Tax risk not found');

    const prob = updates.probability ?? this.taxRisks[idx].probability;
    const impact = updates.financialImpact ?? this.taxRisks[idx].financialImpact;
    const score = prob * impact;

    let severity: 'Low' | 'Medium' | 'High' | 'Critical' = 'Low';
    if (score >= 16) severity = 'Critical';
    else if (score >= 12) severity = 'High';
    else if (score >= 6) severity = 'Medium';

    this.taxRisks[idx] = {
      ...this.taxRisks[idx],
      ...updates,
      riskScore: score,
      severity,
    };
    return this.taxRisks[idx];
  }

  public deleteRisk(id: string): boolean {
    const idx = this.taxRisks.findIndex((r) => r.id === id);
    if (idx === -1) return false;
    this.taxRisks.splice(idx, 1);
    return true;
  }

  // Audit
  public getAuditDocuments(companyId: string) {
    const docs = this.auditDocuments.filter((d) => d.companyId === companyId);
    const uploaded = docs.filter((d) => d.status === 'Uploaded').length;
    const needsReview = docs.filter((d) => d.status === 'Needs Review').length;
    const missing = docs.filter((d) => d.status === 'Missing').length;
    const readinessScore = docs.length > 0 ? Math.round(((uploaded * 1.0 + needsReview * 0.5) / docs.length) * 100) : 87;

    return {
      documents: docs,
      readinessScore,
      stats: {
        total: docs.length,
        uploaded,
        needsReview,
        missing,
      },
    };
  }

  public updateAuditDocument(id: string, updates: Partial<AuditDocument>): AuditDocument {
    const idx = this.auditDocuments.findIndex((d) => d.id === id);
    if (idx === -1) throw new Error('Audit document not found');
    this.auditDocuments[idx] = { ...this.auditDocuments[idx], ...updates };
    return this.auditDocuments[idx];
  }

  // Reports
  public getReports(companyId: string): Report[] {
    return this.reports.filter((r) => r.companyId === companyId);
  }

  public createReport(data: Omit<Report, 'id' | 'generatedDate'>): Report {
    const newReport: Report = {
      ...data,
      id: `rep_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      generatedDate: new Date().toISOString(),
    };
    this.reports.unshift(newReport);
    return newReport;
  }

  // Notifications
  public getNotifications(companyId: string): Notification[] {
    return this.notifications.filter((n) => n.companyId === companyId || !n.companyId);
  }

  public markNotificationAsRead(id: string): boolean {
    const notif = this.notifications.find((n) => n.id === id);
    if (notif) {
      notif.isRead = true;
      return true;
    }
    return false;
  }

  public markAllNotificationsAsRead(companyId: string) {
    this.notifications.forEach((n) => {
      if (n.companyId === companyId || !n.companyId) {
        n.isRead = true;
      }
    });
  }

  // Global Search (Ctrl + K)
  public globalSearch(query: string, companyId: string) {
    const q = query.toLowerCase().trim();
    if (!q) return [];

    const results: Array<{
      id: string;
      type: 'Company' | 'Transaction' | 'Compliance' | 'Risk' | 'Report';
      title: string;
      subtitle: string;
      link: string;
    }> = [];

    // Companies
    this.companies.forEach((c) => {
      if (c.name.toLowerCase().includes(q) || c.pan.toLowerCase().includes(q) || c.gstin.toLowerCase().includes(q)) {
        results.push({
          id: c.id,
          type: 'Company',
          title: c.name,
          subtitle: `${c.industry} · PAN: ${c.pan}`,
          link: `/companies`,
        });
      }
    });

    // Transactions
    this.transactions
      .filter((t) => t.companyId === companyId)
      .forEach((t) => {
        if (
          t.description.toLowerCase().includes(q) ||
          t.referenceNo.toLowerCase().includes(q) ||
          t.category.toLowerCase().includes(q)
        ) {
          results.push({
            id: t.id,
            type: 'Transaction',
            title: t.description,
            subtitle: `${t.category} · ₹${t.amount.toLocaleString('en-IN')} · Ref: ${t.referenceNo}`,
            link: `/transactions`,
          });
        }
      });

    // Compliance
    this.complianceItems
      .filter((c) => c.companyId === companyId)
      .forEach((c) => {
        if (c.title.toLowerCase().includes(q) || c.category.toLowerCase().includes(q) || c.owner.toLowerCase().includes(q)) {
          results.push({
            id: c.id,
            type: 'Compliance',
            title: c.title,
            subtitle: `Due: ${c.dueDate} · Status: ${c.status} · Priority: ${c.priority}`,
            link: `/compliance`,
          });
        }
      });

    // Risks
    this.taxRisks
      .filter((r) => r.companyId === companyId)
      .forEach((r) => {
        if (r.riskName.toLowerCase().includes(q) || r.category.toLowerCase().includes(q) || r.description.toLowerCase().includes(q)) {
          results.push({
            id: r.id,
            type: 'Risk',
            title: r.riskName,
            subtitle: `Severity: ${r.severity} · Category: ${r.category} · Score: ${r.riskScore}`,
            link: `/risk-assessment`,
          });
        }
      });

    // Reports
    this.reports
      .filter((r) => r.companyId === companyId)
      .forEach((r) => {
        if (r.title.toLowerCase().includes(q) || r.reportType.toLowerCase().includes(q) || r.summary.toLowerCase().includes(q)) {
          results.push({
            id: r.id,
            type: 'Report',
            title: r.title,
            subtitle: `${r.reportType} Report · ${r.financialYear}`,
            link: `/reports`,
          });
        }
      });

    return results.slice(0, 15);
  }

  // Tax Configuration
  public getTaxConfig(): TaxConfiguration {
    return { ...this.taxConfig };
  }

  public updateTaxConfig(updates: Partial<TaxConfiguration>): TaxConfiguration {
    this.taxConfig = {
      ...this.taxConfig,
      ...updates,
      lastUpdated: new Date().toISOString().substring(0, 10),
    };
    return { ...this.taxConfig };
  }
}

export const store = new MemoryStore();
