import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/common/Navbar';
import { Sidebar } from './components/common/Sidebar';
import { ToastContainer } from './components/common/ToastContainer';
import { GlobalSearchModal } from './components/common/GlobalSearchModal';
import { LandingPage } from './pages/LandingPage';
import { AuthModal } from './pages/AuthModal';

// Pages
import { DashboardPage } from './pages/DashboardPage';
import { CompaniesPage } from './pages/CompaniesPage';
import { CalculatorPage } from './pages/CalculatorPage';
import { PlanningPage } from './pages/PlanningPage';
import { ForecastingPage } from './pages/ForecastingPage';
import { CompliancePage } from './pages/CompliancePage';
import { RiskAssessmentPage } from './pages/RiskAssessmentPage';
import { AuditCenterPage } from './pages/AuditCenterPage';
import { TaxEfficiencyPage } from './pages/TaxEfficiencyPage';
import { TransactionsPage } from './pages/TransactionsPage';
import { ReportsPage } from './pages/ReportsPage';
import { AnalyticsPage } from './pages/AnalyticsPage';
import { SettingsPage } from './pages/SettingsPage';

function AppContent() {
  const { isAuthenticated, loginAsDemo } = useApp();
  const [currentPage, setCurrentPage] = useState<string>('overview');
  const [showLanding, setShowLanding] = useState<boolean>(!isAuthenticated);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  // If user logs in, dismiss landing page
  React.useEffect(() => {
    if (isAuthenticated) {
      setShowLanding(false);
    }
  }, [isAuthenticated]);

  const handleStartAnalysis = async () => {
    if (!isAuthenticated) {
      await loginAsDemo();
    }
    setShowLanding(false);
    setCurrentPage('calculator');
  };

  const handleOpenAuth = (mode: 'login' | 'register') => {
    setAuthMode(mode);
    setAuthModalOpen(true);
  };

  const handleNavigateDirect = async (page: string) => {
    if (!isAuthenticated) {
      await loginAsDemo();
    }
    setShowLanding(false);
    setCurrentPage(page);
  };

  if (showLanding && !isAuthenticated) {
    return (
      <>
        <LandingPage
          onStart={handleStartAnalysis}
          onOpenAuth={handleOpenAuth}
          onNavigateDirect={handleNavigateDirect}
        />
        <AuthModal
          isOpen={authModalOpen}
          onClose={() => setAuthModalOpen(false)}
          defaultMode={authMode}
        />
        <ToastContainer />
      </>
    );
  }

  const renderActivePage = () => {
    switch (currentPage) {
      case 'overview':
        return <DashboardPage onNavigate={setCurrentPage} />;
      case 'companies':
        return <CompaniesPage onNavigate={setCurrentPage} />;
      case 'calculator':
        return <CalculatorPage onNavigate={setCurrentPage} />;
      case 'planning':
        return <PlanningPage />;
      case 'forecasting':
        return <ForecastingPage onNavigate={setCurrentPage} />;
      case 'compliance':
        return <CompliancePage />;
      case 'risk-assessment':
        return <RiskAssessmentPage />;
      case 'audit-center':
        return <AuditCenterPage onNavigate={setCurrentPage} />;
      case 'tax-efficiency':
        return <TaxEfficiencyPage />;
      case 'transactions':
        return <TransactionsPage />;
      case 'reports':
        return <ReportsPage />;
      case 'analytics':
        return <AnalyticsPage />;
      case 'settings':
        return <SettingsPage />;
      default:
        return <DashboardPage onNavigate={setCurrentPage} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50/60 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex transition-colors">
      {/* Sidebar */}
      <Sidebar
        activePage={currentPage}
        onNavigate={setCurrentPage}
        collapsed={sidebarCollapsed}
        onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
        mobileOpen={mobileSidebarOpen}
        onCloseMobile={() => setMobileSidebarOpen(false)}
      />

      {/* Main Viewport Content Area */}
      <div
        className={`flex-1 flex flex-col min-w-0 transition-all duration-300 ${
          sidebarCollapsed ? 'md:ml-20' : 'md:ml-64'
        }`}
      >
        {/* Top Navbar */}
        <Navbar
          onNavigate={setCurrentPage}
          onOpenAddCompany={() => setCurrentPage('companies')}
          onToggleSidebar={() => setMobileSidebarOpen(!mobileSidebarOpen)}
        />

        {/* Dynamic Page Content */}
        <main className="flex-1 p-4 md:p-8 max-w-7xl w-full mx-auto">
          {renderActivePage()}
        </main>
      </div>

      {/* Global Search Palette (Ctrl + K) */}
      <GlobalSearchModal onNavigate={setCurrentPage} />

      {/* Toast Notification Stack */}
      <ToastContainer />

      {/* Auth Modal */}
      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        defaultMode={authMode}
      />
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
