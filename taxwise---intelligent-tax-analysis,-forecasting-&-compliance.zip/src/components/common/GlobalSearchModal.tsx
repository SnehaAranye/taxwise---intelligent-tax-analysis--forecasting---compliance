import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { api } from '../../services/api';
import { SearchResult } from '../../types';
import { Search, X, Building2, Receipt, CalendarCheck, ShieldAlert, FileText, ArrowRight } from 'lucide-react';

interface GlobalSearchModalProps {
  onNavigate: (page: string) => void;
}

export const GlobalSearchModal: React.FC<GlobalSearchModalProps> = ({ onNavigate }) => {
  const { isSearchOpen, setIsSearchOpen, selectedCompanyId } = useApp();
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [loading, setLoading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isSearchOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    } else {
      setQuery('');
      setResults([]);
    }
  }, [isSearchOpen]);

  useEffect(() => {
    if (!query.trim()) {
      setResults([]);
      return;
    }

    const timer = setTimeout(async () => {
      setLoading(true);
      try {
        const data = await api.search(query, selectedCompanyId);
        setResults(data);
      } catch (err) {
        console.error('Search error:', err);
      } finally {
        setLoading(false);
      }
    }, 200);

    return () => clearTimeout(timer);
  }, [query, selectedCompanyId]);

  if (!isSearchOpen) return null;

  const handleSelectResult = (link: string) => {
    setIsSearchOpen(false);
    // map link to page name
    const page = link.replace('/', '') || 'overview';
    onNavigate(page);
  };

  const getResultIcon = (type: SearchResult['type']) => {
    switch (type) {
      case 'Company':
        return <Building2 className="w-4 h-4 text-blue-500" />;
      case 'Transaction':
        return <Receipt className="w-4 h-4 text-emerald-500" />;
      case 'Compliance':
        return <CalendarCheck className="w-4 h-4 text-indigo-500" />;
      case 'Risk':
        return <ShieldAlert className="w-4 h-4 text-amber-500" />;
      case 'Report':
        return <FileText className="w-4 h-4 text-purple-500" />;
      default:
        return <Search className="w-4 h-4 text-slate-400" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 px-4 bg-slate-950/50 backdrop-blur-xs">
      <div
        className="w-full max-w-2xl bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden transition-all"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Input Bar */}
        <div className="flex items-center gap-3 px-4 py-3.5 border-b border-slate-200 dark:border-slate-800">
          <Search className="w-5 h-5 text-slate-400" />
          <input
            ref={inputRef}
            type="text"
            placeholder="Search across companies, transactions, compliance, risks, and reports..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="flex-1 bg-transparent text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <kbd className="hidden sm:inline-block px-2 py-0.5 text-[11px] font-medium text-slate-400 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded">
            ESC
          </kbd>
        </div>

        {/* Results Area */}
        <div className="max-h-96 overflow-y-auto p-2">
          {loading ? (
            <div className="py-12 text-center text-sm text-slate-400">Searching records...</div>
          ) : results.length > 0 ? (
            <div className="space-y-1">
              {results.map((res) => (
                <button
                  key={`${res.type}_${res.id}`}
                  onClick={() => handleSelectResult(res.link)}
                  className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800/70 text-left transition-colors group cursor-pointer"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="p-2 rounded-lg bg-slate-100 dark:bg-slate-800 shrink-0">
                      {getResultIcon(res.type)}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-semibold text-slate-800 dark:text-slate-200 truncate">
                          {res.title}
                        </span>
                        <span className="text-[11px] text-slate-400 dark:text-slate-500 uppercase tracking-wider">
                          · {res.type}
                        </span>
                      </div>
                      <div className="text-xs text-slate-500 dark:text-slate-400 truncate">
                        {res.subtitle}
                      </div>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-slate-300 dark:text-slate-600 group-hover:text-blue-500 group-hover:translate-x-0.5 transition-all shrink-0 ml-2" />
                </button>
              ))}
            </div>
          ) : query ? (
            <div className="py-12 text-center text-sm text-slate-400">
              No matching records found for "{query}".
            </div>
          ) : (
            <div className="py-8 px-4 text-xs text-slate-400 text-center space-y-2">
              <p>Type to search across corporate entities, transactions, tax filings, and audit records.</p>
              <div className="flex flex-wrap justify-center gap-2 pt-2">
                <span className="px-2 py-1 bg-slate-100 dark:bg-slate-800 rounded text-slate-600 dark:text-slate-300">
                  Advance Tax
                </span>
                <span className="px-2 py-1 bg-slate-100 dark:bg-slate-800 rounded text-slate-600 dark:text-slate-300">
                  GSTR-3B
                </span>
                <span className="px-2 py-1 bg-slate-100 dark:bg-slate-800 rounded text-slate-600 dark:text-slate-300">
                  Transfer Pricing
                </span>
                <span className="px-2 py-1 bg-slate-100 dark:bg-slate-800 rounded text-slate-600 dark:text-slate-300">
                  Apex Tech
                </span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
