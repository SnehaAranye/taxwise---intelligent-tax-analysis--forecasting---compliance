import React, { useState } from 'react';

// Format currency in Indian lakhs/crores
const formatIndianCurr = (val: number): string => {
  if (val >= 10000000) return `₹${(val / 10000000).toFixed(2)} Cr`;
  if (val >= 100000) return `₹${(val / 100000).toFixed(2)} L`;
  return `₹${val.toLocaleString('en-IN')}`;
};

// ==================== 1. REVENUE VS EXPENSES AREA/LINE CHART ====================

interface RevenueExpensesProps {
  data: Array<{ month: string; revenue: number; expenses: number; profit: number }>;
}

export const RevenueExpensesChart: React.FC<RevenueExpensesProps> = ({ data }) => {
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);

  if (!data || data.length === 0) {
    return <div className="h-64 flex items-center justify-center text-xs text-slate-400">No financial data available</div>;
  }

  const height = 240;
  const width = 600;
  const padding = { top: 20, right: 20, bottom: 35, left: 55 };

  const maxVal = Math.max(...data.map((d) => Math.max(d.revenue, d.expenses))) * 1.15;
  const chartW = width - padding.left - padding.right;
  const chartH = height - padding.top - padding.bottom;

  const getX = (idx: number) => padding.left + (idx / (data.length - 1)) * chartW;
  const getY = (val: number) => padding.top + chartH - (val / maxVal) * chartH;

  // Build SVG path strings
  const revPoints = data.map((d, i) => `${getX(i)},${getY(d.revenue)}`).join(' ');
  const expPoints = data.map((d, i) => `${getX(i)},${getY(d.expenses)}`).join(' ');

  const revAreaPath = `${data.map((d, i) => `${i === 0 ? 'M' : 'L'} ${getX(i)} ${getY(d.revenue)}`).join(' ')} L ${getX(data.length - 1)} ${padding.top + chartH} L ${getX(0)} ${padding.top + chartH} Z`;

  return (
    <div className="relative w-full overflow-hidden">
      <div className="flex items-center justify-between mb-3 text-xs">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-xs bg-blue-600 inline-block" />
            <span className="font-medium text-slate-600 dark:text-slate-300">Revenue</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-xs bg-slate-400 dark:bg-slate-500 inline-block" />
            <span className="font-medium text-slate-600 dark:text-slate-300">Expenses</span>
          </div>
        </div>
        {hoveredIdx !== null && (
          <div className="text-right text-[11px] font-mono-numbers text-slate-700 dark:text-slate-300">
            {data[hoveredIdx].month} · Rev: {formatIndianCurr(data[hoveredIdx].revenue)} · Exp: {formatIndianCurr(data[hoveredIdx].expenses)}
          </div>
        )}
      </div>

      <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto overflow-visible select-none">
        <defs>
          <linearGradient id="revGradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#3B82F6" stopOpacity="0.25" />
            <stop offset="100%" stopColor="#3B82F6" stopOpacity="0.0" />
          </linearGradient>
        </defs>

        {/* Horizontal grid lines */}
        {[0, 0.25, 0.5, 0.75, 1].map((ratio, i) => {
          const y = padding.top + chartH * (1 - ratio);
          const val = maxVal * ratio;
          return (
            <g key={i}>
              <line
                x1={padding.left}
                y1={y}
                x2={width - padding.right}
                y2={y}
                stroke="currentColor"
                className="text-slate-200 dark:text-slate-800"
                strokeDasharray="3 3"
                strokeWidth="1"
              />
              <text
                x={padding.left - 8}
                y={y + 3}
                textAnchor="end"
                className="text-[9px] fill-slate-400 dark:fill-slate-500 font-mono-numbers"
              >
                {formatIndianCurr(val)}
              </text>
            </g>
          );
        })}

        {/* Shaded area under revenue */}
        <path d={revAreaPath} fill="url(#revGradient)" />

        {/* Expenses Line */}
        <polyline
          fill="none"
          stroke="#94A3B8"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          points={expPoints}
        />

        {/* Revenue Line */}
        <polyline
          fill="none"
          stroke="#2563EB"
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeLinejoin="round"
          points={revPoints}
        />

        {/* X Axis Labels */}
        {data.map((d, i) => {
          if (i % Math.ceil(data.length / 6) !== 0 && i !== data.length - 1) return null;
          return (
            <text
              key={i}
              x={getX(i)}
              y={height - 10}
              textAnchor="middle"
              className="text-[10px] fill-slate-400 dark:fill-slate-500 font-mono-numbers"
            >
              {d.month.split(' ')[0]}
            </text>
          );
        })}

        {/* Interactive Hover Points */}
        {data.map((d, i) => {
          const isHovered = hoveredIdx === i;
          return (
            <g key={i} onMouseEnter={() => setHoveredIdx(i)} onMouseLeave={() => setHoveredIdx(null)} className="cursor-pointer">
              <rect
                x={getX(i) - 10}
                y={padding.top}
                width={20}
                height={chartH}
                fill="transparent"
              />
              {isHovered && (
                <>
                  <line
                    x1={getX(i)}
                    y1={padding.top}
                    x2={getX(i)}
                    y2={padding.top + chartH}
                    stroke="#3B82F6"
                    strokeWidth="1"
                    strokeDasharray="2 2"
                  />
                  <circle cx={getX(i)} cy={getY(d.revenue)} r="4.5" fill="#2563EB" stroke="#FFFFFF" strokeWidth="2" />
                  <circle cx={getX(i)} cy={getY(d.expenses)} r="4" fill="#94A3B8" stroke="#FFFFFF" strokeWidth="2" />
                </>
              )}
            </g>
          );
        })}
      </svg>
    </div>
  );
};

// ==================== 2. TAX LIABILITY TREND (MONTHLY BARS) ====================

interface TaxLiabilityProps {
  data: Array<{ month: string; taxLiability: number; taxPaid: number }>;
}

export const TaxLiabilityTrendChart: React.FC<TaxLiabilityProps> = ({ data }) => {
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);

  if (!data || data.length === 0) return null;

  const height = 240;
  const width = 600;
  const padding = { top: 20, right: 20, bottom: 35, left: 55 };

  const maxVal = Math.max(...data.map((d) => Math.max(d.taxLiability, d.taxPaid))) * 1.2;
  const chartW = width - padding.left - padding.right;
  const chartH = height - padding.top - padding.bottom;
  const barGroupWidth = chartW / data.length;
  const barWidth = Math.min(14, barGroupWidth * 0.35);

  const getY = (val: number) => padding.top + chartH - (val / maxVal) * chartH;

  return (
    <div className="relative w-full overflow-hidden">
      <div className="flex items-center justify-between mb-3 text-xs">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-xs bg-indigo-600 inline-block" />
            <span className="font-medium text-slate-600 dark:text-slate-300">Computed Liability</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-xs bg-emerald-500 inline-block" />
            <span className="font-medium text-slate-600 dark:text-slate-300">Advance/TDS Paid</span>
          </div>
        </div>
        {hoveredIdx !== null && (
          <div className="text-right text-[11px] font-mono-numbers text-slate-700 dark:text-slate-300">
            {data[hoveredIdx].month} · Liability: {formatIndianCurr(data[hoveredIdx].taxLiability)} · Paid: {formatIndianCurr(data[hoveredIdx].taxPaid)}
          </div>
        )}
      </div>

      <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto select-none">
        {/* Horizontal grid lines */}
        {[0, 0.33, 0.66, 1].map((ratio, i) => {
          const y = padding.top + chartH * (1 - ratio);
          const val = maxVal * ratio;
          return (
            <g key={i}>
              <line
                x1={padding.left}
                y1={y}
                x2={width - padding.right}
                y2={y}
                stroke="currentColor"
                className="text-slate-200 dark:text-slate-800"
                strokeDasharray="3 3"
                strokeWidth="1"
              />
              <text
                x={padding.left - 8}
                y={y + 3}
                textAnchor="end"
                className="text-[9px] fill-slate-400 dark:fill-slate-500 font-mono-numbers"
              >
                {formatIndianCurr(val)}
              </text>
            </g>
          );
        })}

        {/* Bars */}
        {data.map((d, i) => {
          const groupCenter = padding.left + i * barGroupWidth + barGroupWidth / 2;
          const liabX = groupCenter - barWidth - 1;
          const paidX = groupCenter + 1;

          const liabH = Math.max(2, (d.taxLiability / maxVal) * chartH);
          const paidH = Math.max(2, (d.taxPaid / maxVal) * chartH);

          const isHovered = hoveredIdx === i;

          return (
            <g key={i} onMouseEnter={() => setHoveredIdx(i)} onMouseLeave={() => setHoveredIdx(null)} className="cursor-pointer">
              {/* Computed Liability Bar */}
              <rect
                x={liabX}
                y={getY(d.taxLiability)}
                width={barWidth}
                height={liabH}
                rx="2"
                fill="#4F46E5"
                opacity={isHovered ? 1 : 0.85}
              />
              {/* Advance Paid Bar */}
              <rect
                x={paidX}
                y={getY(d.taxPaid)}
                width={barWidth}
                height={paidH}
                rx="2"
                fill="#10B981"
                opacity={isHovered ? 1 : 0.85}
              />
              {/* X Axis Label */}
              <text
                x={groupCenter}
                y={height - 12}
                textAnchor="middle"
                className={`text-[9px] font-mono-numbers ${
                  isHovered ? 'fill-blue-600 font-bold' : 'fill-slate-400 dark:fill-slate-500'
                }`}
              >
                {d.month.split(' ')[0]}
              </text>
            </g>
          );
        })}
      </svg>
    </div>
  );
};

// ==================== 3. EFFECTIVE TAX RATE LINE CHART ====================

interface ETRChartProps {
  data: Array<{ month: string; effectiveRate: number; statutoryBenchmark: number }>;
}

export const EffectiveTaxRateChart: React.FC<ETRChartProps> = ({ data }) => {
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);

  if (!data || data.length === 0) return null;

  const height = 240;
  const width = 600;
  const padding = { top: 20, right: 20, bottom: 35, left: 45 };

  const minVal = 18;
  const maxVal = 28;
  const chartW = width - padding.left - padding.right;
  const chartH = height - padding.top - padding.bottom;

  const getX = (idx: number) => padding.left + (idx / (data.length - 1)) * chartW;
  const getY = (val: number) => padding.top + chartH - ((val - minVal) / (maxVal - minVal)) * chartH;

  const points = data.map((d, i) => `${getX(i)},${getY(d.effectiveRate)}`).join(' ');
  const benchmarkY = getY(25.17);

  return (
    <div className="relative w-full overflow-hidden">
      <div className="flex items-center justify-between mb-3 text-xs">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-0.5 bg-blue-600 inline-block" />
            <span className="font-medium text-slate-600 dark:text-slate-300">Effective Tax Rate (ETR)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-0.5 bg-rose-500 border-dashed inline-block" />
            <span className="font-medium text-slate-600 dark:text-slate-300">Statutory Benchmark (25.17%)</span>
          </div>
        </div>
        {hoveredIdx !== null && (
          <div className="text-right text-[11px] font-mono-numbers text-slate-700 dark:text-slate-300">
            {data[hoveredIdx].month} · ETR: {data[hoveredIdx].effectiveRate}%
          </div>
        )}
      </div>

      <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto select-none">
        {/* Horizontal grid lines */}
        {[20, 22, 24, 26, 28].map((rate) => {
          const y = getY(rate);
          return (
            <g key={rate}>
              <line
                x1={padding.left}
                y1={y}
                x2={width - padding.right}
                y2={y}
                stroke="currentColor"
                className="text-slate-200 dark:text-slate-800"
                strokeDasharray="3 3"
                strokeWidth="1"
              />
              <text
                x={padding.left - 6}
                y={y + 3}
                textAnchor="end"
                className="text-[9px] fill-slate-400 dark:fill-slate-500 font-mono-numbers"
              >
                {rate}%
              </text>
            </g>
          );
        })}

        {/* Benchmark line (25.17%) */}
        <line
          x1={padding.left}
          y1={benchmarkY}
          x2={width - padding.right}
          y2={benchmarkY}
          stroke="#EF4444"
          strokeWidth="1.5"
          strokeDasharray="4 4"
        />

        {/* ETR Curve */}
        <polyline
          fill="none"
          stroke="#2563EB"
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeLinejoin="round"
          points={points}
        />

        {/* X Axis Labels */}
        {data.map((d, i) => {
          if (i % Math.ceil(data.length / 6) !== 0 && i !== data.length - 1) return null;
          return (
            <text
              key={i}
              x={getX(i)}
              y={height - 10}
              textAnchor="middle"
              className="text-[10px] fill-slate-400 dark:fill-slate-500 font-mono-numbers"
            >
              {d.month.split(' ')[0]}
            </text>
          );
        })}

        {/* Interactive Dots */}
        {data.map((d, i) => (
          <circle
            key={i}
            cx={getX(i)}
            cy={getY(d.effectiveRate)}
            r={hoveredIdx === i ? 5 : 3.5}
            fill="#2563EB"
            stroke="#FFFFFF"
            strokeWidth="2"
            className="cursor-pointer transition-all"
            onMouseEnter={() => setHoveredIdx(i)}
            onMouseLeave={() => setHoveredIdx(null)}
          />
        ))}
      </svg>
    </div>
  );
};

// ==================== 4. TAX FORECAST COMPARISON (HISTORICAL VS FORECAST) ====================

interface ForecastComparisonProps {
  data: Array<{
    month: string;
    taxLiability?: number;
    forecastedLiability?: number;
    confidenceLower?: number;
    confidenceUpper?: number;
    type: 'historical' | 'forecast';
  }>;
}

export const ForecastComparisonChart: React.FC<ForecastComparisonProps> = ({ data }) => {
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);

  if (!data || data.length === 0) return null;

  const height = 240;
  const width = 600;
  const padding = { top: 20, right: 20, bottom: 35, left: 55 };

  const allValues = data.flatMap((d) => [
    d.taxLiability || 0,
    d.forecastedLiability || 0,
    d.confidenceUpper || 0,
  ]);
  const maxVal = Math.max(...allValues) * 1.2;
  const chartW = width - padding.left - padding.right;
  const chartH = height - padding.top - padding.bottom;

  const getX = (idx: number) => padding.left + (idx / (data.length - 1)) * chartW;
  const getY = (val: number) => padding.top + chartH - (val / maxVal) * chartH;

  const historicalItems = data.filter((d) => d.type === 'historical');
  const forecastItems = data.filter((d) => d.type === 'forecast');

  // Connection point between historical and forecast
  const lastHistIdx = historicalItems.length - 1;
  const bridgeItem = historicalItems[lastHistIdx];

  const histPoints = historicalItems.map((_, i) => `${getX(i)},${getY(historicalItems[i].taxLiability || 0)}`).join(' ');

  const forecastPoints = [
    `${getX(lastHistIdx)},${getY(bridgeItem.taxLiability || 0)}`,
    ...forecastItems.map((d, i) => `${getX(lastHistIdx + 1 + i)},${getY(d.forecastedLiability || 0)}`),
  ].join(' ');

  // Confidence Envelope Path
  const upperPath = forecastItems.map((d, i) => `${getX(lastHistIdx + 1 + i)},${getY(d.confidenceUpper || 0)}`);
  const lowerPath = forecastItems.slice().reverse().map((d, i) => {
    const origIdx = lastHistIdx + 1 + (forecastItems.length - 1 - i);
    return `${getX(origIdx)},${getY(d.confidenceLower || 0)}`;
  });

  const envelopeD = `M ${getX(lastHistIdx)} ${getY(bridgeItem.taxLiability || 0)} L ${upperPath.join(' L ')} L ${lowerPath.join(' L ')} Z`;

  return (
    <div className="relative w-full overflow-hidden">
      <div className="flex items-center justify-between mb-3 text-xs">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-0.5 bg-blue-600 inline-block" />
            <span className="font-medium text-slate-600 dark:text-slate-300">Historical Solid</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-0.5 border-t-2 border-dashed border-indigo-600 inline-block" />
            <span className="font-medium text-slate-600 dark:text-slate-300">Forecast Dashed</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 bg-indigo-100 dark:bg-indigo-950/60 inline-block rounded-xs" />
            <span className="font-medium text-slate-600 dark:text-slate-300">95% Confidence</span>
          </div>
        </div>
        {hoveredIdx !== null && (
          <div className="text-right text-[11px] font-mono-numbers text-slate-700 dark:text-slate-300">
            {data[hoveredIdx].month} ·{' '}
            {data[hoveredIdx].type === 'historical'
              ? `Actual: ${formatIndianCurr(data[hoveredIdx].taxLiability || 0)}`
              : `Proj: ${formatIndianCurr(data[hoveredIdx].forecastedLiability || 0)}`}
          </div>
        )}
      </div>

      <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto select-none">
        {/* Horizontal grid lines */}
        {[0, 0.33, 0.66, 1].map((ratio, i) => {
          const y = padding.top + chartH * (1 - ratio);
          const val = maxVal * ratio;
          return (
            <g key={i}>
              <line
                x1={padding.left}
                y1={y}
                x2={width - padding.right}
                y2={y}
                stroke="currentColor"
                className="text-slate-200 dark:text-slate-800"
                strokeDasharray="3 3"
                strokeWidth="1"
              />
              <text
                x={padding.left - 8}
                y={y + 3}
                textAnchor="end"
                className="text-[9px] fill-slate-400 dark:fill-slate-500 font-mono-numbers"
              >
                {formatIndianCurr(val)}
              </text>
            </g>
          );
        })}

        {/* Confidence Area */}
        <path d={envelopeD} fill="#818CF8" fillOpacity="0.18" />

        {/* Historical Line */}
        <polyline
          fill="none"
          stroke="#2563EB"
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeLinejoin="round"
          points={histPoints}
        />

        {/* Forecast Dashed Line */}
        <polyline
          fill="none"
          stroke="#6366F1"
          strokeWidth="2.5"
          strokeDasharray="5 4"
          strokeLinecap="round"
          strokeLinejoin="round"
          points={forecastPoints}
        />

        {/* Transition Divider */}
        <line
          x1={getX(lastHistIdx)}
          y1={padding.top}
          x2={getX(lastHistIdx)}
          y2={padding.top + chartH}
          stroke="#94A3B8"
          strokeWidth="1"
          strokeDasharray="2 2"
        />

        {/* X Axis Labels */}
        {data.map((d, i) => {
          if (i % Math.ceil(data.length / 7) !== 0 && i !== data.length - 1) return null;
          return (
            <text
              key={i}
              x={getX(i)}
              y={height - 10}
              textAnchor="middle"
              className="text-[10px] fill-slate-400 dark:fill-slate-500 font-mono-numbers"
            >
              {d.month.split(' ')[0]}
            </text>
          );
        })}

        {/* Interactive Points */}
        {data.map((d, i) => {
          const val = d.type === 'historical' ? d.taxLiability || 0 : d.forecastedLiability || 0;
          const isHovered = hoveredIdx === i;
          return (
            <circle
              key={i}
              cx={getX(i)}
              cy={getY(val)}
              r={isHovered ? 5 : 3.5}
              fill={d.type === 'historical' ? '#2563EB' : '#6366F1'}
              stroke="#FFFFFF"
              strokeWidth="2"
              className="cursor-pointer transition-all"
              onMouseEnter={() => setHoveredIdx(i)}
              onMouseLeave={() => setHoveredIdx(null)}
            />
          );
        })}
      </svg>
    </div>
  );
};

// ==================== 5. TAX DISTRIBUTION DONUT CHART ====================

interface TaxDistributionProps {
  data: Array<{ name: string; value: number; amount: number; color: string }>;
}

export const TaxDistributionDonut: React.FC<TaxDistributionProps> = ({ data }) => {
  const [hoveredSlice, setHoveredSlice] = useState<number | null>(null);

  if (!data || data.length === 0) return null;

  const size = 180;
  const center = size / 2;
  const radius = 68;
  const innerRadius = 46;

  let cumulativeAngle = 0;

  return (
    <div className="flex flex-col sm:flex-row items-center gap-6">
      <div className="relative w-44 h-44 shrink-0">
        <svg viewBox={`0 0 ${size} ${size}`} className="w-full h-full transform -rotate-90">
          {data.map((slice, i) => {
            const sliceAngle = (slice.value / 100) * 360;
            const startAngle = cumulativeAngle;
            const endAngle = cumulativeAngle + sliceAngle;
            cumulativeAngle += sliceAngle;

            const x1 = center + radius * Math.cos((Math.PI * startAngle) / 180);
            const y1 = center + radius * Math.sin((Math.PI * startAngle) / 180);
            const x2 = center + radius * Math.cos((Math.PI * endAngle) / 180);
            const y2 = center + radius * Math.sin((Math.PI * endAngle) / 180);

            const x3 = center + innerRadius * Math.cos((Math.PI * endAngle) / 180);
            const y3 = center + innerRadius * Math.sin((Math.PI * endAngle) / 180);
            const x4 = center + innerRadius * Math.cos((Math.PI * startAngle) / 180);
            const y4 = center + innerRadius * Math.sin((Math.PI * startAngle) / 180);

            const largeArcFlag = sliceAngle > 180 ? 1 : 0;
            const pathData = `M ${x1} ${y1} A ${radius} ${radius} 0 ${largeArcFlag} 1 ${x2} ${y2} L ${x3} ${y3} A ${innerRadius} ${innerRadius} 0 ${largeArcFlag} 0 ${x4} ${y4} Z`;

            const isHovered = hoveredSlice === i;

            return (
              <path
                key={i}
                d={pathData}
                fill={slice.color}
                opacity={isHovered ? 1 : 0.88}
                className="cursor-pointer transition-opacity"
                onMouseEnter={() => setHoveredSlice(i)}
                onMouseLeave={() => setHoveredSlice(null)}
              />
            );
          })}
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center pointer-events-none">
          <span className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">Total</span>
          <span className="text-xs font-bold text-slate-900 dark:text-slate-100 font-mono-numbers">
            100%
          </span>
        </div>
      </div>

      {/* Legend list */}
      <div className="flex-1 w-full space-y-2">
        {data.map((item, i) => (
          <div
            key={i}
            onMouseEnter={() => setHoveredSlice(i)}
            onMouseLeave={() => setHoveredSlice(null)}
            className={`flex items-center justify-between p-1.5 rounded-lg text-xs cursor-pointer transition-colors ${
              hoveredSlice === i ? 'bg-slate-100 dark:bg-slate-800' : ''
            }`}
          >
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: item.color }} />
              <span className="font-medium text-slate-700 dark:text-slate-300">{item.name}</span>
            </div>
            <div className="text-right font-mono-numbers">
              <span className="text-slate-900 dark:text-slate-100 font-semibold">{item.value}%</span>
              <span className="text-[10px] text-slate-400 block">{formatIndianCurr(item.amount)}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// ==================== 6. RISK OVERVIEW HORIZONTAL BAR CHART ====================

interface RiskOverviewProps {
  data: Array<{ severity: string; count: number; color: string }>;
}

export const RiskOverviewBarChart: React.FC<RiskOverviewProps> = ({ data }) => {
  const total = data.reduce((sum, d) => sum + d.count, 0) || 1;

  return (
    <div className="space-y-3">
      {data.map((item) => {
        const percentage = Math.round((item.count / total) * 100);
        return (
          <div key={item.severity} className="space-y-1">
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full" style={{ backgroundColor: item.color }} />
                <span className="font-medium text-slate-700 dark:text-slate-300">{item.severity}</span>
              </div>
              <span className="font-mono-numbers font-semibold text-slate-900 dark:text-slate-100">
                {item.count} <span className="text-slate-400 text-[10px] font-normal">({percentage}%)</span>
              </span>
            </div>
            <div className="h-2 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
              <div
                className="h-full rounded-full transition-all duration-500"
                style={{
                  width: `${percentage}%`,
                  backgroundColor: item.color,
                }}
              />
            </div>
          </div>
        );
      })}
    </div>
  );
};

// ==================== 7. 5X5 TAX RISK INTELLIGENCE HEAT MATRIX ====================

interface RiskMatrixProps {
  risks: Array<{
    id: string;
    riskName: string;
    probability: number;
    financialImpact: number;
    severity: string;
    riskScore: number;
  }>;
  onSelectRisk?: (risk: any) => void;
}

export const TaxRiskMatrix: React.FC<RiskMatrixProps> = ({ risks, onSelectRisk }) => {
  const getCellBg = (prob: number, impact: number) => {
    const score = prob * impact;
    if (score >= 16) return 'bg-rose-500/20 dark:bg-rose-950/40 border-rose-300 dark:border-rose-900';
    if (score >= 12) return 'bg-amber-500/20 dark:bg-amber-950/40 border-amber-300 dark:border-amber-900';
    if (score >= 6) return 'bg-yellow-500/15 dark:bg-yellow-950/30 border-yellow-200 dark:border-yellow-900';
    return 'bg-emerald-500/15 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-900';
  };

  return (
    <div className="w-full">
      <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 mb-2">
        <span className="font-medium">Impact ↑</span>
        <span className="font-medium">Probability →</span>
      </div>

      <div className="grid grid-cols-5 gap-1.5 p-2 bg-slate-50 dark:bg-slate-900/50 rounded-xl border border-slate-200/80 dark:border-slate-800">
        {/* Render 5 rows (Impact: 5 down to 1) */}
        {[5, 4, 3, 2, 1].map((impact) =>
          [1, 2, 3, 4, 5].map((prob) => {
            const matchingRisks = risks.filter(
              (r) => r.probability === prob && r.financialImpact === impact
            );
            const score = prob * impact;

            return (
              <div
                key={`${prob}_${impact}`}
                className={`relative h-14 rounded-lg border flex flex-col items-center justify-center p-1 transition-all ${getCellBg(
                  prob,
                  impact
                )}`}
              >
                <span className="text-[10px] font-mono-numbers text-slate-400 dark:text-slate-500">
                  {score}
                </span>
                {matchingRisks.length > 0 && (
                  <div className="flex items-center -space-x-1 mt-1">
                    {matchingRisks.map((r) => (
                      <button
                        key={r.id}
                        onClick={() => onSelectRisk && onSelectRisk(r)}
                        className="w-5 h-5 rounded-full bg-slate-900 dark:bg-white text-white dark:text-slate-900 text-[10px] font-bold flex items-center justify-center ring-2 ring-white dark:ring-slate-900 hover:scale-110 transition-transform cursor-pointer"
                        title={`${r.riskName} (Score: ${r.riskScore})`}
                      >
                        !
                      </button>
                    ))}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Axis Labels */}
      <div className="flex justify-between px-2 pt-1 text-[10px] font-mono-numbers text-slate-400">
        <span>1: Rare</span>
        <span>2: Unlikely</span>
        <span>3: Possible</span>
        <span>4: Likely</span>
        <span>5: High</span>
      </div>
    </div>
  );
};
