import {
  Company,
  Transaction,
  TaxCalculation,
  TaxScenario,
  TaxForecast,
  ComplianceItem,
  TaxRisk,
  AuditDocument,
  Report,
  Notification,
  TaxConfiguration,
  DashboardStats,
  SearchResult,
  User,
} from '../types';

const BASE_URL = '/api';

async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const token = localStorage.getItem('taxwise_token');
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...(options.headers as Record<string, string>),
  };

  const response = await fetch(`${BASE_URL}${endpoint}`, {
    ...options,
    headers,
  });

  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.error || `HTTP error ${response.status}`);
  }

  return data;
}

export const api = {
  // Auth
  login: (credentials: { email: string; password: string }) =>
    request<{ user: User; token: string; message: string }>('/auth/login', {
      method: 'POST',
      body: JSON.stringify(credentials),
    }),
  register: (userData: { name: string; email: string; password: string; role?: string }) =>
    request<{ user: User; token: string; message: string }>('/auth/register', {
      method: 'POST',
      body: JSON.stringify(userData),
    }),
  logout: () =>
    request<{ message: string }>('/auth/logout', { method: 'POST' }),
  getCurrentUser: () =>
    request<{ user: User }>('/auth/me'),

  // Companies
  getCompanies: () =>
    request<Company[]>('/companies'),
  getCompany: (id: string) =>
    request<Company>(`/companies/${id}`),
  createCompany: (company: Partial<Company>) =>
    request<Company>('/companies', {
      method: 'POST',
      body: JSON.stringify(company),
    }),
  updateCompany: (id: string, company: Partial<Company>) =>
    request<Company>(`/companies/${id}`, {
      method: 'PUT',
      body: JSON.stringify(company),
    }),
  deleteCompany: (id: string) =>
    request<{ message: string }>(`/companies/${id}`, { method: 'DELETE' }),

  // Dashboard
  getDashboardStats: (companyId: string, fy?: string) =>
    request<DashboardStats>(`/dashboard/stats?companyId=${companyId}${fy ? `&fy=${encodeURIComponent(fy)}` : ''}`),

  // Transactions
  getTransactions: (params: {
    companyId: string;
    search?: string;
    category?: string;
    type?: string;
    page?: number;
    limit?: number;
  }) => {
    const query = new URLSearchParams();
    query.set('companyId', params.companyId);
    if (params.search) query.set('search', params.search);
    if (params.category) query.set('category', params.category);
    if (params.type) query.set('type', params.type);
    if (params.page) query.set('page', params.page.toString());
    if (params.limit) query.set('limit', params.limit.toString());
    return request<{
      items: Transaction[];
      total: number;
      page: number;
      totalPages: number;
      monthlySummary: Record<string, { revenue: number; expense: number; tax: number }>;
    }>(`/transactions?${query.toString()}`);
  },
  createTransaction: (tx: Partial<Transaction>) =>
    request<Transaction>('/transactions', {
      method: 'POST',
      body: JSON.stringify(tx),
    }),
  updateTransaction: (id: string, tx: Partial<Transaction>) =>
    request<Transaction>(`/transactions/${id}`, {
      method: 'PUT',
      body: JSON.stringify(tx),
    }),
  deleteTransaction: (id: string) =>
    request<{ message: string }>(`/transactions/${id}`, { method: 'DELETE' }),

  // Tax Calculator
  calculateTax: (payload: {
    companyId: string;
    financialYear: string;
    revenue: number;
    operatingExpenses: number;
    employeeExpenses: number;
    depreciation: number;
    otherExpenses: number;
    deductions: any[];
    advanceTaxPaid?: number;
    tdsCredit?: number;
    matCreditUtilized?: number;
    customBaseTaxRate?: number;
    notes?: string;
  }) =>
    request<TaxCalculation>('/tax/calculate', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  getTaxCalculations: (companyId: string) =>
    request<TaxCalculation[]>(`/tax/calculations?companyId=${companyId}`),
  deleteTaxCalculation: (id: string) =>
    request<{ message: string }>(`/tax/calculations/${id}`, { method: 'DELETE' }),

  // Tax Planning / Scenarios
  getTaxScenarios: (companyId: string) =>
    request<TaxScenario[]>(`/tax/scenarios?companyId=${companyId}`),
  createTaxScenario: (scenario: Partial<TaxScenario>) =>
    request<TaxScenario>('/tax/scenarios', {
      method: 'POST',
      body: JSON.stringify(scenario),
    }),
  duplicateTaxScenario: (id: string) =>
    request<TaxScenario>(`/tax/scenarios/${id}/duplicate`, { method: 'POST' }),
  updateTaxScenario: (id: string, scenario: Partial<TaxScenario>) =>
    request<TaxScenario>(`/tax/scenarios/${id}`, {
      method: 'PUT',
      body: JSON.stringify(scenario),
    }),
  deleteTaxScenario: (id: string) =>
    request<{ message: string }>(`/tax/scenarios/${id}`, { method: 'DELETE' }),

  // Forecasting
  getTaxForecast: (companyId: string) =>
    request<TaxForecast>(`/tax/forecast?companyId=${companyId}`),
  runForecast: (payload: {
    companyId: string;
    financialYear: string;
    methodology: 'moving_average' | 'linear_regression' | 'exponential_smoothing';
    forecastHorizonMonths: 3 | 6 | 12;
    historicalData?: any[];
    baseTaxRate?: number;
  }) =>
    request<TaxForecast>('/tax/forecast', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  // Compliance
  getComplianceItems: (companyId: string) =>
    request<{
      items: ComplianceItem[];
      stats: {
        score: number;
        completed: number;
        pending: number;
        overdue: number;
        underReview: number;
        total: number;
      };
    }>(`/compliance?companyId=${companyId}`),
  createComplianceItem: (item: Partial<ComplianceItem>) =>
    request<ComplianceItem>('/compliance', {
      method: 'POST',
      body: JSON.stringify(item),
    }),
  updateComplianceItem: (id: string, item: Partial<ComplianceItem>) =>
    request<ComplianceItem>(`/compliance/${id}`, {
      method: 'PUT',
      body: JSON.stringify(item),
    }),
  markComplianceComplete: (id: string) =>
    request<ComplianceItem>(`/compliance/${id}/mark-complete`, { method: 'POST' }),
  deleteComplianceItem: (id: string) =>
    request<{ message: string }>(`/compliance/${id}`, { method: 'DELETE' }),

  // Risks
  getRisks: (companyId: string) =>
    request<{
      total: number;
      criticalCount: number;
      highCount: number;
      mediumCount: number;
      lowCount: number;
      overallRisk: 'Low' | 'Medium' | 'High' | 'Critical';
      risks: TaxRisk[];
    }>(`/risks?companyId=${companyId}`),
  createRisk: (risk: Partial<TaxRisk>) =>
    request<TaxRisk>('/risks', {
      method: 'POST',
      body: JSON.stringify(risk),
    }),
  updateRisk: (id: string, risk: Partial<TaxRisk>) =>
    request<TaxRisk>(`/risks/${id}`, {
      method: 'PUT',
      body: JSON.stringify(risk),
    }),
  deleteRisk: (id: string) =>
    request<{ message: string }>(`/risks/${id}`, { method: 'DELETE' }),

  // Audit
  getAuditData: (companyId: string) =>
    request<{
      documents: AuditDocument[];
      readinessScore: number;
      stats: {
        total: number;
        uploaded: number;
        needsReview: number;
        missing: number;
      };
    }>(`/audit?companyId=${companyId}`),
  uploadAuditDoc: (payload: { id: string; fileName: string; fileSize?: number; notes?: string }) =>
    request<AuditDocument>('/audit/upload', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
  updateAuditDoc: (id: string, payload: Partial<AuditDocument>) =>
    request<AuditDocument>(`/audit/${id}`, {
      method: 'PUT',
      body: JSON.stringify(payload),
    }),

  // Tax Efficiency
  getTaxEfficiency: (companyId: string) =>
    request<{
      effectiveTaxRate: number;
      taxToRevenueRatio: number;
      taxToProfitRatio: number;
      complianceCost: number;
      taxSavingsOpportunity: number;
      netProfitAfterTax: number;
      currentPractice: {
        effectiveTaxRate: number;
        grossTax: number;
        npat: number;
      };
      improvedPractice: {
        effectiveTaxRate: number;
        grossTax: number;
        npat: number;
      };
      opportunities: Array<{
        title: string;
        potentialSavings: number;
        description: string;
        horizon: 'Short-Term' | 'Long-Term';
        feasibility: 'High' | 'Medium' | 'Low';
        riskLevel: 'Low' | 'Medium' | 'High';
      }>;
      disclaimer: string;
    }>(`/tax-efficiency?companyId=${companyId}`),

  // Reports
  getReports: (companyId: string) =>
    request<Report[]>(`/reports?companyId=${companyId}`),
  createReport: (report: Partial<Report>) =>
    request<Report>('/reports', {
      method: 'POST',
      body: JSON.stringify(report),
    }),

  // Notifications
  getNotifications: (companyId: string) =>
    request<Notification[]>(`/notifications?companyId=${companyId}`),
  markNotificationRead: (id: string) =>
    request<{ message: string }>(`/notifications/${id}/read`, { method: 'POST' }),
  markAllNotificationsRead: (companyId: string) =>
    request<{ message: string }>('/notifications/read-all', {
      method: 'POST',
      body: JSON.stringify({ companyId }),
    }),

  // Search
  search: (query: string, companyId: string) =>
    request<SearchResult[]>(`/search?q=${encodeURIComponent(query)}&companyId=${companyId}`),

  // Settings
  getSettings: () =>
    request<{ taxConfig: TaxConfiguration; user: User | null }>('/settings'),
  updateTaxConfig: (config: Partial<TaxConfiguration>) =>
    request<TaxConfiguration>('/settings/tax-config', {
      method: 'PUT',
      body: JSON.stringify(config),
    }),

  // Upload Dataset
  uploadDataset: (payload: { fileName: string; fileSize?: string; rows: any[]; columns?: string[] }) =>
    request<{
      status: string;
      fileName: string;
      fileSize: string;
      rowCount: number;
      columns: string[];
      uploadedAt: string;
      message: string;
      samplePreview: any[];
    }>('/upload/dataset', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  // Demo Reset
  resetDemo: () =>
    request<{ message: string }>('/demo/reset', { method: 'POST' }),
};
