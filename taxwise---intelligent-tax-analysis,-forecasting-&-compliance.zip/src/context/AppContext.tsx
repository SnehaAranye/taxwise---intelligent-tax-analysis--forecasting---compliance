import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { Company, User, Notification } from '../types';
import { api } from '../services/api';

interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info' | 'warning';
  text: string;
}

interface AppContextType {
  user: User | null;
  isAuthenticated: boolean;
  companies: Company[];
  selectedCompany: Company | null;
  selectedCompanyId: string;
  setSelectedCompanyId: (id: string) => void;
  financialYear: string;
  setFinancialYear: (fy: string) => void;
  darkMode: boolean;
  toggleDarkMode: () => void;
  notifications: Notification[];
  unreadCount: number;
  markNotificationRead: (id: string) => Promise<void>;
  markAllNotificationsRead: () => Promise<void>;
  isSearchOpen: boolean;
  setIsSearchOpen: (open: boolean) => void;
  login: (credentials: { email: string; password: string }) => Promise<void>;
  loginAsDemo: () => Promise<void>;
  register: (data: { name: string; email: string; password: string; role?: string }) => Promise<void>;
  logout: () => void;
  refreshCompanies: () => Promise<void>;
  refreshNotifications: () => Promise<void>;
  showToast: (text: string, type?: 'success' | 'error' | 'info' | 'warning') => void;
  toasts: ToastMessage[];
  dismissToast: (id: string) => void;
  resetDemoData: () => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('taxwise_user');
    return saved ? JSON.parse(saved) : null;
  });

  const [companies, setCompanies] = useState<Company[]>([]);
  const [selectedCompanyId, setSelectedCompanyIdState] = useState<string>(() => {
    return localStorage.getItem('taxwise_company_id') || 'comp_apex_tech';
  });
  const [financialYear, setFinancialYear] = useState<string>('FY 2026-27');
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    return localStorage.getItem('taxwise_dark_mode') === 'true';
  });
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [isSearchOpen, setIsSearchOpen] = useState<boolean>(false);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Apply dark mode class to root html element
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('taxwise_dark_mode', 'true');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('taxwise_dark_mode', 'false');
    }
  }, [darkMode]);

  const toggleDarkMode = () => {
    setDarkMode((prev) => !prev);
  };

  const showToast = useCallback((text: string, type: 'success' | 'error' | 'info' | 'warning' = 'info') => {
    const id = `toast_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`;
    setToasts((prev) => [...prev, { id, type, text }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4500);
  }, []);

  const dismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Keyboard shortcut listener for Ctrl + K
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsSearchOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const refreshCompanies = useCallback(async () => {
    try {
      const data = await api.getCompanies();
      setCompanies(data);
      if (data.length > 0 && !data.some((c) => c.id === selectedCompanyId)) {
        setSelectedCompanyIdState(data[0].id);
        localStorage.setItem('taxwise_company_id', data[0].id);
      }
    } catch (err: any) {
      console.error('Failed to load companies:', err);
    }
  }, [selectedCompanyId]);

  const refreshNotifications = useCallback(async () => {
    try {
      const data = await api.getNotifications(selectedCompanyId);
      setNotifications(data);
    } catch (err: any) {
      console.error('Failed to load notifications:', err);
    }
  }, [selectedCompanyId]);

  useEffect(() => {
    refreshCompanies();
  }, [refreshCompanies]);

  useEffect(() => {
    refreshNotifications();
  }, [selectedCompanyId, refreshNotifications]);

  const setSelectedCompanyId = (id: string) => {
    setSelectedCompanyIdState(id);
    localStorage.setItem('taxwise_company_id', id);
  };

  const login = async (credentials: { email: string; password: string }) => {
    const res = await api.login(credentials);
    setUser(res.user);
    localStorage.setItem('taxwise_user', JSON.stringify(res.user));
    localStorage.setItem('taxwise_token', res.token);
    showToast(`Welcome back, ${res.user.name}`, 'success');
  };

  const loginAsDemo = async () => {
    await login({ email: 'analyst@taxwise.io', password: 'Password123!' });
  };

  const register = async (data: { name: string; email: string; password: string; role?: string }) => {
    const res = await api.register(data);
    setUser(res.user);
    localStorage.setItem('taxwise_user', JSON.stringify(res.user));
    localStorage.setItem('taxwise_token', res.token);
    showToast('Registration successful! Welcome to TaxWise.', 'success');
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('taxwise_user');
    localStorage.removeItem('taxwise_token');
    showToast('You have been safely signed out.', 'info');
  };

  const markNotificationRead = async (id: string) => {
    await api.markNotificationRead(id);
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, isRead: true } : n))
    );
  };

  const markAllNotificationsRead = async () => {
    await api.markAllNotificationsRead(selectedCompanyId);
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
    showToast('All notifications marked as read.', 'success');
  };

  const resetDemoData = async () => {
    await api.resetDemo();
    await refreshCompanies();
    await refreshNotifications();
    showToast('Demo dataset has been reset to baseline defaults.', 'success');
  };

  const selectedCompany = companies.find((c) => c.id === selectedCompanyId) || companies[0] || null;
  const unreadCount = notifications.filter((n) => !n.isRead).length;

  return (
    <AppContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        companies,
        selectedCompany,
        selectedCompanyId,
        setSelectedCompanyId,
        financialYear,
        setFinancialYear,
        darkMode,
        toggleDarkMode,
        notifications,
        unreadCount,
        markNotificationRead,
        markAllNotificationsRead,
        isSearchOpen,
        setIsSearchOpen,
        login,
        loginAsDemo,
        register,
        logout,
        refreshCompanies,
        refreshNotifications,
        showToast,
        toasts,
        dismissToast,
        resetDemoData,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
