export type UserRole = 'Junior Financial Analyst' | 'Senior Tax Consultant' | 'Tax Director';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  companyId: string;
  avatarUrl?: string;
  createdAt: string;
}

export interface Company {
  id: string;
  name: string;
  industry: string;
  businessType: string;
  pan: string;
  gstin: string;
  state: string;
  city: string;
  financialYear: string;
  revenue: number;
  expenses: number;
  baseTaxRate: number;
  isDemo?: boolean;
}

export type TransactionCategory =
  | 'Revenue'
  | 'Operating Expense'
  | 'Payroll'
  | 'Capital Expense'
  | 'Tax Payment'
  | 'Other';

export interface Transaction {
  id: string;
  companyId: string;
  date: string;
  description: string;
  category: TransactionCategory;
  type: 'credit' | 'debit';
  amount: number;
  taxCategory: string;
  taxAmount: number;
  paymentStatus: 'Paid' | 'Pending' | 'Scheduled';
  referenceNo: string;
}

export interface DeductionItem {
  id: string;
  section: string;
  name: string;
  amount: number;
  description: string;
}

export interface TaxCalculation {
  id: string;
  companyId: string;
  financialYear: string;
  calculationDate: string;
  revenue: number;
  operatingExpenses: number;
  employeeExpenses: number;
  depreciation: number;
  otherExpenses: number;
  totalExpenses: number;
  profitBeforeTax: number;
  deductions: DeductionItem[];
  totalDeductions: number;
  taxableIncome: number;
  taxRate: number;
  surcharge: number;
  cess: number;
  grossTax: number;
  taxCredits: number;
  advanceTaxPaid: number;
  tdsCredit: number;
  matCreditUtilized: number;
  estimatedTaxPayable: number;
  effectiveTaxRate: number;
  netProfitAfterTax: number;
  notes?: string;
}

export interface TaxScenario {
  id: string;
  companyId: string;
  name: string;
  description: string;
  revenue: number;
  expenses: number;
  depreciation: number;
  deductions: number;
  taxCredits: number;
  taxRate: number;
  taxableIncome: number;
  estimatedTax: number;
  effectiveTaxRate: number;
  netProfitAfterTax: number;
  taxSavingsVsBaseline: number;
  isOptimized: boolean;
  assumptions: string[];
  createdAt: string;
}

export interface HistoricalMonthData {
  month: string;
  revenue: number;
  expenses: number;
  profit: number;
  taxPaid: number;
  taxLiability: number;
}

export interface ForecastMonthData {
  month: string;
  forecastedRevenue: number;
  forecastedExpenses: number;
  forecastedProfit: number;
  forecastedTaxLiability: number;
  confidenceLower: number;
  confidenceUpper: number;
}

export interface TaxForecast {
  id: string;
  companyId: string;
  financialYear: string;
  methodology: 'moving_average' | 'linear_regression' | 'exponential_smoothing';
  forecastHorizonMonths: 3 | 6 | 12;
  historicalData: HistoricalMonthData[];
  forecastData: ForecastMonthData[];
  assumptions: string[];
  metrics: {
    rSquared: number;
    annualizedGrowthRate: number;
    meanAbsoluteError: number;
  };
  generatedAt: string;
}

export interface ComplianceItem {
  id: string;
  companyId: string;
  title: string;
  category: 'GST' | 'Direct Tax' | 'TDS/TCS' | 'Transfer Pricing' | 'Corporate Law';
  dueDate: string;
  status: 'Completed' | 'Pending' | 'Overdue' | 'Under Review';
  priority: 'Critical' | 'High' | 'Medium' | 'Low';
  owner: string;
  filingPeriod: string;
  penaltyRisk: string;
  documentAttached?: {
    name: string;
    size: number;
    uploadedAt: string;
  };
}

export interface TaxRisk {
  id: string;
  companyId: string;
  riskName: string;
  category:
    | 'Transfer Pricing'
    | 'GST Reconciliation'
    | 'TDS Non-Deduction'
    | 'Permanent Establishment'
    | 'Depreciation Disallowance'
    | 'Section 40A(3) Cash Payments'
    | 'Related Party Transaction';
  description: string;
  probability: number;
  financialImpact: number;
  riskScore: number;
  severity: 'Low' | 'Medium' | 'High' | 'Critical';
  mitigation: string;
  owner: string;
  status: 'Open' | 'Mitigating' | 'Resolved';
  detectedDate: string;
}

export interface AuditDocument {
  id: string;
  companyId: string;
  itemType:
    | 'Financial Statements'
    | 'Tax Returns'
    | 'Invoices'
    | 'Expense Records'
    | 'Bank Statements'
    | 'Payroll Records'
    | 'Tax Payments'
    | 'Supporting Documents'
    | 'Tax Correspondence';
  title: string;
  fileName?: string;
  fileSize?: number;
  status: 'Uploaded' | 'Missing' | 'Needs Review';
  uploadedAt?: string;
  compliancePeriod: string;
  notes?: string;
}

export interface Report {
  id: string;
  companyId: string;
  reportType:
    | 'Tax Liability'
    | 'Tax Forecast'
    | 'Compliance'
    | 'Tax Risk'
    | 'Audit Readiness'
    | 'Tax Efficiency';
  title: string;
  financialYear: string;
  summary: string;
  generatedDate: string;
  generatedBy: string;
  data: any;
}

export interface Notification {
  id: string;
  companyId: string;
  title: string;
  message: string;
  type: 'warning' | 'alert' | 'info' | 'success';
  isRead: boolean;
  createdAt: string;
  linkTo?: string;
}

export interface TaxConfiguration {
  corporateTaxRate: number;
  surchargeRate: number;
  cessRate: number;
  matRate: number;
  financialYear: string;
  deductionRules: {
    section: string;
    title: string;
    maxLimit: number;
    description: string;
  }[];
  lastUpdated: string;
}

export interface DashboardStats {
  company: Company;
  financialYear: string;
  kpi: {
    revenue: number;
    revenueFormatted: string;
    revenueGrowth: string;
    taxableIncome: number;
    taxableIncomeFormatted: string;
    taxableIncomeGrowth: string;
    estimatedTax: number;
    estimatedTaxFormatted: string;
    taxSavingsOpportunity: number;
    taxSavingsOpportunityFormatted: string;
    complianceScore: number;
    riskScore: 'Low' | 'Medium' | 'High' | 'Critical';
  };
  charts: {
    revenueVsExpenses: Array<{ month: string; revenue: number; expenses: number; profit: number }>;
    taxLiabilityTrend: Array<{ month: string; taxLiability: number; taxPaid: number }>;
    effectiveTaxRateTrend: Array<{ month: string; effectiveRate: number; statutoryBenchmark: number }>;
    historicalVsForecast: Array<{
      month: string;
      taxLiability?: number;
      forecastedLiability?: number;
      confidenceLower?: number;
      confidenceUpper?: number;
      type: 'historical' | 'forecast';
    }>;
    taxDistribution: Array<{ name: string; value: number; amount: number; color: string }>;
    riskOverview: Array<{ severity: string; count: number; color: string }>;
  };
}

export interface SearchResult {
  id: string;
  type: 'Company' | 'Transaction' | 'Compliance' | 'Risk' | 'Report';
  title: string;
  subtitle: string;
  link: string;
}
