import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { api } from '../services/api';
import { Company } from '../types';
import { Modal } from '../components/common/Modal';
import {
  Building2,
  Plus,
  Trash2,
  Edit2,
  Check,
  ArrowRight,
  TrendingUp,
  Receipt,
  FileCheck,
} from 'lucide-react';

interface CompaniesPageProps {
  onNavigate: (page: string) => void;
}

export const CompaniesPage: React.FC<CompaniesPageProps> = ({ onNavigate }) => {
  const {
    companies,
    selectedCompanyId,
    setSelectedCompanyId,
    refreshCompanies,
    showToast,
  } = useApp();

  const [modalOpen, setModalOpen] = useState(false);
  const [editingComp, setEditingComp] = useState<Company | null>(null);

  // Form
  const [name, setName] = useState('');
  const [industry, setIndustry] = useState('');
  const [businessType, setBusinessType] = useState('Private Limited Company');
  const [pan, setPan] = useState('');
  const [gstin, setGstin] = useState('');
  const [state, setState] = useState('Maharashtra');
  const [city, setCity] = useState('Mumbai');
  const [financialYear, setFinancialYear] = useState('FY 2026-27');
  const [revenue, setRevenue] = useState<number>(100000000);
  const [expenses, setExpenses] = useState<number>(65000000);
  const [baseTaxRate, setBaseTaxRate] = useState<number>(25.17);

  const fmtCr = (val: number) => {
    if (val >= 10000000) return `₹${(val / 10000000).toFixed(2)} Cr`;
    if (val >= 100000) return `₹${(val / 100000).toFixed(2)} L`;
    return `₹${val.toLocaleString('en-IN')}`;
  };

  const handleOpenCreate = () => {
    setEditingComp(null);
    setName('');
    setIndustry('Enterprise Cloud Software & AI');
    setBusinessType('Private Limited Company');
    setPan('AABCP8841M');
    setGstin('27AABCP8841M1Z4');
    setState('Maharashtra');
    setCity('Mumbai');
    setFinancialYear('FY 2026-27');
    setRevenue(124000000);
    setExpenses(75800000);
    setBaseTaxRate(25.17);
    setModalOpen(true);
  };

  const handleOpenEdit = (c: Company) => {
    setEditingComp(c);
    setName(c.name);
    setIndustry(c.industry);
    setBusinessType(c.businessType);
    setPan(c.pan);
    setGstin(c.gstin);
    setState(c.state);
    setCity(c.city);
    setFinancialYear(c.financialYear);
    setRevenue(c.revenue);
    setExpenses(c.expenses);
    setBaseTaxRate(c.baseTaxRate);
    setModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingComp) {
        await api.updateCompany(editingComp.id, {
          name,
          industry,
          businessType,
          pan: pan.toUpperCase(),
          gstin: gstin.toUpperCase(),
          state,
          city,
          financialYear,
          revenue: Number(revenue),
          expenses: Number(expenses),
          baseTaxRate: Number(baseTaxRate),
        });
        showToast('Company profile updated successfully.', 'success');
      } else {
        const created = await api.createCompany({
          name,
          industry,
          businessType,
          pan: pan.toUpperCase(),
          gstin: gstin.toUpperCase(),
          state,
          city,
          financialYear,
          revenue: Number(revenue),
          expenses: Number(expenses),
          baseTaxRate: Number(baseTaxRate),
        });
        setSelectedCompanyId(created.id);
        showToast('New corporate entity registered.', 'success');
      }
      setModalOpen(false);
      await refreshCompanies();
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  const handleDelete = async (id: string) => {
    if (companies.length <= 1) {
      showToast('Cannot delete the only company.', 'warning');
      return;
    }

    try {
      await api.deleteCompany(id);
      showToast('Company removed.', 'info');
      await refreshCompanies();
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  const handleSelect = (id: string) => {
    setSelectedCompanyId(id);
    showToast('Switched active corporate entity. Recalculating dashboard.', 'success');
    onNavigate('overview');
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 dark:text-white flex items-center gap-2.5">
            <Building2 className="w-7 h-7 text-blue-600" />
            <span>Company Management</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Manage multi-entity portfolios. Switching company automatically updates all calculations, forecasts, compliance, and risk registers.
          </p>
        </div>

        <button
          onClick={handleOpenCreate}
          className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs transition-colors flex items-center gap-2 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Register New Company</span>
        </button>
      </div>

      {/* Companies Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {companies.map((comp) => {
          const isSelected = comp.id === selectedCompanyId;
          const pbt = Math.max(0, comp.revenue - comp.expenses);

          return (
            <div
              key={comp.id}
              className={`p-6 bg-white dark:bg-slate-900 rounded-3xl border transition-all flex flex-col justify-between ${
                isSelected
                  ? 'border-blue-600 dark:border-blue-500 shadow-md ring-2 ring-blue-500/20'
                  : 'border-slate-200/80 dark:border-slate-800 shadow-2xs hover:border-slate-300'
              }`}
            >
              <div>
                <div className="flex items-center justify-between text-xs mb-3">
                  <span
                    className={`px-2.5 py-0.5 rounded-full font-semibold ${
                      comp.isDemo
                        ? 'bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300'
                        : 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300'
                    }`}
                  >
                    {comp.isDemo ? 'Demo Company' : 'Production Entity'}
                  </span>

                  {isSelected && (
                    <span className="flex items-center gap-1 text-[11px] font-bold text-blue-600 dark:text-blue-400">
                      <Check className="w-3.5 h-3.5" />
                      Active
                    </span>
                  )}
                </div>

                <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">{comp.name}</h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">{comp.industry}</p>

                <div className="mt-4 p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl space-y-1.5 text-xs font-mono-numbers">
                  <div className="flex justify-between">
                    <span className="text-slate-400 font-sans">PAN:</span>
                    <span className="font-semibold text-slate-800 dark:text-slate-200">{comp.pan}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400 font-sans">GSTIN:</span>
                    <span className="font-semibold text-slate-800 dark:text-slate-200">{comp.gstin}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400 font-sans">Annual Revenue:</span>
                    <span className="font-bold text-slate-900 dark:text-slate-100">{fmtCr(comp.revenue)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400 font-sans">Operating Profit (PBT):</span>
                    <span className="font-bold text-blue-600 dark:text-blue-400">{fmtCr(pbt)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400 font-sans">Location:</span>
                    <span className="font-sans text-slate-600 dark:text-slate-400">{comp.city}, {comp.state}</span>
                  </div>
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => handleOpenEdit(comp)}
                    className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                    title="Edit Company"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  {!comp.isDemo && (
                    <button
                      onClick={() => handleDelete(comp.id)}
                      className="p-1.5 text-slate-400 hover:text-rose-500 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                      title="Delete Company"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                {isSelected ? (
                  <span className="text-xs font-semibold text-slate-400">Selected</span>
                ) : (
                  <button
                    onClick={() => handleSelect(comp.id)}
                    className="px-3 py-1.5 text-xs font-semibold text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/60 rounded-xl transition-colors flex items-center gap-1 cursor-pointer"
                  >
                    <span>Switch to Entity</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Create / Edit Modal */}
      <Modal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editingComp ? 'Edit Corporate Profile' : 'Register Corporate Entity'}
        subtitle="Manage tax identification and statutory financial scale"
      >
        <form onSubmit={handleSave} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Company Legal Name
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Apex Technologies Pvt. Ltd."
              className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Industry
              </label>
              <input
                type="text"
                required
                value={industry}
                onChange={(e) => setIndustry(e.target.value)}
                placeholder="Technology & Cloud Services"
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Business Constitution
              </label>
              <select
                value={businessType}
                onChange={(e) => setBusinessType(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
              >
                <option value="Private Limited Company">Private Limited Company</option>
                <option value="Public Limited Company">Public Limited Company</option>
                <option value="Limited Liability Partnership (LLP)">Limited Liability Partnership</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Permanent Account Number (PAN)
              </label>
              <input
                type="text"
                required
                maxLength={10}
                value={pan}
                onChange={(e) => setPan(e.target.value.toUpperCase())}
                placeholder="AABCA1234F"
                className="w-full px-3 py-2 text-xs font-mono-numbers uppercase bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                GSTIN Identification
              </label>
              <input
                type="text"
                required
                maxLength={15}
                value={gstin}
                onChange={(e) => setGstin(e.target.value.toUpperCase())}
                placeholder="27AABCA1234F1Z5"
                className="w-full px-3 py-2 text-xs font-mono-numbers uppercase bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                City
              </label>
              <input
                type="text"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                State
              </label>
              <input
                type="text"
                value={state}
                onChange={(e) => setState(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Annual Revenue (₹)
              </label>
              <input
                type="number"
                min="0"
                value={revenue}
                onChange={(e) => setRevenue(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs font-mono-numbers bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Annual Expenses (₹)
              </label>
              <input
                type="number"
                min="0"
                value={expenses}
                onChange={(e) => setExpenses(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs font-mono-numbers bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
              />
            </div>
          </div>

          <div className="pt-4 flex justify-end gap-2 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-400"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs"
            >
              Save Entity
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
