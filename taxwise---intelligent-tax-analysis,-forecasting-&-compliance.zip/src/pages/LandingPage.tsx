import React, { useState } from 'react';
import {
  ShieldCheck,
  ArrowRight,
  TrendingUp,
  Calculator,
  CalendarCheck,
  ShieldAlert,
  Sparkles,
  FileText,
  BarChart3,
  CheckCircle2,
  Lock,
  PieChart,
} from 'lucide-react';

interface LandingPageProps {
  onStart: () => void;
  onOpenAuth: (mode: 'login' | 'register') => void;
  onNavigateDirect: (page: string) => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onStart,
  onOpenAuth,
  onNavigateDirect,
}) => {
  const [heroInputRevenue, setHeroInputRevenue] = useState(124000000);
  const [heroExpenses, setHeroExpenses] = useState(75800000);
  const [heroDeductions, setHeroDeductions] = useState(4200000);

  const heroPBT = Math.max(0, heroInputRevenue - heroExpenses);
  const heroTaxable = Math.max(0, heroPBT - heroDeductions);
  const heroGrossTax = heroTaxable * 0.2517;
  const heroETR = heroPBT > 0 ? (heroGrossTax / heroPBT) * 100 : 0;

  const modules = [
    {
      title: 'Tax Strategy Simulator',
      desc: 'Simulate allowable deductions under Section 80JJAA, accelerated depreciation, and R&D incentives side-by-side.',
      icon: Calculator,
      color: 'text-blue-600 bg-blue-50 dark:bg-blue-950/50',
      action: 'planning',
    },
    {
      title: 'Liability Forecasting',
      desc: 'Project 3, 6, and 12-month corporate tax obligations using Linear Regression and Exponential Smoothing with 95% confidence intervals.',
      icon: TrendingUp,
      color: 'text-indigo-600 bg-indigo-50 dark:bg-indigo-950/50',
      action: 'forecasting',
    },
    {
      title: 'Statutory Compliance Center',
      desc: 'Monitor Advance Tax installments, GSTR-1, GSTR-3B, TDS Form 26Q, and transfer pricing filing deadlines.',
      icon: CalendarCheck,
      color: 'text-emerald-600 bg-emerald-50 dark:bg-emerald-950/50',
      action: 'compliance',
    },
    {
      title: 'Tax Risk Intelligence',
      desc: 'Identify transfer pricing variances, GST 2B reconciliation mismatches, and statutory exposure on an interactive 5x5 impact matrix.',
      icon: ShieldAlert,
      color: 'text-amber-600 bg-amber-50 dark:bg-amber-950/50',
      action: 'risk-assessment',
    },
    {
      title: 'Audit Readiness Workspace',
      desc: 'Pre-audit preparation across 9 evidentiary categories: financial statements, returns, IRN logs, and payroll records.',
      icon: CheckCircle2,
      color: 'text-purple-600 bg-purple-50 dark:bg-purple-950/50',
      action: 'audit-center',
    },
    {
      title: 'Executive Reporting Engine',
      desc: 'Generate downloadable tax liability audits, forecast projections, and tax efficiency studies for leadership.',
      icon: FileText,
      color: 'text-rose-600 bg-rose-50 dark:bg-rose-950/50',
      action: 'reports',
    },
  ];

  return (
    <div className="min-h-screen bg-[#FCFDFD] dark:bg-slate-950 text-slate-900 dark:text-slate-100 antialiased">
      {/* 1. STICKY NAVBAR */}
      <header className="sticky top-0 z-50 bg-white/85 dark:bg-slate-900/85 backdrop-blur-md border-b border-slate-200/80 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-6 h-18 flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center gap-2.5 cursor-pointer" onClick={onStart}>
            <div className="w-9 h-9 rounded-xl bg-blue-600 flex items-center justify-center text-white font-bold shadow-xs">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <span className="text-xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
                TaxWise
              </span>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="hidden lg:flex items-center gap-7 text-xs font-semibold text-slate-600 dark:text-slate-300">
            <a href="#platform" className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
              Platform
            </a>
            <a href="#calculator" className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
              Tax Calculator
            </a>
            <a href="#forecasting" className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
              Forecasting
            </a>
            <a href="#compliance" className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
              Compliance
            </a>
            <a href="#risk" className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
              Risk Analysis
            </a>
            <a href="#reports" className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
              Reports
            </a>
          </nav>

          {/* Right Action Buttons */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => onOpenAuth('login')}
              className="px-4 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer"
            >
              Sign In
            </button>
            <button
              onClick={onStart}
              className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <span>Get Started</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </header>

      {/* 2. HERO SECTION */}
      <section className="relative pt-16 pb-24 px-6 overflow-hidden">
        {/* Subtle background glow */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[650px] h-[350px] bg-blue-400/10 dark:bg-blue-600/10 rounded-full blur-3xl pointer-events-none -z-10" />

        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Column: Headlines & CTA */}
          <div className="lg:col-span-6 space-y-6">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-full text-xs font-medium border border-slate-200/60 dark:border-slate-700/60">
              <span className="w-2 h-2 rounded-full bg-blue-600 animate-pulse" />
              <span>Junior Financial Analyst – Taxation Portfolio Architecture</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-[52px] font-extrabold tracking-tight text-slate-950 dark:text-white leading-[1.12]">
              Turn Tax Data Into Smarter Financial Decisions
            </h1>

            <p className="text-base text-slate-600 dark:text-slate-300 leading-relaxed max-w-xl">
              Analyze tax liabilities, forecast future obligations, identify compliance risks, and evaluate tax efficiency from one intelligent financial analytics platform.
            </p>

            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={onStart}
                className="px-6 py-3.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-sm transition-all flex items-center gap-2 cursor-pointer hover:shadow-blue-500/20"
              >
                <span>Start Analysis</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => onNavigateDirect('overview')}
                className="px-6 py-3.5 text-xs font-semibold text-slate-800 dark:text-slate-200 bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800 rounded-xl transition-colors cursor-pointer"
              >
                Explore Platform
              </button>
            </div>

            {/* Micro Trust Stats */}
            <div className="pt-6 grid grid-cols-3 gap-4 border-t border-slate-200/80 dark:border-slate-800/80 text-xs">
              <div>
                <div className="font-extrabold text-slate-900 dark:text-slate-100 font-mono-numbers text-sm">
                  Section 115BAA
                </div>
                <div className="text-slate-500 dark:text-slate-400 text-[11px]">Corporate Engine</div>
              </div>
              <div>
                <div className="font-extrabold text-slate-900 dark:text-slate-100 font-mono-numbers text-sm">
                  OLS & Holt's
                </div>
                <div className="text-slate-500 dark:text-slate-400 text-[11px]">Forecasting Math</div>
              </div>
              <div>
                <div className="font-extrabold text-slate-900 dark:text-slate-100 font-mono-numbers text-sm">
                  5×5 Matrix
                </div>
                <div className="text-slate-500 dark:text-slate-400 text-[11px]">Risk Intelligence</div>
              </div>
            </div>
          </div>

          {/* Right Column: Live Interactive Financial Analytics Visual */}
          <div className="lg:col-span-6">
            <div className="relative p-6 bg-white dark:bg-slate-900 rounded-3xl shadow-xl border border-slate-200/80 dark:border-slate-800 space-y-5 transition-all">
              {/* Window Header */}
              <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800 text-xs">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-slate-300 dark:bg-slate-700" />
                  <span className="w-2.5 h-2.5 rounded-full bg-slate-300 dark:bg-slate-700" />
                  <span className="w-2.5 h-2.5 rounded-full bg-slate-300 dark:bg-slate-700" />
                  <span className="font-semibold text-slate-700 dark:text-slate-300 ml-2">
                    TaxWise Intelligence Engine · FY 2026-27
                  </span>
                </div>
                <span className="text-[11px] font-medium text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 px-2 py-0.5 rounded-md">
                  Live Engine
                </span>
              </div>

              {/* KPI Strip */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-100 dark:border-slate-800">
                  <div className="text-[10px] font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                    Tax Liability
                  </div>
                  <div className="text-base font-bold text-slate-900 dark:text-slate-100 font-mono-numbers mt-0.5">
                    ₹{(heroGrossTax / 10000000).toFixed(2)} Cr
                  </div>
                  <div className="text-[10px] text-blue-600 dark:text-blue-400 font-medium mt-0.5">
                    Rate: 25.17%
                  </div>
                </div>

                <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-100 dark:border-slate-800">
                  <div className="text-[10px] font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                    Effective Tax Rate
                  </div>
                  <div className="text-base font-bold text-slate-900 dark:text-slate-100 font-mono-numbers mt-0.5">
                    {heroETR.toFixed(2)}%
                  </div>
                  <div className="text-[10px] text-emerald-600 dark:text-emerald-400 font-medium mt-0.5">
                    -2.19% vs base
                  </div>
                </div>

                <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-100 dark:border-slate-800">
                  <div className="text-[10px] font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                    Forecast
                  </div>
                  <div className="text-base font-bold text-slate-900 dark:text-slate-100 font-mono-numbers mt-0.5">
                    +8.4%
                  </div>
                  <div className="text-[10px] text-indigo-600 dark:text-indigo-400 font-medium mt-0.5">
                    R² = 0.91 OLS
                  </div>
                </div>

                <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-100 dark:border-slate-800">
                  <div className="text-[10px] font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                    Risk Indicator
                  </div>
                  <div className="text-base font-bold text-emerald-600 dark:text-emerald-400 font-mono-numbers mt-0.5">
                    Low
                  </div>
                  <div className="text-[10px] text-slate-500 dark:text-slate-400 font-medium mt-0.5">
                    0 Critical
                  </div>
                </div>
              </div>

              {/* Interactive Mini Chart */}
              <div className="p-4 bg-slate-50 dark:bg-slate-800/30 rounded-2xl border border-slate-100 dark:border-slate-800">
                <div className="flex items-center justify-between text-xs mb-2">
                  <span className="font-semibold text-slate-700 dark:text-slate-300">
                    6-Month Liability Curve vs Advance Tax Safe Harbor
                  </span>
                  <span className="text-[11px] font-mono-numbers text-slate-400">
                    Confidence: 95%
                  </span>
                </div>

                {/* SVG Visual */}
                <div className="h-32 w-full">
                  <svg viewBox="0 0 400 120" className="w-full h-full overflow-visible">
                    <defs>
                      <linearGradient id="miniGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#2563EB" stopOpacity="0.2" />
                        <stop offset="100%" stopColor="#2563EB" stopOpacity="0" />
                      </linearGradient>
                    </defs>

                    {/* Grid */}
                    <line x1="0" y1="30" x2="400" y2="30" stroke="currentColor" className="text-slate-200 dark:text-slate-800" strokeDasharray="3 3" />
                    <line x1="0" y1="70" x2="400" y2="70" stroke="currentColor" className="text-slate-200 dark:text-slate-800" strokeDasharray="3 3" />
                    <line x1="0" y1="100" x2="400" y2="100" stroke="currentColor" className="text-slate-200 dark:text-slate-800" strokeDasharray="3 3" />

                    {/* Historical Area */}
                    <path
                      d="M 20 85 L 80 72 L 140 68 L 200 50 L 200 100 L 20 100 Z"
                      fill="url(#miniGradient)"
                    />
                    {/* Historical Line */}
                    <path
                      d="M 20 85 L 80 72 L 140 68 L 200 50"
                      fill="none"
                      stroke="#2563EB"
                      strokeWidth="2.5"
                    />

                    {/* Transition Dot */}
                    <circle cx="200" cy="50" r="4" fill="#2563EB" stroke="#FFFFFF" strokeWidth="2" />

                    {/* Forecast Dashed Line */}
                    <path
                      d="M 200 50 L 260 42 L 320 35 L 380 28"
                      fill="none"
                      stroke="#6366F1"
                      strokeWidth="2.5"
                      strokeDasharray="4 4"
                    />

                    {/* Forecast Dots */}
                    <circle cx="260" cy="42" r="3.5" fill="#6366F1" />
                    <circle cx="320" cy="35" r="3.5" fill="#6366F1" />
                    <circle cx="380" cy="28" r="3.5" fill="#6366F1" />

                    {/* Labels */}
                    <text x="20" y="115" className="text-[9px] fill-slate-400 font-mono-numbers">Apr</text>
                    <text x="80" y="115" className="text-[9px] fill-slate-400 font-mono-numbers">May</text>
                    <text x="140" y="115" className="text-[9px] fill-slate-400 font-mono-numbers">Jun</text>
                    <text x="200" y="115" className="text-[9px] fill-blue-600 font-semibold font-mono-numbers">Jul (Actual)</text>
                    <text x="260" y="115" className="text-[9px] fill-indigo-600 font-mono-numbers">Aug (Proj)</text>
                    <text x="320" y="115" className="text-[9px] fill-indigo-600 font-mono-numbers">Sep (Proj)</text>
                    <text x="380" y="115" className="text-[9px] fill-indigo-600 font-mono-numbers">Oct (Proj)</text>
                  </svg>
                </div>
              </div>

              {/* Interactive Mini Sliders for Quick Proof */}
              <div className="pt-2 border-t border-slate-100 dark:border-slate-800 text-xs space-y-2">
                <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
                  <span>Interactive Proof: Adjust Revenue</span>
                  <span className="font-mono-numbers font-semibold text-slate-800 dark:text-slate-200">
                    ₹{(heroInputRevenue / 10000000).toFixed(2)} Cr
                  </span>
                </div>
                <input
                  type="range"
                  min="50000000"
                  max="200000000"
                  step="5000000"
                  value={heroInputRevenue}
                  onChange={(e) => setHeroInputRevenue(Number(e.target.value))}
                  className="w-full accent-blue-600 h-1.5 bg-slate-200 dark:bg-slate-700 rounded-lg cursor-pointer"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3. PLATFORM MODULES SECTION */}
      <section id="platform" className="py-20 px-6 bg-slate-50/70 dark:bg-slate-900/40 border-y border-slate-200/80 dark:border-slate-800">
        <div className="max-w-7xl mx-auto space-y-12">
          <div className="text-center max-w-2xl mx-auto space-y-3">
            <span className="text-xs font-bold text-blue-600 dark:text-blue-400 uppercase tracking-wider">
              Connected Architecture
            </span>
            <h2 className="text-3xl font-extrabold tracking-tight text-slate-950 dark:text-white">
              End-to-End Corporate Taxation Ecosystem
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
              Every module feeds directly into the calculation and risk engines, eliminating spreadsheet errors and disconnects.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {modules.map((m) => {
              const Icon = m.icon;
              return (
                <div
                  key={m.title}
                  onClick={() => onNavigateDirect(m.action)}
                  className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs hover:shadow-md transition-all cursor-pointer group"
                >
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-4 ${m.color}`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                    {m.title}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 leading-relaxed">
                    {m.desc}
                  </p>
                  <div className="mt-4 flex items-center gap-1 text-xs font-semibold text-blue-600 dark:text-blue-400">
                    <span>Open Module</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* 4. COMPARISON: MANUAL VS TAXWISE */}
      <section className="py-20 px-6">
        <div className="max-w-5xl mx-auto space-y-12">
          <div className="text-center max-w-2xl mx-auto space-y-3">
            <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider">
              Methodology
            </span>
            <h2 className="text-3xl font-extrabold tracking-tight text-slate-950 dark:text-white">
              Why Financial Analysts Choose TaxWise
            </h2>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden">
              <thead className="bg-slate-50 dark:bg-slate-900 text-slate-700 dark:text-slate-300 font-semibold border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="py-3.5 px-4">Financial Capability</th>
                  <th className="py-3.5 px-4 text-slate-400">Traditional Excel Spreadsheets</th>
                  <th className="py-3.5 px-4 text-blue-600 dark:text-blue-400 bg-blue-50/50 dark:bg-blue-950/20">TaxWise Platform</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-600 dark:text-slate-400">
                <tr>
                  <td className="py-3 px-4 font-semibold text-slate-900 dark:text-slate-200">Statutory Tax Engine</td>
                  <td className="py-3 px-4">Prone to formula breaks and manual override errors</td>
                  <td className="py-3 px-4 text-blue-700 dark:text-blue-300 bg-blue-50/30 dark:bg-blue-950/10 font-medium">Sec 115BAA formulaic rules + cess & surcharge automation</td>
                </tr>
                <tr>
                  <td className="py-3 px-4 font-semibold text-slate-900 dark:text-slate-200">Forecasting Math</td>
                  <td className="py-3 px-4">Static gut-feel extrapolations without confidence intervals</td>
                  <td className="py-3 px-4 text-blue-700 dark:text-blue-300 bg-blue-50/30 dark:bg-blue-950/10 font-medium">OLS Linear Regression, Moving Averages, and Holt's models</td>
                </tr>
                <tr>
                  <td className="py-3 px-4 font-semibold text-slate-900 dark:text-slate-200">Risk Assessment</td>
                  <td className="py-3 px-4">Siloed audit notes scattered across email threads</td>
                  <td className="py-3 px-4 text-blue-700 dark:text-blue-300 bg-blue-50/30 dark:bg-blue-950/10 font-medium">Interactive 5x5 Probability × Financial Impact scoring</td>
                </tr>
                <tr>
                  <td className="py-3 px-4 font-semibold text-slate-900 dark:text-slate-200">Multi-Entity Support</td>
                  <td className="py-3 px-4">Separate disconnected workbook files per legal entity</td>
                  <td className="py-3 px-4 text-blue-700 dark:text-blue-300 bg-blue-50/30 dark:bg-blue-950/10 font-medium">Instant company switching with synchronized calculations</td>
                </tr>
                <tr>
                  <td className="py-3 px-4 font-semibold text-slate-900 dark:text-slate-200">Audit Preparation</td>
                  <td className="py-3 px-4">Scrambling through folders during tax notice deadlines</td>
                  <td className="py-3 px-4 text-blue-700 dark:text-blue-300 bg-blue-50/30 dark:bg-blue-950/10 font-medium">Pre-audited 9-category checklist with 87% readiness tracking</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* 5. FOOTER */}
      <footer className="py-12 px-6 border-t border-slate-200/80 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-blue-600" />
            <span className="font-bold text-slate-900 dark:text-slate-100">TaxWise</span>
            <span>· Intelligent Tax Analysis, Forecasting & Compliance</span>
          </div>
          <div>
            Portfolio project for Junior Financial Analyst – Taxation role.
          </div>
        </div>
      </footer>
    </div>
  );
};
