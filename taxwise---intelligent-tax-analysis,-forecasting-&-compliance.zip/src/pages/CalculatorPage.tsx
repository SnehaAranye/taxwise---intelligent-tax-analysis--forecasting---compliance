import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { api } from '../services/api';
import { TaxCalculation, DeductionItem } from '../types';
import {
  Calculator,
  Plus,
  Trash2,
  Save,
  FileDown,
  RefreshCw,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  TrendingDown,
  History,
} from 'lucide-react';

interface CalculatorPageProps {
  onNavigate: (page: string) => void;
}

export const CalculatorPage: React.FC<CalculatorPageProps> = ({ onNavigate }) => {
  const { selectedCompanyId, financialYear, showToast } = useApp();

  // Financial Inputs state
  const [revenue, setRevenue] = useState<number>(124000000);
  const [operatingExpenses, setOperatingExpenses] = useState<number>(28500000);
  const [employeeExpenses, setEmployeeExpenses] = useState<number>(34500000);
  const [depreciation, setDepreciation] = useState<number>(8200000);
  const [otherExpenses, setOtherExpenses] = useState<number>(4600000);
  const [advanceTaxPaid, setAdvanceTaxPaid] = useState<number>(6500000);
  const [tdsCredit, setTdsCredit] = useState<number>(2000000);
  const [matCreditUtilized, setMatCreditUtilized] = useState<number>(0);
  const [customTaxRate, setCustomTaxRate] = useState<number>(22.0); // Base rate

  const [deductions, setDeductions] = useState<DeductionItem[]>([
    {
      id: 'ded_1',
      section: 'Section 80JJAA',
      name: 'Employment Generation Incentive (42 Tech Roles)',
      amount: 2500000,
      description: '30% additional salary deduction',
    },
    {
      id: 'ded_2',
      section: 'Section 35(2AB)',
      name: 'Scientific R&D Expenditure (AI Architecture)',
      amount: 1700000,
      description: 'In-house software testing facility',
    },
  ]);

  const [notes, setNotes] = useState('FY 2026-27 Corporate Tax Liability Computation');
  const [calculationResult, setCalculationResult] = useState<TaxCalculation | null>(null);
  const [calculating, setCalculating] = useState(false);
  const [history, setHistory] = useState<TaxCalculation[]>([]);

  // Format currency helper
  const fmt = (val: number) => `₹${val.toLocaleString('en-IN')}`;
  const fmtCr = (val: number) => {
    if (val >= 10000000) return `₹${(val / 10000000).toFixed(2)} Cr`;
    if (val >= 100000) return `₹${(val / 100000).toFixed(2)} L`;
    return `₹${val.toLocaleString('en-IN')}`;
  };

  const handleCalculate = async () => {
    setCalculating(true);
    try {
      const res = await api.calculateTax({
        companyId: selectedCompanyId,
        financialYear,
        revenue,
        operatingExpenses,
        employeeExpenses,
        depreciation,
        otherExpenses,
        deductions,
        advanceTaxPaid,
        tdsCredit,
        matCreditUtilized,
        customBaseTaxRate: customTaxRate,
        notes,
      });
      setCalculationResult(res);
      showToast('Tax liability computed successfully via backend engine.', 'success');
      loadHistory();
    } catch (err: any) {
      showToast(err.message || 'Calculation error', 'error');
    } finally {
      setCalculating(false);
    }
  };

  const loadHistory = async () => {
    try {
      const data = await api.getTaxCalculations(selectedCompanyId);
      setHistory(data);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    handleCalculate();
    loadHistory();
  }, [selectedCompanyId]);

  const addDeduction = () => {
    const newItem: DeductionItem = {
      id: `ded_${Date.now()}`,
      section: 'Section 80JJAA',
      name: 'Additional Allowable Deduction',
      amount: 500000,
      description: 'Statutory qualification allowance',
    };
    setDeductions([...deductions, newItem]);
  };

  const removeDeduction = (id: string) => {
    setDeductions(deductions.filter((d) => d.id !== id));
  };

  const updateDeduction = (id: string, updates: Partial<DeductionItem>) => {
    setDeductions(deductions.map((d) => (d.id === id ? { ...d, ...updates } : d)));
  };

  const totalExpenses = operatingExpenses + employeeExpenses + depreciation + otherExpenses;
  const pbt = Math.max(0, revenue - totalExpenses);
  const totalDeductions = deductions.reduce((acc, item) => acc + (Number(item.amount) || 0), 0);
  const taxableIncome = Math.max(0, pbt - totalDeductions);

  const handleExportReport = async () => {
    try {
      await api.createReport({
        companyId: selectedCompanyId,
        reportType: 'Tax Liability',
        title: `Tax Liability Report - ${financialYear}`,
        summary: `Computed PBT: ${fmtCr(pbt)}, Gross Tax: ${fmtCr(calculationResult?.grossTax || 0)}, Net Payable: ${fmtCr(calculationResult?.estimatedTaxPayable || 0)}.`,
        data: calculationResult,
      });
      showToast('Tax liability report generated and saved to Report Center.', 'success');
      onNavigate('reports');
    } catch (err: any) {
      showToast('Failed to save report: ' + err.message, 'error');
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 dark:text-white flex items-center gap-2.5">
            <Calculator className="w-7 h-7 text-blue-600" />
            <span>Corporate Tax Calculator</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Section 115BAA corporate tax computation with deductions, cess, surcharge, and advance tax credits.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportReport}
            className="px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800 rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <FileDown className="w-3.5 h-3.5" />
            <span>Export Report</span>
          </button>
          <button
            onClick={handleCalculate}
            disabled={calculating}
            className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${calculating ? 'animate-spin' : ''}`} />
            <span>Calculate Tax</span>
          </button>
        </div>
      </div>

      {/* Two-Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* LEFT COLUMN: Financial Inputs */}
        <div className="lg:col-span-6 space-y-5">
          <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 border-b border-slate-100 dark:border-slate-800 pb-3">
              1. Financial & Operational Inputs
            </h3>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Gross Revenue (₹)
              </label>
              <input
                type="number"
                min="0"
                value={revenue}
                onChange={(e) => setRevenue(Number(e.target.value))}
                className="w-full px-3.5 py-2 text-xs font-mono-numbers bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
              />
              <span className="text-[11px] text-slate-400 mt-1 block">In Words: {fmtCr(revenue)}</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Operating Expenses (₹)
                </label>
                <input
                  type="number"
                  min="0"
                  value={operatingExpenses}
                  onChange={(e) => setOperatingExpenses(Number(e.target.value))}
                  className="w-full px-3.5 py-2 text-xs font-mono-numbers bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Employee Costs / Payroll (₹)
                </label>
                <input
                  type="number"
                  min="0"
                  value={employeeExpenses}
                  onChange={(e) => setEmployeeExpenses(Number(e.target.value))}
                  className="w-full px-3.5 py-2 text-xs font-mono-numbers bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Depreciation & Amortization (₹)
                </label>
                <input
                  type="number"
                  min="0"
                  value={depreciation}
                  onChange={(e) => setDepreciation(Number(e.target.value))}
                  className="w-full px-3.5 py-2 text-xs font-mono-numbers bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Other Statutory Expenses (₹)
                </label>
                <input
                  type="number"
                  min="0"
                  value={otherExpenses}
                  onChange={(e) => setOtherExpenses(Number(e.target.value))}
                  className="w-full px-3.5 py-2 text-xs font-mono-numbers bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Deductions Sub-Panel */}
          <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                  2. Allowable Deductions & Exemptions
                </h3>
                <p className="text-xs text-slate-400">Total Deductions: {fmtCr(totalDeductions)}</p>
              </div>
              <button
                onClick={addDeduction}
                className="px-2.5 py-1 text-xs font-medium text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/60 rounded-lg hover:bg-blue-100 transition-colors flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Line</span>
              </button>
            </div>

            <div className="space-y-3">
              {deductions.map((ded) => (
                <div
                  key={ded.id}
                  className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200/60 dark:border-slate-700/60 space-y-2"
                >
                  <div className="flex items-center justify-between gap-2">
                    <select
                      value={ded.section}
                      onChange={(e) => updateDeduction(ded.id, { section: e.target.value })}
                      className="text-xs font-semibold bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-lg px-2 py-1 text-slate-900 dark:text-slate-100"
                    >
                      <option value="Section 80JJAA">Section 80JJAA (New Employees)</option>
                      <option value="Section 35(2AB)">Section 35(2AB) (R&D)</option>
                      <option value="Section 32(1)(iia)">Section 32(1)(iia) (Addl Depr)</option>
                      <option value="Section 80G">Section 80G (CSR Donations)</option>
                      <option value="Other Allowable">Other Allowable Deduction</option>
                    </select>

                    <button
                      onClick={() => removeDeduction(ded.id)}
                      className="text-slate-400 hover:text-rose-500 p-1 transition-colors cursor-pointer"
                      title="Remove"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <input
                      type="text"
                      placeholder="Description label"
                      value={ded.name}
                      onChange={(e) => updateDeduction(ded.id, { name: e.target.value })}
                      className="px-2.5 py-1 text-xs bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-lg text-slate-900 dark:text-slate-100"
                    />
                    <input
                      type="number"
                      min="0"
                      value={ded.amount}
                      onChange={(e) => updateDeduction(ded.id, { amount: Number(e.target.value) })}
                      className="px-2.5 py-1 text-xs font-mono-numbers bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-lg text-slate-900 dark:text-slate-100"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Credits & Statutory Rate */}
          <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 border-b border-slate-100 dark:border-slate-800 pb-3">
              3. Tax Credits & Statutory Rate Parameters
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Advance Tax Paid (₹)
                </label>
                <input
                  type="number"
                  min="0"
                  value={advanceTaxPaid}
                  onChange={(e) => setAdvanceTaxPaid(Number(e.target.value))}
                  className="w-full px-3 py-2 text-xs font-mono-numbers bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  TDS Credits (26AS) (₹)
                </label>
                <input
                  type="number"
                  min="0"
                  value={tdsCredit}
                  onChange={(e) => setTdsCredit(Number(e.target.value))}
                  className="w-full px-3 py-2 text-xs font-mono-numbers bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Base Corporate Rate (%)
                </label>
                <input
                  type="number"
                  step="0.1"
                  value={customTaxRate}
                  onChange={(e) => setCustomTaxRate(Number(e.target.value))}
                  className="w-full px-3 py-2 text-xs font-mono-numbers bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
                />
              </div>
            </div>
            <p className="text-[11px] text-slate-400">
              * Statutory effective rate includes 10% Surcharge and 4% Health & Education Cess (Base 22% → 25.17%).
            </p>
          </div>
        </div>

        {/* RIGHT COLUMN: Tax Calculation Summary */}
        <div className="lg:col-span-6 space-y-5">
          <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs space-y-5 sticky top-20">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                Tax Calculation Summary
              </h3>
              <span className="text-[11px] font-semibold text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/60 px-2 py-0.5 rounded-md">
                Section 115BAA
              </span>
            </div>

            {/* Step-by-Step Mathematical Waterfall */}
            <div className="space-y-2.5 text-xs">
              <div className="flex items-center justify-between py-1">
                <span className="text-slate-600 dark:text-slate-400 font-medium">Gross Revenue</span>
                <span className="font-mono-numbers font-semibold text-slate-900 dark:text-slate-100">
                  {fmt(revenue)}
                </span>
              </div>

              <div className="flex items-center justify-between py-1 text-slate-500">
                <span>− Total Operating Expenses</span>
                <span className="font-mono-numbers">({fmt(totalExpenses)})</span>
              </div>

              <div className="flex items-center justify-between py-1.5 border-t border-slate-100 dark:border-slate-800 font-semibold">
                <span className="text-slate-800 dark:text-slate-200">= Profit Before Tax (PBT)</span>
                <span className="font-mono-numbers text-slate-900 dark:text-slate-100">{fmt(pbt)}</span>
              </div>

              <div className="flex items-center justify-between py-1 text-emerald-600 dark:text-emerald-400">
                <span>− Allowable Deductions (Sec 80JJAA/35)</span>
                <span className="font-mono-numbers">({fmt(totalDeductions)})</span>
              </div>

              <div className="flex items-center justify-between py-1.5 border-t border-slate-100 dark:border-slate-800 font-semibold bg-slate-50 dark:bg-slate-800/40 p-2 rounded-lg">
                <span className="text-slate-800 dark:text-slate-200">= Taxable Income</span>
                <span className="font-mono-numbers text-blue-600 dark:text-blue-400">{fmt(taxableIncome)}</span>
              </div>

              <div className="flex items-center justify-between py-1 text-slate-500">
                <span>× Effective Statutory Rate (22% + 10% + 4%)</span>
                <span className="font-mono-numbers">{calculationResult?.taxRate || 25.17}%</span>
              </div>

              <div className="flex items-center justify-between py-1.5 border-t border-slate-100 dark:border-slate-800 font-semibold">
                <span className="text-slate-800 dark:text-slate-200">= Gross Corporate Tax</span>
                <span className="font-mono-numbers text-slate-900 dark:text-slate-100">
                  {fmt(calculationResult?.grossTax || 0)}
                </span>
              </div>

              <div className="flex items-center justify-between py-1 text-emerald-600 dark:text-emerald-400">
                <span>− Advance Tax Paid & TDS Credits</span>
                <span className="font-mono-numbers">({fmt(advanceTaxPaid + tdsCredit)})</span>
              </div>

              {/* Final Payable Callout */}
              <div className="p-4 bg-linear-to-br from-blue-50 to-indigo-50 dark:from-blue-950/40 dark:to-indigo-950/40 rounded-xl border border-blue-200/80 dark:border-blue-900/80 mt-4 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                    Estimated Tax Payable
                  </span>
                  <span className="text-xl font-extrabold text-blue-700 dark:text-blue-300 font-mono-numbers">
                    {fmt(calculationResult?.estimatedTaxPayable || 0)}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 pt-2 border-t border-blue-200/60 dark:border-blue-900/60 text-xs">
                  <div>
                    <span className="text-[11px] text-slate-500 dark:text-slate-400 block">Effective Tax Rate</span>
                    <span className="text-sm font-bold text-slate-800 dark:text-slate-200 font-mono-numbers">
                      {calculationResult?.effectiveTaxRate || 22.98}%
                    </span>
                  </div>
                  <div>
                    <span className="text-[11px] text-slate-500 dark:text-slate-400 block">Net Profit After Tax</span>
                    <span className="text-sm font-bold text-emerald-600 dark:text-emerald-400 font-mono-numbers">
                      {fmtCr(calculationResult?.netProfitAfterTax || 0)}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div className="pt-2 flex items-center justify-between text-xs">
              <span className="text-slate-400">Status: Calculated via API</span>
              <button
                onClick={handleCalculate}
                className="font-semibold text-blue-600 dark:text-blue-400 hover:underline cursor-pointer"
              >
                Recalculate Model
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
