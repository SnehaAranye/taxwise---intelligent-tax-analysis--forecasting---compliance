import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { api } from '../services/api';
import { Report } from '../types';
import { Modal } from '../components/common/Modal';
import {
  FileText,
  Printer,
  Download,
  Eye,
  Calendar,
  Building2,
  CheckCircle2,
  ShieldCheck,
  Plus,
} from 'lucide-react';

export const ReportsPage: React.FC = () => {
  const { selectedCompanyId, selectedCompany, financialYear, showToast } = useApp();
  const [reports, setReports] = useState<Report[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeReport, setActiveReport] = useState<Report | null>(null);
  const [previewOpen, setPreviewOpen] = useState(false);

  const loadReports = async () => {
    setLoading(true);
    try {
      const data = await api.getReports(selectedCompanyId);
      setReports(data);
    } catch (err: any) {
      showToast(err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadReports();
  }, [selectedCompanyId]);

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadCSV = (rep: Report) => {
    const csvContent =
      'data:text/csv;charset=utf-8,' +
      `Report Title,${rep.title}\n` +
      `Company,${selectedCompany?.name || 'Apex Technologies'}\n` +
      `Financial Year,${rep.financialYear}\n` +
      `Generated Date,${rep.generatedDate}\n` +
      `Summary,"${rep.summary.replace(/"/g, '""')}"\n\n` +
      `Key Data Metrics\n` +
      Object.entries(rep.data || {})
        .map(([k, v]) => `${k},${typeof v === 'object' ? JSON.stringify(v) : v}`)
        .join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `${rep.reportType.replace(/\s+/g, '_')}_Report.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('Report CSV downloaded successfully.', 'success');
  };

  const handleOpenPreview = (rep: Report) => {
    setActiveReport(rep);
    setPreviewOpen(true);
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 dark:text-white flex items-center gap-2.5">
            <FileText className="w-7 h-7 text-blue-600" />
            <span>Executive Report Center</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Formal statutory liability audits, forecasts, compliance status schedules, and tax efficiency studies.
          </p>
        </div>
      </div>

      {/* Reports Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {reports.map((rep) => (
          <div
            key={rep.id}
            className="p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs hover:shadow-xs transition-all flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between text-xs mb-2">
                <span className="px-2 py-0.5 rounded-md font-semibold bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300">
                  {rep.reportType}
                </span>
                <span className="text-[11px] font-mono-numbers text-slate-400">
                  {new Date(rep.generatedDate).toLocaleDateString()}
                </span>
              </div>

              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">{rep.title}</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 line-clamp-3 leading-relaxed">
                {rep.summary}
              </p>

              <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-400 space-y-1">
                <div className="flex justify-between">
                  <span>Organization:</span>
                  <span className="text-slate-700 dark:text-slate-300 font-medium">
                    {selectedCompany?.name}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Author:</span>
                  <span className="text-slate-700 dark:text-slate-300">{rep.generatedBy}</span>
                </div>
              </div>
            </div>

            <div className="mt-5 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <button
                onClick={() => handleOpenPreview(rep)}
                className="px-3 py-1.5 text-xs font-semibold text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/60 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Eye className="w-3.5 h-3.5" />
                <span>Preview</span>
              </button>

              <div className="flex items-center gap-1">
                <button
                  onClick={() => handleDownloadCSV(rep)}
                  className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                  title="Export CSV"
                >
                  <Download className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => {
                    setActiveReport(rep);
                    setPreviewOpen(true);
                    setTimeout(() => window.print(), 300);
                  }}
                  className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                  title="Print / Save PDF"
                >
                  <Printer className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Report Preview Modal (with Print Format) */}
      <Modal
        isOpen={previewOpen}
        onClose={() => setPreviewOpen(false)}
        title="Statutory Financial Report Preview"
        subtitle="Formatted for board submission and regulatory compliance"
        maxWidth="max-w-3xl"
      >
        {activeReport && (
          <div className="space-y-6 text-xs text-slate-700 dark:text-slate-300">
            {/* Report Header */}
            <div className="p-6 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200/80 dark:border-slate-700/60 space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-700">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-blue-600 text-white flex items-center justify-center font-bold">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <h2 className="text-base font-extrabold text-slate-900 dark:text-slate-100">
                      TaxWise Financial Intelligence
                    </h2>
                    <span className="text-[10px] text-slate-400 block uppercase tracking-wider">
                      Taxation & Compliance Practice Division
                    </span>
                  </div>
                </div>

                <div className="text-right text-[11px] font-mono-numbers text-slate-500">
                  <div>Ref: REP-{activeReport.id.toUpperCase()}</div>
                  <div>Date: {new Date(activeReport.generatedDate).toLocaleDateString()}</div>
                </div>
              </div>

              {/* Company & Entity Summary */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div>
                  <span className="text-slate-400 text-[10px] block">Company Name:</span>
                  <span className="font-bold text-slate-900 dark:text-slate-100">
                    {selectedCompany?.name}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 text-[10px] block">PAN & GSTIN:</span>
                  <span className="font-mono-numbers font-semibold">
                    {selectedCompany?.pan} / {selectedCompany?.gstin}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 text-[10px] block">Financial Year:</span>
                  <span className="font-bold">{activeReport.financialYear}</span>
                </div>
                <div>
                  <span className="text-slate-400 text-[10px] block">Assessing Officer / Lead:</span>
                  <span className="font-medium">{activeReport.generatedBy}</span>
                </div>
              </div>
            </div>

            {/* Document Title & Executive Summary */}
            <div className="space-y-2">
              <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
                {activeReport.title}
              </h3>
              <p className="text-slate-600 dark:text-slate-400 leading-relaxed text-xs p-3 bg-slate-50 dark:bg-slate-800/30 rounded-xl border border-slate-100 dark:border-slate-800">
                {activeReport.summary}
              </p>
            </div>

            {/* Structured Table / Key Metrics */}
            {activeReport.data && (
              <div className="space-y-2">
                <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider">
                  Quantitative Schedule Breakdown
                </h4>
                <div className="overflow-x-auto border border-slate-200 dark:border-slate-800 rounded-xl">
                  <table className="w-full text-left text-xs font-mono-numbers">
                    <thead className="bg-slate-50 dark:bg-slate-800/60 font-semibold border-b border-slate-200 dark:border-slate-700">
                      <tr>
                        <th className="py-2.5 px-3">Statutory Metric</th>
                        <th className="py-2.5 px-3 text-right">Computed Value</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {Object.entries(activeReport.data).map(([key, val]) => {
                        if (typeof val === 'object') return null;
                        const label = key
                          .replace(/([A-Z])/g, ' $1')
                          .replace(/^./, (str) => str.toUpperCase());
                        return (
                          <tr key={key}>
                            <td className="py-2 px-3 text-slate-600 dark:text-slate-300 font-sans">
                              {label}
                            </td>
                            <td className="py-2 px-3 text-right font-bold text-slate-900 dark:text-slate-100">
                              {typeof val === 'number'
                                ? val > 1000
                                  ? `₹${val.toLocaleString('en-IN')}`
                                  : `${val}%`
                                : String(val)}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Methodology & Legal Notice */}
            <div className="pt-4 border-t border-slate-200 dark:border-slate-800 space-y-2 text-[11px] text-slate-400">
              <p>
                <strong>Methodology & Computation Standards:</strong> Prepared strictly under Indian Income Tax Act 1961 Section 115BAA corporate provisions with statutory surcharge (10%) and health and education cess (4%).
              </p>
              <p>
                <em>Confidential. Prepared for internal executive financial planning and audit review only.</em>
              </p>
            </div>

            {/* Actions Bar */}
            <div className="flex items-center justify-end gap-3 pt-3">
              <button
                type="button"
                onClick={() => handleDownloadCSV(activeReport)}
                className="px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl hover:bg-slate-50 transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export CSV</span>
              </button>
              <button
                type="button"
                onClick={handlePrint}
                className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print / Save as PDF</span>
              </button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};
