import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { api } from '../services/api';
import { Transaction, TransactionCategory } from '../types';
import { Modal } from '../components/common/Modal';
import {
  Receipt,
  Plus,
  Trash2,
  Edit2,
  Search,
  Filter,
  ArrowUpDown,
  ChevronLeft,
  ChevronRight,
  TrendingDown,
  TrendingUp,
} from 'lucide-react';

export const TransactionsPage: React.FC = () => {
  const { selectedCompanyId, showToast } = useApp();
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [monthlySummary, setMonthlySummary] = useState<Record<string, { revenue: number; expense: number; tax: number }>>({});
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(true);

  // Filters
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');
  const [type, setType] = useState('All');

  // Modal State
  const [modalOpen, setModalOpen] = useState(false);
  const [editingTx, setEditingTx] = useState<Transaction | null>(null);
  const [date, setDate] = useState(new Date().toISOString().substring(0, 10));
  const [description, setDescription] = useState('');
  const [txCategory, setTxCategory] = useState<TransactionCategory>('Operating Expense');
  const [txType, setTxType] = useState<'credit' | 'debit'>('debit');
  const [amount, setAmount] = useState<number>(100000);
  const [taxCategory, setTaxCategory] = useState('GST 18%');
  const [taxAmount, setTaxAmount] = useState<number>(18000);
  const [paymentStatus, setPaymentStatus] = useState<'Paid' | 'Pending' | 'Scheduled'>('Paid');
  const [referenceNo, setReferenceNo] = useState('');

  const fmt = (val: number) => `₹${val.toLocaleString('en-IN')}`;
  const fmtCr = (val: number) => {
    if (val >= 10000000) return `₹${(val / 10000000).toFixed(2)} Cr`;
    if (val >= 100000) return `₹${(val / 100000).toFixed(2)} L`;
    return `₹${val.toLocaleString('en-IN')}`;
  };

  const loadTransactions = async () => {
    setLoading(true);
    try {
      const data = await api.getTransactions({
        companyId: selectedCompanyId,
        search,
        category: category !== 'All' ? category : undefined,
        type: type !== 'All' ? type : undefined,
        page,
        limit: 10,
      });
      setTransactions(data.items);
      setTotal(data.total);
      setTotalPages(data.totalPages);
      setMonthlySummary(data.monthlySummary || {});
    } catch (err: any) {
      showToast(err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadTransactions();
  }, [selectedCompanyId, search, category, type, page]);

  const handleOpenCreate = () => {
    setEditingTx(null);
    setDate(new Date().toISOString().substring(0, 10));
    setDescription('');
    setTxCategory('Operating Expense');
    setTxType('debit');
    setAmount(150000);
    setTaxCategory('GST 18%');
    setTaxAmount(27000);
    setPaymentStatus('Paid');
    setReferenceNo(`INV-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`);
    setModalOpen(true);
  };

  const handleOpenEdit = (t: Transaction) => {
    setEditingTx(t);
    setDate(t.date);
    setDescription(t.description);
    setTxCategory(t.category);
    setTxType(t.type);
    setAmount(t.amount);
    setTaxCategory(t.taxCategory);
    setTaxAmount(t.taxAmount);
    setPaymentStatus(t.paymentStatus);
    setReferenceNo(t.referenceNo);
    setModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingTx) {
        await api.updateTransaction(editingTx.id, {
          date,
          description,
          category: txCategory,
          type: txType,
          amount: Number(amount),
          taxCategory,
          taxAmount: Number(taxAmount),
          paymentStatus,
          referenceNo,
        });
        showToast('Transaction updated successfully.', 'success');
      } else {
        await api.createTransaction({
          companyId: selectedCompanyId,
          date,
          description,
          category: txCategory,
          type: txType,
          amount: Number(amount),
          taxCategory,
          taxAmount: Number(taxAmount),
          paymentStatus,
          referenceNo,
        });
        showToast('Transaction logged in financial ledger.', 'success');
      }
      setModalOpen(false);
      loadTransactions();
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await api.deleteTransaction(id);
      showToast('Transaction deleted.', 'info');
      loadTransactions();
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  // Recent month summaries array
  const months = Object.keys(monthlySummary).sort().reverse().slice(0, 4);

  return (
    <div className="space-y-8 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 dark:text-white flex items-center gap-2.5">
            <Receipt className="w-7 h-7 text-blue-600" />
            <span>Transaction Management</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Corporate general ledger with GST and TDS classifications, invoice matching, and monthly aggregate rollups.
          </p>
        </div>

        <button
          onClick={handleOpenCreate}
          className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs transition-colors flex items-center gap-2 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Add Transaction</span>
        </button>
      </div>

      {/* Monthly Aggregate Summaries (Auto Generated) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {months.map((m) => {
          const sum = monthlySummary[m];
          const net = sum.revenue - sum.expense;
          return (
            <div key={m} className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-slate-900 dark:text-slate-100">{m} Summary</span>
                <span className={`font-mono-numbers font-semibold ${net >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                  Net: {fmtCr(net)}
                </span>
              </div>
              <div className="space-y-1 text-[11px] font-mono-numbers text-slate-500 dark:text-slate-400 pt-1 border-t border-slate-100 dark:border-slate-800">
                <div className="flex justify-between">
                  <span>Revenue Inflows:</span>
                  <span className="text-emerald-600 font-medium">{fmtCr(sum.revenue)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Operating Expenses:</span>
                  <span className="text-slate-700 dark:text-slate-300 font-medium">{fmtCr(sum.expense)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Statutory Tax Withheld:</span>
                  <span className="text-blue-600 font-medium">{fmtCr(sum.tax)}</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Search & Filter Bar */}
      <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs flex flex-wrap items-center justify-between gap-4 text-xs">
        {/* Search */}
        <div className="flex-1 min-w-[240px] max-w-md relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search description, reference no, or category..."
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setPage(1);
            }}
            className="w-full pl-9 pr-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 focus:outline-none"
          />
        </div>

        {/* Filter Dropdowns */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1.5">
            <span className="text-slate-500 dark:text-slate-400 font-semibold">Category:</span>
            <select
              value={category}
              onChange={(e) => {
                setCategory(e.target.value);
                setPage(1);
              }}
              className="px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 focus:outline-none"
            >
              <option value="All">All Categories</option>
              <option value="Revenue">Revenue</option>
              <option value="Operating Expense">Operating Expense</option>
              <option value="Payroll">Payroll</option>
              <option value="Capital Expense">Capital Expense</option>
              <option value="Tax Payment">Tax Payment</option>
              <option value="Other">Other</option>
            </select>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-slate-500 dark:text-slate-400 font-semibold">Type:</span>
            <select
              value={type}
              onChange={(e) => {
                setType(e.target.value);
                setPage(1);
              }}
              className="px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 focus:outline-none"
            >
              <option value="All">All Types</option>
              <option value="credit">Revenue / Credit</option>
              <option value="debit">Expense / Debit</option>
            </select>
          </div>
        </div>
      </div>

      {/* Transactions Table */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/50 text-slate-600 dark:text-slate-400 font-semibold border-b border-slate-200 dark:border-slate-700">
              <tr>
                <th className="py-3 px-4">Date</th>
                <th className="py-3 px-4">Description & Ref No</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4 text-right">Amount (₹)</th>
                <th className="py-3 px-4">Tax Category</th>
                <th className="py-3 px-4 text-right">Tax Amount (₹)</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {transactions.map((t) => (
                <tr key={t.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors">
                  <td className="py-3.5 px-4 font-mono-numbers text-slate-500">{t.date}</td>
                  <td className="py-3.5 px-4">
                    <div className="font-semibold text-slate-900 dark:text-slate-100">{t.description}</div>
                    <div className="text-[11px] font-mono-numbers text-slate-400">Ref: {t.referenceNo}</div>
                  </td>
                  <td className="py-3.5 px-4">
                    <span className="px-2 py-0.5 rounded-md text-[11px] font-medium bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                      {t.category}
                    </span>
                  </td>
                  <td className={`py-3.5 px-4 text-right font-mono-numbers font-bold ${
                    t.type === 'credit' ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-900 dark:text-slate-100'
                  }`}>
                    {t.type === 'credit' ? '+' : '-'}{fmt(t.amount)}
                  </td>
                  <td className="py-3.5 px-4 text-slate-600 dark:text-slate-300 font-medium">
                    {t.taxCategory}
                  </td>
                  <td className="py-3.5 px-4 text-right font-mono-numbers text-blue-600 dark:text-blue-400 font-semibold">
                    {fmt(t.taxAmount)}
                  </td>
                  <td className="py-3.5 px-4">
                    <span className={`text-[11px] font-semibold ${
                      t.paymentStatus === 'Paid' ? 'text-emerald-600' : t.paymentStatus === 'Pending' ? 'text-amber-500' : 'text-blue-600'
                    }`}>
                      {t.paymentStatus}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={() => handleOpenEdit(t)}
                        className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                        title="Edit"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDelete(t.id)}
                        className="p-1.5 text-slate-400 hover:text-rose-500 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                        title="Delete"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination Bar */}
        <div className="p-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
          <div>
            Showing {transactions.length} of {total} transactions
          </div>
          <div className="flex items-center gap-2">
            <button
              disabled={page <= 1}
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 disabled:opacity-40 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="font-mono-numbers">
              Page {page} of {Math.max(1, totalPages)}
            </span>
            <button
              disabled={page >= totalPages}
              onClick={() => setPage((p) => p + 1)}
              className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 disabled:opacity-40 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Add / Edit Transaction Modal */}
      <Modal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editingTx ? 'Edit Transaction Record' : 'Record Financial Transaction'}
        subtitle="Specify tax category and payment status"
      >
        <form onSubmit={handleSave} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Transaction Date
              </label>
              <input
                type="date"
                required
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Reference / Invoice No
              </label>
              <input
                type="text"
                required
                value={referenceNo}
                onChange={(e) => setReferenceNo(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Description
            </label>
            <input
              type="text"
              required
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g. AWS Cloud Hosting Infrastructure Invoice"
              className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Category
              </label>
              <select
                value={txCategory}
                onChange={(e) => setTxCategory(e.target.value as any)}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
              >
                <option value="Revenue">Revenue</option>
                <option value="Operating Expense">Operating Expense</option>
                <option value="Payroll">Payroll</option>
                <option value="Capital Expense">Capital Expense</option>
                <option value="Tax Payment">Tax Payment</option>
                <option value="Other">Other</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Entry Type
              </label>
              <select
                value={txType}
                onChange={(e) => setTxType(e.target.value as any)}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
              >
                <option value="debit">Debit (Expense)</option>
                <option value="credit">Credit (Revenue / Inflow)</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Gross Amount (₹)
              </label>
              <input
                type="number"
                min="1"
                required
                value={amount}
                onChange={(e) => {
                  const val = Number(e.target.value);
                  setAmount(val);
                  setTaxAmount(Math.round(val * 0.18));
                }}
                className="w-full px-3 py-2 text-xs font-mono-numbers bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Tax Amount Withheld / Charged (₹)
              </label>
              <input
                type="number"
                min="0"
                value={taxAmount}
                onChange={(e) => setTaxAmount(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs font-mono-numbers bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Tax Classification
              </label>
              <select
                value={taxCategory}
                onChange={(e) => setTaxCategory(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
              >
                <option value="GST 18%">GST 18%</option>
                <option value="GST 12%">GST 12%</option>
                <option value="GST 5%">GST 5%</option>
                <option value="TDS 194J">TDS 194J (Tech Fees)</option>
                <option value="TDS 192">TDS 192 (Salaries)</option>
                <option value="Direct Tax">Direct Tax (Advance Tax)</option>
                <option value="Exempt">Exempt / Zero Rated</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Settlement Status
              </label>
              <select
                value={paymentStatus}
                onChange={(e) => setPaymentStatus(e.target.value as any)}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
              >
                <option value="Paid">Paid</option>
                <option value="Pending">Pending</option>
                <option value="Scheduled">Scheduled</option>
              </select>
            </div>
          </div>

          <div className="pt-4 flex justify-end gap-2 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-400"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs"
            >
              Save Record
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
