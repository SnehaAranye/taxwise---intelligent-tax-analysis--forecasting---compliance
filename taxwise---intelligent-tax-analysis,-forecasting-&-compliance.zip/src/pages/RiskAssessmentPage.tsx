import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { api } from '../services/api';
import { TaxRisk } from '../types';
import { TaxRiskMatrix } from '../components/charts/FinancialCharts';
import { Modal } from '../components/common/Modal';
import {
  ShieldAlert,
  Plus,
  Trash2,
  Edit2,
  CheckCircle2,
  AlertTriangle,
  Info,
  Sliders,
  Filter,
} from 'lucide-react';

export const RiskAssessmentPage: React.FC = () => {
  const { selectedCompanyId, showToast } = useApp();
  const [risks, setRisks] = useState<TaxRisk[]>([]);
  const [stats, setStats] = useState({
    total: 0,
    criticalCount: 0,
    highCount: 0,
    mediumCount: 0,
    lowCount: 0,
    overallRisk: 'Low' as 'Low' | 'Medium' | 'High' | 'Critical',
  });
  const [loading, setLoading] = useState(true);
  const [filterSeverity, setFilterSeverity] = useState('All');

  // Modal State
  const [modalOpen, setModalOpen] = useState(false);
  const [editingRisk, setEditingRisk] = useState<TaxRisk | null>(null);
  const [riskName, setRiskName] = useState('');
  const [category, setCategory] = useState<TaxRisk['category']>('Transfer Pricing');
  const [description, setDescription] = useState('');
  const [probability, setProbability] = useState<number>(3);
  const [financialImpact, setFinancialImpact] = useState<number>(3);
  const [mitigation, setMitigation] = useState('');
  const [owner, setOwner] = useState('Aditya Sharma');
  const [status, setStatus] = useState<TaxRisk['status']>('Open');

  const loadRisks = async () => {
    setLoading(true);
    try {
      const data = await api.getRisks(selectedCompanyId);
      setRisks(data.risks);
      setStats({
        total: data.total,
        criticalCount: data.criticalCount,
        highCount: data.highCount,
        mediumCount: data.mediumCount,
        lowCount: data.lowCount,
        overallRisk: data.overallRisk,
      });
    } catch (err: any) {
      showToast(err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadRisks();
  }, [selectedCompanyId]);

  const handleOpenCreate = () => {
    setEditingRisk(null);
    setRiskName('');
    setCategory('Transfer Pricing');
    setDescription('');
    setProbability(3);
    setFinancialImpact(3);
    setMitigation('');
    setOwner('Aditya Sharma');
    setStatus('Open');
    setModalOpen(true);
  };

  const handleOpenEdit = (r: TaxRisk) => {
    setEditingRisk(r);
    setRiskName(r.riskName);
    setCategory(r.category);
    setDescription(r.description);
    setProbability(r.probability);
    setFinancialImpact(r.financialImpact);
    setMitigation(r.mitigation);
    setOwner(r.owner);
    setStatus(r.status);
    setModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingRisk) {
        await api.updateRisk(editingRisk.id, {
          riskName,
          category,
          description,
          probability: Number(probability),
          financialImpact: Number(financialImpact),
          mitigation,
          owner,
          status,
        });
        showToast('Tax risk record updated.', 'success');
      } else {
        await api.createRisk({
          companyId: selectedCompanyId,
          riskName,
          category,
          description,
          probability: Number(probability),
          financialImpact: Number(financialImpact),
          mitigation,
          owner,
          status,
        });
        showToast('New tax risk profile cataloged.', 'success');
      }
      setModalOpen(false);
      loadRisks();
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await api.deleteRisk(id);
      showToast('Risk entry deleted.', 'info');
      loadRisks();
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  const filteredRisks = risks.filter((r) => {
    if (filterSeverity !== 'All' && r.severity !== filterSeverity) return false;
    return true;
  });

  const getSeverityBadge = (sev: TaxRisk['severity']) => {
    switch (sev) {
      case 'Critical':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300 border border-rose-200 dark:border-rose-900">
            Critical
          </span>
        );
      case 'High':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300 border border-amber-200 dark:border-amber-900">
            High
          </span>
        );
      case 'Medium':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-yellow-50 text-yellow-700 dark:bg-yellow-950/60 dark:text-yellow-300 border border-yellow-200 dark:border-yellow-900">
            Medium
          </span>
        );
      case 'Low':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-900">
            Low
          </span>
        );
    }
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 dark:text-white flex items-center gap-2.5">
            <ShieldAlert className="w-7 h-7 text-blue-600" />
            <span>Tax Risk Intelligence</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Quantitative exposure scoring: <strong>Risk Score = Probability (1–5) × Financial Impact (1–5)</strong> across statutory tax vectors.
          </p>
        </div>

        <button
          onClick={handleOpenCreate}
          className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs transition-colors flex items-center gap-2 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Catalog Tax Risk</span>
        </button>
      </div>

      {/* Top Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs">
          <span className="text-xs font-medium text-slate-500 dark:text-slate-400">Total Risks Cataloged</span>
          <div className="text-2xl font-extrabold text-slate-900 dark:text-slate-100 font-mono-numbers mt-1">
            {stats.total}
          </div>
          <span className="text-[11px] text-slate-400">Active Exposure Profiles</span>
        </div>

        <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs">
          <span className="text-xs font-medium text-slate-500 dark:text-slate-400">Critical Risks (Score ≥ 16)</span>
          <div className="text-2xl font-extrabold text-rose-600 font-mono-numbers mt-1">
            {stats.criticalCount}
          </div>
          <span className="text-[11px] text-slate-400">Requires Board Notification</span>
        </div>

        <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs">
          <span className="text-xs font-medium text-slate-500 dark:text-slate-400">High Risks (Score ≥ 12)</span>
          <div className="text-2xl font-extrabold text-amber-500 font-mono-numbers mt-1">
            {stats.highCount}
          </div>
          <span className="text-[11px] text-slate-400">Active Legal Review</span>
        </div>

        <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs">
          <span className="text-xs font-medium text-slate-500 dark:text-slate-400">Medium Risks (Score ≥ 6)</span>
          <div className="text-2xl font-extrabold text-yellow-500 font-mono-numbers mt-1">
            {stats.mediumCount}
          </div>
          <span className="text-[11px] text-slate-400">Operational Mitigation</span>
        </div>
      </div>

      {/* 5x5 Heat Matrix Visual */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-6 p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs space-y-4">
          <div className="border-b border-slate-100 dark:border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
              Tax Risk Severity Matrix (5 × 5)
            </h3>
            <p className="text-xs text-slate-400">
              Click individual cell dots to inspect specific risk profiles
            </p>
          </div>

          <TaxRiskMatrix
            risks={risks}
            onSelectRisk={(r) => handleOpenEdit(r)}
          />

          <div className="flex items-center justify-between text-[11px] text-slate-400 pt-2 border-t border-slate-100 dark:border-slate-800">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-xs bg-emerald-500/50" />
              <span>Low (1–5)</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-xs bg-yellow-500/50" />
              <span>Medium (6–11)</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-xs bg-amber-500/50" />
              <span>High (12–15)</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-xs bg-rose-500/50" />
              <span>Critical (16–25)</span>
            </div>
          </div>
        </div>

        {/* Risk Register Summary Card */}
        <div className="lg:col-span-6 p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs space-y-4 flex flex-col justify-between">
          <div>
            <div className="border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                Statutory Exposure Highlights
              </h3>
              <p className="text-xs text-slate-400">
                Key areas under monitoring by Junior Financial Analyst team
              </p>
            </div>

            <div className="divide-y divide-slate-100 dark:divide-slate-800 mt-2">
              <div className="py-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                    Transfer Pricing (Form 3CEB)
                  </span>
                  <span className="text-[11px] font-bold text-amber-600">Score: 12</span>
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 leading-relaxed">
                  Intercompany service billing markup scrutinized at 15% vs industry 17.5% safe-harbor benchmark.
                </p>
              </div>

              <div className="py-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                    GSTR-2B Input Credit Reconciliation
                  </span>
                  <span className="text-[11px] font-bold text-amber-600">Score: 12</span>
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 leading-relaxed">
                  ₹14.8L input tax credit withheld pending vendor quarterly filing reflection.
                </p>
              </div>

              <div className="py-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                    TDS Section 194J vs 194C Classification
                  </span>
                  <span className="text-[11px] font-bold text-emerald-600">Score: 6</span>
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 leading-relaxed">
                  Cloud hosting infrastructure contracts classified at 2% contractor withholding rate.
                </p>
              </div>
            </div>
          </div>

          <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl text-xs text-slate-500 dark:text-slate-400">
            <strong>Mitigation Strategy Protocol:</strong> Automated daily checks against Income Tax Portal e-proceedings registry and GSTIN verification APIs.
          </div>
        </div>
      </div>

      {/* Risk Table */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs overflow-hidden">
        <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
            Active Risk Catalog ({filteredRisks.length})
          </h3>

          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-400">Filter Severity:</span>
            <select
              value={filterSeverity}
              onChange={(e) => setFilterSeverity(e.target.value)}
              className="px-2.5 py-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-800 dark:text-slate-200"
            >
              <option value="All">All Severities</option>
              <option value="Critical">Critical</option>
              <option value="High">High</option>
              <option value="Medium">Medium</option>
              <option value="Low">Low</option>
            </select>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/50 text-slate-600 dark:text-slate-400 font-semibold border-b border-slate-200 dark:border-slate-700">
              <tr>
                <th className="py-3 px-4">Risk Name</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4 text-center">Prob (1–5)</th>
                <th className="py-3 px-4 text-center">Impact (1–5)</th>
                <th className="py-3 px-4 text-center">Score</th>
                <th className="py-3 px-4">Severity</th>
                <th className="py-3 px-4">Mitigation Plan</th>
                <th className="py-3 px-4">Owner</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredRisks.map((r) => (
                <tr key={r.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors">
                  <td className="py-3 px-4">
                    <div className="font-semibold text-slate-900 dark:text-slate-100">{r.riskName}</div>
                    <div className="text-[11px] text-slate-400 mt-0.5 line-clamp-1">{r.description}</div>
                  </td>
                  <td className="py-3 px-4 text-slate-600 dark:text-slate-300 font-medium">{r.category}</td>
                  <td className="py-3 px-4 text-center font-mono-numbers">{r.probability}</td>
                  <td className="py-3 px-4 text-center font-mono-numbers">{r.financialImpact}</td>
                  <td className="py-3 px-4 text-center font-mono-numbers font-bold text-slate-900 dark:text-slate-100">
                    {r.riskScore}
                  </td>
                  <td className="py-3 px-4">{getSeverityBadge(r.severity)}</td>
                  <td className="py-3 px-4 text-slate-500 text-[11px] max-w-xs leading-relaxed">{r.mitigation}</td>
                  <td className="py-3 px-4 text-slate-600 dark:text-slate-300">{r.owner}</td>
                  <td className="py-3 px-4">
                    <span className={`text-[11px] font-semibold ${
                      r.status === 'Resolved' ? 'text-emerald-600' : r.status === 'Mitigating' ? 'text-blue-600' : 'text-amber-600'
                    }`}>
                      {r.status}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={() => handleOpenEdit(r)}
                        className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                        title="Edit"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDelete(r.id)}
                        className="p-1.5 text-slate-400 hover:text-rose-500 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                        title="Delete"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal for Risk Create/Edit */}
      <Modal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editingRisk ? 'Edit Tax Risk' : 'Catalog Tax Risk'}
        subtitle="Configure probability and financial impact parameters"
      >
        <form onSubmit={handleSave} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Risk Name
            </label>
            <input
              type="text"
              required
              value={riskName}
              onChange={(e) => setRiskName(e.target.value)}
              placeholder="e.g. Transfer Pricing Cross-Border Scrutiny"
              className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Category
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as any)}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
              >
                <option value="Transfer Pricing">Transfer Pricing</option>
                <option value="GST Reconciliation">GST Reconciliation</option>
                <option value="TDS Non-Deduction">TDS Non-Deduction</option>
                <option value="Permanent Establishment">Permanent Establishment</option>
                <option value="Depreciation Disallowance">Depreciation Disallowance</option>
                <option value="Section 40A(3) Cash Payments">Section 40A(3) Cash Payments</option>
                <option value="Related Party Transaction">Related Party Transaction</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Risk Status
              </label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as any)}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
              >
                <option value="Open">Open</option>
                <option value="Mitigating">Mitigating</option>
                <option value="Resolved">Resolved</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Exposure Description
            </label>
            <textarea
              rows={2}
              required
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Probability (1: Rare → 5: High)
              </label>
              <input
                type="number"
                min="1"
                max="5"
                value={probability}
                onChange={(e) => setProbability(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs font-mono-numbers bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Financial Impact (1: Low → 5: Critical)
              </label>
              <input
                type="number"
                min="1"
                max="5"
                value={financialImpact}
                onChange={(e) => setFinancialImpact(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs font-mono-numbers bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Mitigation Action Plan
            </label>
            <input
              type="text"
              required
              value={mitigation}
              onChange={(e) => setMitigation(e.target.value)}
              placeholder="e.g. Commission fresh CUP benchmarking analysis report"
              className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Risk Owner
            </label>
            <input
              type="text"
              value={owner}
              onChange={(e) => setOwner(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
            />
          </div>

          <div className="pt-4 flex justify-end gap-2 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-400"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs"
            >
              Save Risk
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
