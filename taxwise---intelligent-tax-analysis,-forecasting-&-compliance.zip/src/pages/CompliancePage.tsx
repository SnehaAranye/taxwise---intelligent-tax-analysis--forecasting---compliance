import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { api } from '../services/api';
import { ComplianceItem } from '../types';
import { Modal } from '../components/common/Modal';
import {
  CalendarCheck,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Plus,
  Trash2,
  Edit2,
  UploadCloud,
  FileText,
  Filter,
  Search,
  Check,
} from 'lucide-react';

export const CompliancePage: React.FC = () => {
  const { selectedCompanyId, showToast } = useApp();
  const [items, setItems] = useState<ComplianceItem[]>([]);
  const [stats, setStats] = useState({
    score: 92,
    completed: 0,
    pending: 0,
    overdue: 0,
    underReview: 0,
    total: 0,
  });
  const [loading, setLoading] = useState(true);
  const [filterCategory, setFilterCategory] = useState('All');
  const [filterStatus, setFilterStatus] = useState('All');

  // Modal state
  const [modalOpen, setModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<ComplianceItem | null>(null);
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<'GST' | 'Direct Tax' | 'TDS/TCS' | 'Transfer Pricing' | 'Corporate Law'>('Direct Tax');
  const [dueDate, setDueDate] = useState('');
  const [priority, setPriority] = useState<'Critical' | 'High' | 'Medium' | 'Low'>('High');
  const [owner, setOwner] = useState('Aditya Sharma');
  const [filingPeriod, setFilingPeriod] = useState('Q3 FY 2026-27');
  const [penaltyRisk, setPenaltyRisk] = useState('');

  // Upload modal state
  const [uploadModalOpen, setUploadModalOpen] = useState(false);
  const [selectedUploadItemId, setSelectedUploadItemId] = useState<string | null>(null);
  const [docName, setDocName] = useState('');

  const loadCompliance = async () => {
    setLoading(true);
    try {
      const data = await api.getComplianceItems(selectedCompanyId);
      setItems(data.items);
      setStats(data.stats);
    } catch (err: any) {
      showToast(err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadCompliance();
  }, [selectedCompanyId]);

  const handleOpenCreate = () => {
    setEditingItem(null);
    setTitle('');
    setCategory('Direct Tax');
    setDueDate('2026-12-15');
    setPriority('High');
    setOwner('Aditya Sharma');
    setFilingPeriod('Q3 FY 2026-27');
    setPenaltyRisk('Section 234C 1% monthly interest on installment shortfall');
    setModalOpen(true);
  };

  const handleOpenEdit = (item: ComplianceItem) => {
    setEditingItem(item);
    setTitle(item.title);
    setCategory(item.category);
    setDueDate(item.dueDate);
    setPriority(item.priority);
    setOwner(item.owner);
    setFilingPeriod(item.filingPeriod);
    setPenaltyRisk(item.penaltyRisk);
    setModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingItem) {
        await api.updateComplianceItem(editingItem.id, {
          title,
          category,
          dueDate,
          priority,
          owner,
          filingPeriod,
          penaltyRisk,
        });
        showToast('Compliance obligation updated.', 'success');
      } else {
        await api.createComplianceItem({
          companyId: selectedCompanyId,
          title,
          category,
          dueDate,
          priority,
          owner,
          filingPeriod,
          penaltyRisk,
          status: 'Pending',
        });
        showToast('New compliance task registered.', 'success');
      }
      setModalOpen(false);
      loadCompliance();
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  const handleMarkComplete = async (id: string) => {
    try {
      await api.markComplianceComplete(id);
      showToast('Marked as Completed.', 'success');
      loadCompliance();
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await api.deleteComplianceItem(id);
      showToast('Compliance obligation deleted.', 'info');
      loadCompliance();
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  const handleAttachDoc = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUploadItemId || !docName.trim()) return;

    try {
      await api.updateComplianceItem(selectedUploadItemId, {
        documentAttached: {
          name: docName,
          size: 245000,
          uploadedAt: new Date().toISOString(),
        },
      });
      showToast(`Document attached to compliance entry.`, 'success');
      setUploadModalOpen(false);
      loadCompliance();
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  const filteredItems = items.filter((item) => {
    if (filterCategory !== 'All' && item.category !== filterCategory) return false;
    if (filterStatus !== 'All' && item.status !== filterStatus) return false;
    return true;
  });

  const getStatusBadge = (status: ComplianceItem['status']) => {
    switch (status) {
      case 'Completed':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-200/60 dark:border-emerald-800">
            <CheckCircle2 className="w-3 h-3 text-emerald-500" />
            Completed
          </span>
        );
      case 'Pending':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300 border border-amber-200/60 dark:border-amber-800">
            <Clock className="w-3 h-3 text-amber-500" />
            Pending
          </span>
        );
      case 'Under Review':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300 border border-blue-200/60 dark:border-blue-800">
            Under Review
          </span>
        );
      case 'Overdue':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300 border border-rose-200/60 dark:border-rose-800">
            <AlertTriangle className="w-3 h-3 text-rose-500" />
            Overdue
          </span>
        );
    }
  };

  const getPriorityBadge = (priority: ComplianceItem['priority']) => {
    switch (priority) {
      case 'Critical':
        return <span className="text-[11px] font-bold text-rose-600 dark:text-rose-400">Critical</span>;
      case 'High':
        return <span className="text-[11px] font-semibold text-amber-600 dark:text-amber-400">High</span>;
      case 'Medium':
        return <span className="text-[11px] font-medium text-blue-600 dark:text-blue-400">Medium</span>;
      case 'Low':
        return <span className="text-[11px] text-slate-500">Low</span>;
    }
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 dark:text-white flex items-center gap-2.5">
            <CalendarCheck className="w-7 h-7 text-blue-600" />
            <span>Tax Compliance Center</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Statutory calendar monitoring for Advance Tax, GST returns (GSTR-1, 3B), TDS quarterly statements, and transfer pricing.
          </p>
        </div>

        <button
          onClick={handleOpenCreate}
          className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs transition-colors flex items-center gap-2 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Add Compliance Item</span>
        </button>
      </div>

      {/* Top KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs">
          <span className="text-xs font-medium text-slate-500 dark:text-slate-400">Compliance Score</span>
          <div className="text-2xl font-extrabold text-blue-600 dark:text-blue-400 font-mono-numbers mt-1">
            {stats.score}/100
          </div>
          <span className="text-[11px] text-emerald-600 dark:text-emerald-400">Statutory Healthy</span>
        </div>

        <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs">
          <span className="text-xs font-medium text-slate-500 dark:text-slate-400">Completed Filings</span>
          <div className="text-2xl font-extrabold text-emerald-600 dark:text-emerald-400 font-mono-numbers mt-1">
            {stats.completed}
          </div>
          <span className="text-[11px] text-slate-400">ITR & Advance Tax Deposited</span>
        </div>

        <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs">
          <span className="text-xs font-medium text-slate-500 dark:text-slate-400">Pending Filings</span>
          <div className="text-2xl font-extrabold text-amber-500 font-mono-numbers mt-1">
            {stats.pending}
          </div>
          <span className="text-[11px] text-slate-400">Approaching Deadlines</span>
        </div>

        <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs">
          <span className="text-xs font-medium text-slate-500 dark:text-slate-400">Overdue Filings</span>
          <div className="text-2xl font-extrabold text-slate-900 dark:text-slate-100 font-mono-numbers mt-1">
            {stats.overdue}
          </div>
          <span className="text-[11px] text-emerald-600">Zero Statutory Default</span>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs flex flex-wrap items-center justify-between gap-4 text-xs">
        <div className="flex flex-wrap items-center gap-3">
          <span className="font-semibold text-slate-500 dark:text-slate-400">Category:</span>
          {['All', 'Direct Tax', 'GST', 'TDS/TCS', 'Transfer Pricing'].map((cat) => (
            <button
              key={cat}
              onClick={() => setFilterCategory(cat)}
              className={`px-3 py-1.5 rounded-lg font-medium transition-colors cursor-pointer ${
                filterCategory === cat
                  ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300 font-bold'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <span className="font-semibold text-slate-500 dark:text-slate-400">Status:</span>
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-800 dark:text-slate-200 focus:outline-none"
          >
            <option value="All">All Statuses</option>
            <option value="Completed">Completed</option>
            <option value="Pending">Pending</option>
            <option value="Under Review">Under Review</option>
            <option value="Overdue">Overdue</option>
          </select>
        </div>
      </div>

      {/* Compliance Table */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50/75 dark:bg-slate-800/50 text-slate-600 dark:text-slate-400 font-semibold border-b border-slate-200 dark:border-slate-700">
              <tr>
                <th className="py-3 px-4">Compliance Item</th>
                <th className="py-3 px-4">Filing Period</th>
                <th className="py-3 px-4">Due Date</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Priority</th>
                <th className="py-3 px-4">Owner</th>
                <th className="py-3 px-4">Penalty Risk Exposure</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredItems.map((item) => (
                <tr key={item.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors">
                  <td className="py-3 px-4">
                    <div className="font-semibold text-slate-900 dark:text-slate-100">{item.title}</div>
                    <div className="text-[11px] text-slate-400 mt-0.5">Category: {item.category}</div>
                    {item.documentAttached && (
                      <span className="inline-flex items-center gap-1 text-[10px] text-blue-600 dark:text-blue-400 mt-1">
                        <FileText className="w-3 h-3" />
                        {item.documentAttached.name}
                      </span>
                    )}
                  </td>
                  <td className="py-3 px-4 text-slate-600 dark:text-slate-300 font-medium">
                    {item.filingPeriod}
                  </td>
                  <td className="py-3 px-4 font-mono-numbers text-slate-700 dark:text-slate-300 font-semibold">
                    {item.dueDate}
                  </td>
                  <td className="py-3 px-4">{getStatusBadge(item.status)}</td>
                  <td className="py-3 px-4">{getPriorityBadge(item.priority)}</td>
                  <td className="py-3 px-4 text-slate-600 dark:text-slate-300">{item.owner}</td>
                  <td className="py-3 px-4 text-slate-500 text-[11px] max-w-xs leading-relaxed">
                    {item.penaltyRisk}
                  </td>
                  <td className="py-3 px-4 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      {item.status !== 'Completed' && (
                        <button
                          onClick={() => handleMarkComplete(item.id)}
                          className="px-2 py-1 text-[11px] font-semibold text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/60 rounded-lg hover:bg-emerald-100 transition-colors flex items-center gap-1 cursor-pointer"
                          title="Mark Complete"
                        >
                          <Check className="w-3 h-3" />
                          <span>Done</span>
                        </button>
                      )}
                      <button
                        onClick={() => {
                          setSelectedUploadItemId(item.id);
                          setDocName(`${item.title.split(' ')[0]}_Worksheet.pdf`);
                          setUploadModalOpen(true);
                        }}
                        className="p-1.5 text-slate-400 hover:text-blue-600 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                        title="Upload Document"
                      >
                        <UploadCloud className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleOpenEdit(item)}
                        className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                        title="Edit"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDelete(item.id)}
                        className="p-1.5 text-slate-400 hover:text-rose-500 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                        title="Delete"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Compliance Item Modal */}
      <Modal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editingItem ? 'Edit Compliance Obligation' : 'Add Compliance Obligation'}
        subtitle="Manage statutory filing dates and penalty liability"
      >
        <form onSubmit={handleSave} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Filing / Compliance Title
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Advance Tax Q3 Installment (75% Threshold)"
              className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Category
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as any)}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
              >
                <option value="Direct Tax">Direct Tax</option>
                <option value="GST">GST</option>
                <option value="TDS/TCS">TDS/TCS</option>
                <option value="Transfer Pricing">Transfer Pricing</option>
                <option value="Corporate Law">Corporate Law</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Due Date
              </label>
              <input
                type="date"
                required
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Priority
              </label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as any)}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
              >
                <option value="Critical">Critical</option>
                <option value="High">High</option>
                <option value="Medium">Medium</option>
                <option value="Low">Low</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Task Owner / Analyst
              </label>
              <input
                type="text"
                value={owner}
                onChange={(e) => setOwner(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Filing Period / Quarter
            </label>
            <input
              type="text"
              value={filingPeriod}
              onChange={(e) => setFilingPeriod(e.target.value)}
              placeholder="e.g. Q3 FY 2026-27"
              className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Statutory Penalty Exposure
            </label>
            <input
              type="text"
              value={penaltyRisk}
              onChange={(e) => setPenaltyRisk(e.target.value)}
              placeholder="e.g. Section 234C 1% per month interest"
              className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
            />
          </div>

          <div className="pt-4 flex justify-end gap-2 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-400"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs"
            >
              Save Item
            </button>
          </div>
        </form>
      </Modal>

      {/* Document Attachment Modal */}
      <Modal
        isOpen={uploadModalOpen}
        onClose={() => setUploadModalOpen(false)}
        title="Upload Compliance Challan / Worksheet"
        subtitle="Attach statutory verification documentation"
      >
        <form onSubmit={handleAttachDoc} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Document File Name
            </label>
            <input
              type="text"
              required
              value={docName}
              onChange={(e) => setDocName(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
            />
          </div>

          <div className="p-6 border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-2xl text-center">
            <UploadCloud className="w-8 h-8 text-blue-500 mx-auto mb-2" />
            <p className="text-xs text-slate-600 dark:text-slate-300 font-medium">
              Click or drag file to attach
            </p>
            <span className="text-[10px] text-slate-400 block mt-1">PDF, XLSX up to 10MB</span>
          </div>

          <div className="pt-3 flex justify-end gap-2 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={() => setUploadModalOpen(false)}
              className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-400"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs"
            >
              Attach Document
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
