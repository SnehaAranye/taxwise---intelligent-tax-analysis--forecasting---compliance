import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { api } from '../services/api';
import {
  Sparkles,
  TrendingDown,
  TrendingUp,
  ShieldCheck,
  CheckCircle2,
  ArrowRight,
  Info,
  Calendar,
  Layers,
} from 'lucide-react';

export const TaxEfficiencyPage: React.FC = () => {
  const { selectedCompanyId, financialYear, showToast } = useApp();
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  const fmtCr = (val: number) => {
    if (val >= 10000000) return `₹${(val / 10000000).toFixed(2)} Cr`;
    if (val >= 100000) return `₹${(val / 100000).toFixed(2)} L`;
    return `₹${val.toLocaleString('en-IN')}`;
  };

  const loadEfficiency = async () => {
    setLoading(true);
    try {
      const res = await api.getTaxEfficiency(selectedCompanyId);
      setData(res);
    } catch (err: any) {
      showToast(err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadEfficiency();
  }, [selectedCompanyId]);

  const shortTerm = data?.opportunities.filter((o: any) => o.horizon === 'Short-Term') || [];
  const longTerm = data?.opportunities.filter((o: any) => o.horizon === 'Long-Term') || [];

  return (
    <div className="space-y-8 pb-12">
      {/* Header */}
      <div>
        <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 dark:text-white flex items-center gap-2.5">
          <Sparkles className="w-7 h-7 text-blue-600" />
          <span>Tax Efficiency Analysis</span>
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
          Quantitative benchmarking of corporate tax burden, incentive utilization rates, and allowable optimization levers.
        </p>
      </div>

      {/* Primary Efficiency Metrics Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
        <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs">
          <span className="text-xs text-slate-500 dark:text-slate-400">Effective Tax Rate (ETR)</span>
          <div className="text-2xl font-bold text-blue-600 dark:text-blue-400 font-mono-numbers mt-1">
            {data?.effectiveTaxRate || 22.98}%
          </div>
          <span className="text-[11px] text-slate-400">-2.19% vs Statutory 25.17%</span>
        </div>

        <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs">
          <span className="text-xs text-slate-500 dark:text-slate-400">Tax-to-Revenue Ratio</span>
          <div className="text-2xl font-bold text-slate-900 dark:text-slate-100 font-mono-numbers mt-1">
            {data?.taxToRevenueRatio || 8.93}%
          </div>
          <span className="text-[11px] text-slate-400">Statutory Tax / Gross Rev</span>
        </div>

        <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs">
          <span className="text-xs text-slate-500 dark:text-slate-400">Tax-to-Profit Ratio</span>
          <div className="text-2xl font-bold text-slate-900 dark:text-slate-100 font-mono-numbers mt-1">
            {data?.taxToProfitRatio || 22.98}%
          </div>
          <span className="text-[11px] text-slate-400">Tax / Profit Before Tax</span>
        </div>

        <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs">
          <span className="text-xs text-slate-500 dark:text-slate-400">Compliance Cost</span>
          <div className="text-2xl font-bold text-slate-900 dark:text-slate-100 font-mono-numbers mt-1">
            {fmtCr(data?.complianceCost || 850000)}
          </div>
          <span className="text-[11px] text-slate-400">Audits, Counsel & Filing</span>
        </div>

        <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs">
          <span className="text-xs text-slate-500 dark:text-slate-400">Tax Savings Opp.</span>
          <div className="text-2xl font-bold text-emerald-600 dark:text-emerald-400 font-mono-numbers mt-1">
            {fmtCr(data?.taxSavingsOpportunity || 1860000)}
          </div>
          <span className="text-[11px] text-emerald-600">80JJAA & R&D Incentives</span>
        </div>

        <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs">
          <span className="text-xs text-slate-500 dark:text-slate-400">Net Profit After Tax</span>
          <div className="text-2xl font-bold text-slate-900 dark:text-slate-100 font-mono-numbers mt-1">
            {fmtCr(data?.netProfitAfterTax || 37125200)}
          </div>
          <span className="text-[11px] text-slate-400">Retained Earnings FY</span>
        </div>
      </div>

      {/* Comparison: Current Practice vs Improved Practice */}
      <div className="p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-2xs space-y-6">
        <div className="border-b border-slate-100 dark:border-slate-800 pb-3 flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
              Operational Efficiency Benchmark: Current Practice vs. Improved Practice
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Simulated financial impact of claiming statutory employment incentives under Section 80JJAA and IT asset depreciation
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Current Practice */}
          <div className="p-5 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200 dark:border-slate-700/60 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">
                Current Practice
              </span>
              <span className="text-xs px-2 py-0.5 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 rounded font-medium">
                As-Is Baseline
              </span>
            </div>

            <div className="space-y-2 text-xs font-mono-numbers">
              <div className="flex justify-between py-1 border-b border-slate-200 dark:border-slate-700">
                <span className="text-slate-500">Effective Tax Rate:</span>
                <span className="font-bold text-slate-900 dark:text-slate-100">{data?.currentPractice?.effectiveTaxRate}%</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-200 dark:border-slate-700">
                <span className="text-slate-500">Computed Gross Tax:</span>
                <span className="font-bold text-rose-600">{fmtCr(data?.currentPractice?.grossTax || 11074800)}</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-500">Net Profit After Tax (NPAT):</span>
                <span className="font-bold text-slate-900 dark:text-slate-100">{fmtCr(data?.currentPractice?.npat || 37125200)}</span>
              </div>
            </div>

            <p className="text-xs text-slate-500 leading-relaxed">
              Standard tax reporting without optimization on newly hired software engineering payroll or accelerated write-offs.
            </p>
          </div>

          {/* Improved Practice */}
          <div className="p-5 bg-blue-50/60 dark:bg-blue-950/30 rounded-2xl border border-blue-200 dark:border-blue-900/80 space-y-4 ring-2 ring-blue-500/20">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-blue-700 dark:text-blue-300 uppercase tracking-wider">
                Improved Practice (Optimized)
              </span>
              <span className="text-xs px-2 py-0.5 bg-blue-600 text-white rounded font-medium shadow-2xs">
                Recommended Pathway
              </span>
            </div>

            <div className="space-y-2 text-xs font-mono-numbers">
              <div className="flex justify-between py-1 border-b border-blue-200 dark:border-blue-900/60">
                <span className="text-slate-600 dark:text-slate-300">Effective Tax Rate:</span>
                <span className="font-bold text-emerald-600 dark:text-emerald-400">{data?.improvedPractice?.effectiveTaxRate}%</span>
              </div>
              <div className="flex justify-between py-1 border-b border-blue-200 dark:border-blue-900/60">
                <span className="text-slate-600 dark:text-slate-300">Computed Gross Tax:</span>
                <span className="font-bold text-blue-600 dark:text-blue-400">{fmtCr(data?.improvedPractice?.grossTax || 9214800)}</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-600 dark:text-slate-300">Net Profit After Tax (NPAT):</span>
                <span className="font-bold text-emerald-600 dark:text-emerald-400">{fmtCr(data?.improvedPractice?.npat || 38985200)}</span>
              </div>
            </div>

            <p className="text-xs text-blue-900 dark:text-blue-300/80 leading-relaxed font-medium">
              Tax savings of {fmtCr(data?.taxSavingsOpportunity || 1860000)} retained directly on the corporate balance sheet.
            </p>
          </div>
        </div>
      </div>

      {/* Short-Term & Long-Term Opportunities Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Short-Term */}
        <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs space-y-4">
          <div className="border-b border-slate-100 dark:border-slate-800 pb-3 flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <Calendar className="w-4 h-4 text-emerald-600" />
              <span>Short-Term Opportunities (&lt; 6 Months)</span>
            </h3>
            <span className="text-[11px] font-semibold text-emerald-600 bg-emerald-50 dark:bg-emerald-950/60 px-2 py-0.5 rounded-md">
              Immediate Execution
            </span>
          </div>

          <div className="space-y-3">
            {shortTerm.map((opp: any, i: number) => (
              <div
                key={i}
                className="p-3.5 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-100 dark:border-slate-800 space-y-1.5"
              >
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100">{opp.title}</h4>
                  <span className="text-xs font-bold text-emerald-600 font-mono-numbers">
                    +{fmtCr(opp.potentialSavings)}
                  </span>
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                  {opp.description}
                </p>
                <div className="flex items-center gap-3 pt-1 text-[11px] text-slate-400">
                  <span>Feasibility: <strong className="text-slate-700 dark:text-slate-300">{opp.feasibility}</strong></span>
                  <span>·</span>
                  <span>Risk Level: <strong className="text-slate-700 dark:text-slate-300">{opp.riskLevel}</strong></span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Long-Term */}
        <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs space-y-4">
          <div className="border-b border-slate-100 dark:border-slate-800 pb-3 flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <Layers className="w-4 h-4 text-blue-600" />
              <span>Long-Term Opportunities (6–18 Months)</span>
            </h3>
            <span className="text-[11px] font-semibold text-blue-600 bg-blue-50 dark:bg-blue-950/60 px-2 py-0.5 rounded-md">
              Strategic Planning
            </span>
          </div>

          <div className="space-y-3">
            {longTerm.map((opp: any, i: number) => (
              <div
                key={i}
                className="p-3.5 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-100 dark:border-slate-800 space-y-1.5"
              >
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100">{opp.title}</h4>
                  <span className="text-xs font-bold text-blue-600 font-mono-numbers">
                    +{fmtCr(opp.potentialSavings)}
                  </span>
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                  {opp.description}
                </p>
                <div className="flex items-center gap-3 pt-1 text-[11px] text-slate-400">
                  <span>Feasibility: <strong className="text-slate-700 dark:text-slate-300">{opp.feasibility}</strong></span>
                  <span>·</span>
                  <span>Risk Level: <strong className="text-slate-700 dark:text-slate-300">{opp.riskLevel}</strong></span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Compliance Disclaimer */}
      <div className="p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400 flex items-start gap-3">
        <Info className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
        <p className="leading-relaxed">
          {data?.disclaimer ||
            'Results are analytical estimates based on configured statutory assumptions and should not be treated as formal legal or tax counsel.'}
        </p>
      </div>
    </div>
  );
};
