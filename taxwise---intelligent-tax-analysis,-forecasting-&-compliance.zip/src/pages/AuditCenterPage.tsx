import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { api } from '../services/api';
import { AuditDocument } from '../types';
import { Modal } from '../components/common/Modal';
import {
  ClipboardCheck,
  CheckCircle2,
  AlertTriangle,
  UploadCloud,
  FileText,
  FileCheck,
  Edit2,
  FileDown,
  ShieldCheck,
  Info,
} from 'lucide-react';

interface AuditCenterPageProps {
  onNavigate: (page: string) => void;
}

export const AuditCenterPage: React.FC<AuditCenterPageProps> = ({ onNavigate }) => {
  const { selectedCompanyId, showToast } = useApp();
  const [documents, setDocuments] = useState<AuditDocument[]>([]);
  const [readinessScore, setReadinessScore] = useState(87);
  const [stats, setStats] = useState({ total: 9, uploaded: 7, needsReview: 1, missing: 1 });
  const [loading, setLoading] = useState(true);

  // Upload/Edit modal
  const [modalOpen, setModalOpen] = useState(false);
  const [activeDoc, setActiveDoc] = useState<AuditDocument | null>(null);
  const [fileName, setFileName] = useState('');
  const [status, setStatus] = useState<AuditDocument['status']>('Uploaded');
  const [notes, setNotes] = useState('');

  const loadAuditData = async () => {
    setLoading(true);
    try {
      const data = await api.getAuditData(selectedCompanyId);
      setDocuments(data.documents);
      setReadinessScore(data.readinessScore);
      setStats(data.stats);
    } catch (err: any) {
      showToast(err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAuditData();
  }, [selectedCompanyId]);

  const handleOpenUpload = (doc: AuditDocument) => {
    setActiveDoc(doc);
    setFileName(doc.fileName || `${doc.itemType.replace(/\s+/g, '_')}_Evidence.pdf`);
    setStatus(doc.status === 'Missing' ? 'Uploaded' : doc.status);
    setNotes(doc.notes || '');
    setModalOpen(true);
  };

  const handleSaveUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeDoc) return;

    try {
      await api.uploadAuditDoc({
        id: activeDoc.id,
        fileName,
        fileSize: 3400000,
        notes,
      });
      showToast(`Document uploaded for ${activeDoc.itemType}.`, 'success');
      setModalOpen(false);
      loadAuditData();
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  const handleGenerateAuditReport = async () => {
    try {
      await api.createReport({
        companyId: selectedCompanyId,
        reportType: 'Audit Readiness',
        title: 'Statutory Tax Audit Readiness Evaluation Scorecard',
        summary: `Pre-audit readiness scored at ${readinessScore}%. ${stats.uploaded} documents verified, ${stats.needsReview} pending review.`,
        data: {
          readinessScore,
          documents,
          stats,
        },
      });
      showToast('Audit readiness report compiled successfully.', 'success');
      onNavigate('reports');
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 dark:text-white flex items-center gap-2.5">
            <ClipboardCheck className="w-7 h-7 text-blue-600" />
            <span>Tax Audit Preparation</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Pre-audit verification workspace across mandatory statutory evidentiary records under Section 44AB / 92E.
          </p>
        </div>

        <button
          onClick={handleGenerateAuditReport}
          className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs transition-colors flex items-center gap-2 cursor-pointer"
        >
          <FileCheck className="w-4 h-4" />
          <span>Audit Readiness Report</span>
        </button>
      </div>

      {/* Top Readiness Score Card */}
      <div className="p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-2xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6">
          <div className="flex items-center gap-5">
            <div className="relative w-20 h-20 flex items-center justify-center rounded-2xl bg-blue-50 dark:bg-blue-950/60 border border-blue-200/60 dark:border-blue-900/60">
              <span className="text-2xl font-black text-blue-600 dark:text-blue-400 font-mono-numbers">
                {readinessScore}%
              </span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">
                  Overall Audit Readiness
                </h3>
                <span className="text-[11px] font-semibold text-emerald-600 bg-emerald-50 dark:bg-emerald-950/60 px-2 py-0.5 rounded-md">
                  Strong Pre-Audit Position
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-lg leading-relaxed">
                7 of 9 evidentiary record sets verified against statutory IRN, 26AS, and GST portal registries.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4 text-xs font-mono-numbers">
            <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-100 dark:border-slate-800 text-center">
              <span className="text-slate-400 text-[10px] block uppercase font-medium">Uploaded</span>
              <span className="font-bold text-emerald-600 dark:text-emerald-400 text-base">{stats.uploaded}</span>
            </div>
            <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-100 dark:border-slate-800 text-center">
              <span className="text-slate-400 text-[10px] block uppercase font-medium">Needs Review</span>
              <span className="font-bold text-amber-500 text-base">{stats.needsReview}</span>
            </div>
            <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-100 dark:border-slate-800 text-center">
              <span className="text-slate-400 text-[10px] block uppercase font-medium">Missing</span>
              <span className="font-bold text-rose-500 text-base">{stats.missing}</span>
            </div>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="mt-5 pt-4 border-t border-slate-100 dark:border-slate-800">
          <div className="h-2.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden flex">
            <div style={{ width: `${(stats.uploaded / stats.total) * 100}%` }} className="bg-emerald-500" />
            <div style={{ width: `${(stats.needsReview / stats.total) * 100}%` }} className="bg-amber-400" />
            <div style={{ width: `${(stats.missing / stats.total) * 100}%` }} className="bg-rose-400" />
          </div>
        </div>
      </div>

      {/* 9 Standard Audit Checklist Categories */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs overflow-hidden">
        <div className="p-4 border-b border-slate-100 dark:border-slate-800">
          <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
            Mandatory Tax Audit Documentation Checklist (9 Core Categories)
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Cross-indexed with Form 3CD Clauses and Section 44AB statutory audit mandates
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/50 text-slate-600 dark:text-slate-400 font-semibold border-b border-slate-200 dark:border-slate-700">
              <tr>
                <th className="py-3 px-4">Evidentiary Category</th>
                <th className="py-3 px-4">Document Title & Summary</th>
                <th className="py-3 px-4">Compliance Period</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Attached File</th>
                <th className="py-3 px-4">Auditor Notes</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {documents.map((doc) => (
                <tr key={doc.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors">
                  <td className="py-3.5 px-4 font-semibold text-slate-900 dark:text-slate-100">
                    {doc.itemType}
                  </td>
                  <td className="py-3.5 px-4 max-w-xs">
                    <span className="text-slate-800 dark:text-slate-200 font-medium block">{doc.title}</span>
                  </td>
                  <td className="py-3.5 px-4 text-slate-500 font-mono-numbers">
                    {doc.compliancePeriod}
                  </td>
                  <td className="py-3.5 px-4">
                    {doc.status === 'Uploaded' ? (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-200/60 dark:border-emerald-800">
                        <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                        Uploaded
                      </span>
                    ) : doc.status === 'Needs Review' ? (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300 border border-amber-200/60 dark:border-amber-800">
                        <AlertTriangle className="w-3 h-3 text-amber-500" />
                        Needs Review
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300 border border-rose-200/60 dark:border-rose-800">
                        Missing
                      </span>
                    )}
                  </td>
                  <td className="py-3.5 px-4">
                    {doc.fileName ? (
                      <span className="inline-flex items-center gap-1 text-[11px] text-blue-600 dark:text-blue-400 font-medium truncate max-w-[140px]">
                        <FileText className="w-3.5 h-3.5 shrink-0" />
                        <span className="truncate">{doc.fileName}</span>
                      </span>
                    ) : (
                      <span className="text-slate-400 text-[11px]">No file attached</span>
                    )}
                  </td>
                  <td className="py-3.5 px-4 text-slate-500 text-[11px] max-w-xs leading-relaxed">
                    {doc.notes || 'Awaiting preliminary review.'}
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    <button
                      onClick={() => handleOpenUpload(doc)}
                      className="px-2.5 py-1 text-xs font-semibold text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/60 rounded-lg transition-colors cursor-pointer"
                    >
                      {doc.fileName ? 'Replace / Edit' : 'Upload File'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Upload / Edit Modal */}
      <Modal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title={`Audit Evidence: ${activeDoc?.itemType}`}
        subtitle="Upload verifying documentation or adjust status"
      >
        <form onSubmit={handleSaveUpload} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              File Name / Title
            </label>
            <input
              type="text"
              required
              value={fileName}
              onChange={(e) => setFileName(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 focus:outline-none"
            />
          </div>

          <div className="p-6 border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-2xl text-center">
            <UploadCloud className="w-8 h-8 text-blue-500 mx-auto mb-2" />
            <p className="text-xs text-slate-600 dark:text-slate-300 font-medium">
              Click or drag evidentiary dossier here
            </p>
            <span className="text-[10px] text-slate-400 block mt-1">PDF, XLSX, ZIP up to 25MB</span>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Auditor Verification Notes
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Cross-verified with Form 26AS and OLTAS challan receipts"
              className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 focus:outline-none"
            />
          </div>

          <div className="pt-4 flex justify-end gap-2 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-400"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs"
            >
              Save Verification Record
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
