import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { api } from '../services/api';
import { DashboardStats } from '../types';
import {
  RevenueExpensesChart,
  TaxLiabilityTrendChart,
  EffectiveTaxRateChart,
  ForecastComparisonChart,
  TaxDistributionDonut,
  RiskOverviewBarChart,
} from '../components/charts/FinancialCharts';
import {
  TrendingUp,
  Receipt,
  ShieldCheck,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  RefreshCw,
  FileText,
  Calendar,
  Building2,
} from 'lucide-react';

interface DashboardPageProps {
  onNavigate: (page: string) => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({ onNavigate }) => {
  const { selectedCompanyId, financialYear, selectedCompany, user } = useApp();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const loadStats = async () => {
    setLoading(true);
    setError('');
    try {
      const data = await api.getDashboardStats(selectedCompanyId, financialYear);
      setStats(data);
    } catch (err: any) {
      setError(err.message || 'Failed to load dashboard metrics.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadStats();
  }, [selectedCompanyId, financialYear]);

  return (
    <div className="space-y-8 pb-12">
      {/* 1. Header Section */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-semibold px-2.5 py-0.5 bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 rounded-md border border-blue-200/60 dark:border-blue-900/60">
              {selectedCompany?.isDemo ? 'Demo Environment' : 'Production'} · {selectedCompany?.name}
            </span>
            <span className="text-xs text-slate-400">· {financialYear}</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 dark:text-white">
            Good morning, {user?.name ? user.name.split(' ')[0] : 'Financial Analyst'}
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Here's your tax and financial overview for {financialYear}.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={loadStats}
            className="p-2 text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-100 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            title="Refresh Data"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
          <button
            onClick={() => onNavigate('calculator')}
            className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs transition-colors flex items-center gap-2 cursor-pointer"
          >
            <span>New Tax Analysis</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {error && (
        <div className="p-4 bg-rose-50 dark:bg-rose-950/40 text-rose-600 border border-rose-200 dark:border-rose-900 rounded-xl text-xs font-medium">
          {error}
        </div>
      )}

      {/* 2. KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        {/* Revenue */}
        <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs hover:shadow-xs transition-shadow">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 mb-1">
            <span>Revenue</span>
            <span className="text-[11px] font-semibold text-emerald-600 dark:text-emerald-400 font-mono-numbers">
              {stats?.kpi.revenueGrowth || '+8.4%'}
            </span>
          </div>
          <div className="text-xl font-bold text-slate-900 dark:text-slate-100 font-mono-numbers">
            {stats?.kpi.revenueFormatted || '₹12.4 Cr'}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Gross Inflow YTD</div>
        </div>

        {/* Taxable Income */}
        <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs hover:shadow-xs transition-shadow">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 mb-1">
            <span>Taxable Income</span>
            <span className="text-[11px] font-semibold text-emerald-600 dark:text-emerald-400 font-mono-numbers">
              {stats?.kpi.taxableIncomeGrowth || '+5.2%'}
            </span>
          </div>
          <div className="text-xl font-bold text-slate-900 dark:text-slate-100 font-mono-numbers">
            {stats?.kpi.taxableIncomeFormatted || '₹4.82 Cr'}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">PBT less Deductions</div>
        </div>

        {/* Estimated Tax */}
        <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs hover:shadow-xs transition-shadow">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 mb-1">
            <span>Estimated Tax</span>
            <span className="text-[10px] text-blue-600 dark:text-blue-400 font-semibold font-mono-numbers">
              25.17% Base
            </span>
          </div>
          <div className="text-xl font-bold text-blue-600 dark:text-blue-400 font-mono-numbers">
            {stats?.kpi.estimatedTaxFormatted || '₹1.45 Cr'}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Computed FY Liability</div>
        </div>

        {/* Tax Savings Opportunity */}
        <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs hover:shadow-xs transition-shadow">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 mb-1">
            <span>Tax Savings Opp.</span>
            <Sparkles className="w-3.5 h-3.5 text-emerald-500" />
          </div>
          <div className="text-xl font-bold text-emerald-600 dark:text-emerald-400 font-mono-numbers">
            {stats?.kpi.taxSavingsOpportunityFormatted || '₹18.6 L'}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Sec 80JJAA & Depr</div>
        </div>

        {/* Compliance Score */}
        <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs hover:shadow-xs transition-shadow">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 mb-1">
            <span>Compliance Score</span>
            <CheckCircle2 className="w-3.5 h-3.5 text-blue-500" />
          </div>
          <div className="text-xl font-bold text-slate-900 dark:text-slate-100 font-mono-numbers">
            {stats?.kpi.complianceScore ?? 92}/100
          </div>
          <div className="text-[11px] text-slate-400 mt-1">0 Overdue Filings</div>
        </div>

        {/* Risk Score */}
        <div className="p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs hover:shadow-xs transition-shadow">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 mb-1">
            <span>Risk Score</span>
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
          </div>
          <div className="text-xl font-bold text-emerald-600 dark:text-emerald-400 font-mono-numbers">
            {stats?.kpi.riskScore || 'Low'}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">0 Critical Exposure</div>
        </div>
      </div>

      {/* 3. Primary Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Revenue vs Expenses */}
        <div className="lg:col-span-8 p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs">
          <div className="flex items-center justify-between pb-3 mb-2 border-b border-slate-100 dark:border-slate-800">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">Revenue vs Operating Expenses</h3>
              <p className="text-xs text-slate-400">Monthly trajectory and operational margins</p>
            </div>
            <button
              onClick={() => onNavigate('transactions')}
              className="text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1 cursor-pointer"
            >
              <span>View Ledger</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>
          {stats?.charts.revenueVsExpenses && (
            <RevenueExpensesChart data={stats.charts.revenueVsExpenses} />
          )}
        </div>

        {/* Tax Distribution Donut */}
        <div className="lg:col-span-4 p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs flex flex-col justify-between">
          <div className="pb-3 border-b border-slate-100 dark:border-slate-800">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">Tax Liability Distribution</h3>
            <p className="text-xs text-slate-400">Statutory categories breakdown</p>
          </div>
          <div className="py-4">
            {stats?.charts.taxDistribution && (
              <TaxDistributionDonut data={stats.charts.taxDistribution} />
            )}
          </div>
          <div className="pt-3 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-500 dark:text-slate-400 flex items-center justify-between">
            <span>Corporate Income Tax Dominance</span>
            <span className="font-semibold text-slate-800 dark:text-slate-200">68%</span>
          </div>
        </div>
      </div>

      {/* 4. Secondary Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Effective Tax Rate */}
        <div className="lg:col-span-6 p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs">
          <div className="flex items-center justify-between pb-3 mb-2 border-b border-slate-100 dark:border-slate-800">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">Effective Tax Rate (ETR) Trend</h3>
              <p className="text-xs text-slate-400">Actual statutory rate vs 25.17% benchmark</p>
            </div>
            <button
              onClick={() => onNavigate('tax-efficiency')}
              className="text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1 cursor-pointer"
            >
              <span>Efficiency Analysis</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>
          {stats?.charts.effectiveTaxRateTrend && (
            <EffectiveTaxRateChart data={stats.charts.effectiveTaxRateTrend} />
          )}
        </div>

        {/* Tax Forecast */}
        <div className="lg:col-span-6 p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs">
          <div className="flex items-center justify-between pb-3 mb-2 border-b border-slate-100 dark:border-slate-800">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">Historical vs Forecasted Tax Liability</h3>
              <p className="text-xs text-slate-400">OLS linear trend with 95% confidence bounds</p>
            </div>
            <button
              onClick={() => onNavigate('forecasting')}
              className="text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1 cursor-pointer"
            >
              <span>Forecasting Engine</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>
          {stats?.charts.historicalVsForecast && (
            <ForecastComparisonChart data={stats.charts.historicalVsForecast} />
          )}
        </div>
      </div>

      {/* 5. Bottom Row: Monthly Liability Bars & Risk Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Monthly Liability & Advance Tax Paid */}
        <div className="lg:col-span-8 p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs">
          <div className="flex items-center justify-between pb-3 mb-2 border-b border-slate-100 dark:border-slate-800">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">Tax Liability vs Advance Remittance</h3>
              <p className="text-xs text-slate-400">Monthly computed obligation vs Challan 280 deposits</p>
            </div>
            <button
              onClick={() => onNavigate('compliance')}
              className="text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1 cursor-pointer"
            >
              <span>Compliance Center</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>
          {stats?.charts.taxLiabilityTrend && (
            <TaxLiabilityTrendChart data={stats.charts.taxLiabilityTrend} />
          )}
        </div>

        {/* Risk Overview */}
        <div className="lg:col-span-4 p-5 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 shadow-2xs flex flex-col justify-between">
          <div className="pb-3 border-b border-slate-100 dark:border-slate-800">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">Risk Assessment Overview</h3>
            <p className="text-xs text-slate-400">Severities across transfer pricing & GST</p>
          </div>
          <div className="py-4">
            {stats?.charts.riskOverview && (
              <RiskOverviewBarChart data={stats.charts.riskOverview} />
            )}
          </div>
          <div className="pt-3 border-t border-slate-100 dark:border-slate-800">
            <button
              onClick={() => onNavigate('risk-assessment')}
              className="w-full py-2 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white bg-slate-50 dark:bg-slate-800 rounded-xl transition-colors text-center cursor-pointer"
            >
              Inspect Risk Matrix
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
