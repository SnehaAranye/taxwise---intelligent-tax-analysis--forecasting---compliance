import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { api } from '../services/api';
import {
  PieChart,
  BarChart3,
  TrendingUp,
  Building2,
  Calendar,
  Layers,
  ArrowUpRight,
} from 'lucide-react';

export const AnalyticsPage: React.FC = () => {
  const { selectedCompanyId, selectedCompany, companies, financialYear } = useApp();
  const [stats, setStats] = useState<any>(null);

  useEffect(() => {
    api.getDashboardStats(selectedCompanyId, financialYear).then(setStats).catch(console.error);
  }, [selectedCompanyId, financialYear]);

  const fmtCr = (val: number) => {
    if (val >= 10000000) return `₹${(val / 10000000).toFixed(2)} Cr`;
    if (val >= 100000) return `₹${(val / 100000).toFixed(2)} L`;
    return `₹${val.toLocaleString('en-IN')}`;
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Header */}
      <div>
        <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 dark:text-white flex items-center gap-2.5">
          <PieChart className="w-7 h-7 text-blue-600" />
          <span>Cross-Entity Tax Analytics</span>
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
          Comparative macroeconomic analytics across registered corporate entities for {financialYear}.
        </p>
      </div>

      {/* Portfolio Comparison */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {companies.map((c) => {
          const pbt = Math.max(0, c.revenue - c.expenses);
          const estTax = pbt * (c.baseTaxRate / 100);

          return (
            <div
              key={c.id}
              className="p-5 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-2xs space-y-3"
            >
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-slate-900 dark:text-slate-100">{c.name}</span>
                <span className="text-[10px] text-slate-400 font-mono-numbers">{c.pan}</span>
              </div>
              <p className="text-[11px] text-slate-500">{c.industry}</p>

              <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-1 text-xs font-mono-numbers">
                <div className="flex justify-between">
                  <span className="text-slate-400 font-sans">Turnover:</span>
                  <span className="font-semibold">{fmtCr(c.revenue)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400 font-sans">Estimated PBT:</span>
                  <span className="font-semibold text-slate-800 dark:text-slate-200">{fmtCr(pbt)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400 font-sans">Gross Tax Obligation:</span>
                  <span className="font-bold text-blue-600 dark:text-blue-400">{fmtCr(estTax)}</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Macro Analytics Breakdown */}
      <div className="p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-2xs space-y-4">
        <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 border-b border-slate-100 dark:border-slate-800 pb-3">
          Tax Analyst Key Takeaways & Recommendations
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs leading-relaxed">
          <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-100 dark:border-slate-800 space-y-1.5">
            <span className="font-bold text-slate-900 dark:text-slate-100 block">
              1. Advance Tax Schedule Discipline
            </span>
            <p className="text-slate-500 dark:text-slate-400">
              Meeting the 75% threshold by December 15 (Q3) prevents Section 234C 1% monthly compounding interest penalties.
            </p>
          </div>

          <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-100 dark:border-slate-800 space-y-1.5">
            <span className="font-bold text-slate-900 dark:text-slate-100 block">
              2. Section 80JJAA Employee Recruitment Maximization
            </span>
            <p className="text-slate-500 dark:text-slate-400">
              Newly onboarded software engineers qualifying under Section 80JJAA provide a 30% additional tax deduction on their salary for 3 consecutive assessment years.
            </p>
          </div>

          <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-100 dark:border-slate-800 space-y-1.5">
            <span className="font-bold text-slate-900 dark:text-slate-100 block">
              3. GSTR-2B Vendor Invoice Reflection
            </span>
            <p className="text-slate-500 dark:text-slate-400">
              Input Tax Credit should only be claimed where vendors have formally submitted GSTR-1, mitigating Section 16(2)(aa) disallowances.
            </p>
          </div>

          <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-100 dark:border-slate-800 space-y-1.5">
            <span className="font-bold text-slate-900 dark:text-slate-100 block">
              4. Transfer Pricing Documentation Benchmarking
            </span>
            <p className="text-slate-500 dark:text-slate-400">
              Form 3CEB and local file benchmarking should be filed before November 30 to avert the 2% Section 271AA value penalty.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
