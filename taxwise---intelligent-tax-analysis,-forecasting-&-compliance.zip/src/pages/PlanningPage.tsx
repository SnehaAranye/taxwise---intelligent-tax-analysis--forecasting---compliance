import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { api } from '../services/api';
import { TaxScenario } from '../types';
import { Modal } from '../components/common/Modal';
import {
  SlidersHorizontal,
  Plus,
  Copy,
  Trash2,
  Edit2,
  Sparkles,
  ArrowRight,
  TrendingDown,
  Info,
  Check,
} from 'lucide-react';

export const PlanningPage: React.FC = () => {
  const { selectedCompanyId, showToast } = useApp();
  const [scenarios, setScenarios] = useState<TaxScenario[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingScenario, setEditingScenario] = useState<TaxScenario | null>(null);

  // Form state
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [revenue, setRevenue] = useState(100000000);
  const [expenses, setExpenses] = useState(50000000);
  const [depreciation, setDepreciation] = useState(6000000);
  const [deductions, setDeductions] = useState(0);
  const [taxCredits, setTaxCredits] = useState(0);
  const [taxRate, setTaxRate] = useState(25.17);
  const [isOptimized, setIsOptimized] = useState(false);

  const fmt = (val: number) => `₹${val.toLocaleString('en-IN')}`;
  const fmtCr = (val: number) => {
    if (val >= 10000000) return `₹${(val / 10000000).toFixed(2)} Cr`;
    if (val >= 100000) return `₹${(val / 100000).toFixed(2)} L`;
    return `₹${val.toLocaleString('en-IN')}`;
  };

  const loadScenarios = async () => {
    setLoading(true);
    try {
      const data = await api.getTaxScenarios(selectedCompanyId);
      setScenarios(data);
    } catch (err: any) {
      showToast(err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadScenarios();
  }, [selectedCompanyId]);

  const handleOpenCreate = () => {
    setEditingScenario(null);
    setName('Strategic Scenario ' + (scenarios.length + 1));
    setDescription('Optimization through capital write-offs and statutory incentive allocations.');
    setRevenue(100000000);
    setExpenses(54000000);
    setDepreciation(10000000);
    setDeductions(3500000);
    setTaxCredits(500000);
    setTaxRate(25.17);
    setIsOptimized(true);
    setModalOpen(true);
  };

  const handleOpenEdit = (scen: TaxScenario) => {
    setEditingScenario(scen);
    setName(scen.name);
    setDescription(scen.description);
    setRevenue(scen.revenue);
    setExpenses(scen.expenses);
    setDepreciation(scen.depreciation);
    setDeductions(scen.deductions);
    setTaxCredits(scen.taxCredits);
    setTaxRate(scen.taxRate);
    setIsOptimized(scen.isOptimized);
    setModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingScenario) {
        await api.updateTaxScenario(editingScenario.id, {
          name,
          description,
          revenue: Number(revenue),
          expenses: Number(expenses),
          depreciation: Number(depreciation),
          deductions: Number(deductions),
          taxCredits: Number(taxCredits),
          taxRate: Number(taxRate),
          isOptimized,
        });
        showToast('Scenario updated successfully.', 'success');
      } else {
        await api.createTaxScenario({
          companyId: selectedCompanyId,
          name,
          description,
          revenue: Number(revenue),
          expenses: Number(expenses),
          depreciation: Number(depreciation),
          deductions: Number(deductions),
          taxCredits: Number(taxCredits),
          taxRate: Number(taxRate),
          isOptimized,
          assumptions: [
            'Configured under corporate tax Section 115BAA standard schedule',
            'Allowable deductions applied against operating taxable surplus',
          ],
        });
        showToast('New tax strategy scenario created.', 'success');
      }
      setModalOpen(false);
      loadScenarios();
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  const handleDuplicate = async (id: string) => {
    try {
      await api.duplicateTaxScenario(id);
      showToast('Scenario duplicated successfully.', 'success');
      loadScenarios();
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await api.deleteTaxScenario(id);
      showToast('Scenario deleted.', 'info');
      loadScenarios();
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  // Compare baseline vs best optimized
  const baseline = scenarios.find((s) => !s.isOptimized) || scenarios[0];
  const optimizedScenarios = scenarios.filter((s) => s.isOptimized);

  return (
    <div className="space-y-8 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 dark:text-white flex items-center gap-2.5">
            <SlidersHorizontal className="w-7 h-7 text-blue-600" />
            <span>Tax Strategy Simulator</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Model and compare multiple corporate taxation strategies, accelerated depreciation paths, and allowable deductions.
          </p>
        </div>

        <button
          onClick={handleOpenCreate}
          className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs transition-colors flex items-center gap-2 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Create Scenario</span>
        </button>
      </div>

      {/* Analytical Comparison Spotlight */}
      {baseline && optimizedScenarios.length > 0 && (
        <div className="p-6 bg-linear-to-br from-blue-50/70 via-indigo-50/40 to-slate-50 dark:from-slate-900 dark:via-blue-950/20 dark:to-slate-900 rounded-3xl border border-blue-200/80 dark:border-blue-900/60 shadow-xs">
          <div className="flex items-center justify-between pb-4 border-b border-blue-100 dark:border-slate-800">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                Strategy Optimization Difference Analysis
              </h3>
            </div>
            <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 px-2.5 py-0.5 rounded-md">
              Allowable Compliance Optimization
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-5">
            {/* Baseline Strategy */}
            <div className="p-4 bg-white dark:bg-slate-900/80 rounded-2xl border border-slate-200/80 dark:border-slate-800">
              <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                Current Strategy (Baseline)
              </span>
              <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100 mt-1">{baseline.name}</h4>
              <div className="mt-3 space-y-1.5 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-400">Revenue:</span>
                  <span className="font-mono-numbers font-semibold">{fmtCr(baseline.revenue)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Expenses:</span>
                  <span className="font-mono-numbers">{fmtCr(baseline.expenses)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Effective Tax Rate:</span>
                  <span className="font-mono-numbers">{baseline.effectiveTaxRate}%</span>
                </div>
                <div className="flex justify-between pt-2 border-t border-slate-100 dark:border-slate-800 font-bold text-slate-900 dark:text-slate-100">
                  <span>Gross Tax:</span>
                  <span className="font-mono-numbers text-rose-600 dark:text-rose-400">{fmtCr(baseline.estimatedTax)}</span>
                </div>
              </div>
            </div>

            {/* Optimized Strategy */}
            <div className="p-4 bg-white dark:bg-slate-900/80 rounded-2xl border border-blue-200 dark:border-blue-900 ring-2 ring-blue-500/20">
              <span className="text-xs font-semibold text-blue-600 dark:text-blue-400">
                Optimized Strategy
              </span>
              <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100 mt-1">
                {optimizedScenarios[0].name}
              </h4>
              <div className="mt-3 space-y-1.5 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-400">Revenue:</span>
                  <span className="font-mono-numbers font-semibold">{fmtCr(optimizedScenarios[0].revenue)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Allowable Deductions:</span>
                  <span className="font-mono-numbers text-emerald-600">{fmtCr(optimizedScenarios[0].deductions)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Effective Tax Rate:</span>
                  <span className="font-mono-numbers">{optimizedScenarios[0].effectiveTaxRate}%</span>
                </div>
                <div className="flex justify-between pt-2 border-t border-slate-100 dark:border-slate-800 font-bold text-slate-900 dark:text-slate-100">
                  <span>Gross Tax:</span>
                  <span className="font-mono-numbers text-blue-600 dark:text-blue-400">{fmtCr(optimizedScenarios[0].estimatedTax)}</span>
                </div>
              </div>
            </div>

            {/* Difference Result */}
            <div className="p-4 bg-emerald-50/70 dark:bg-emerald-950/30 rounded-2xl border border-emerald-200 dark:border-emerald-900/60 flex flex-col justify-between">
              <div>
                <span className="text-xs font-bold text-emerald-700 dark:text-emerald-400 uppercase tracking-wider">
                  Potential Tax Difference
                </span>
                <div className="text-2xl sm:text-3xl font-extrabold text-emerald-700 dark:text-emerald-300 font-mono-numbers mt-2">
                  {fmtCr(Math.max(0, baseline.estimatedTax - optimizedScenarios[0].estimatedTax))}
                </div>
                <p className="text-xs text-emerald-800 dark:text-emerald-300/80 mt-1 leading-relaxed">
                  Allowable statutory tax savings achievable through Section 80JJAA employment incentive and accelerated write-off.
                </p>
              </div>

              <div className="pt-3 border-t border-emerald-200 dark:border-emerald-900/60 flex items-center justify-between text-xs">
                <span className="font-semibold text-emerald-800 dark:text-emerald-300">
                  ETR Reduction:
                </span>
                <span className="font-mono-numbers font-bold text-emerald-700 dark:text-emerald-300">
                  -{(baseline.effectiveTaxRate - optimizedScenarios[0].effectiveTaxRate).toFixed(2)}%
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Scenarios Grid */}
      <div className="space-y-4">
        <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
          All Configured Tax Scenarios ({scenarios.length})
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {scenarios.map((scen) => (
            <div
              key={scen.id}
              className={`p-5 bg-white dark:bg-slate-900 rounded-2xl border transition-all flex flex-col justify-between ${
                scen.isOptimized
                  ? 'border-blue-300 dark:border-blue-800 shadow-xs'
                  : 'border-slate-200 dark:border-slate-800'
              }`}
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span
                    className={`text-[10px] font-semibold px-2 py-0.5 rounded-md ${
                      scen.isOptimized
                        ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300'
                        : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                    }`}
                  >
                    {scen.isOptimized ? 'Optimized Scenario' : 'Baseline Model'}
                  </span>
                  <span className="text-[11px] font-mono-numbers text-slate-400">
                    ETR: {scen.effectiveTaxRate}%
                  </span>
                </div>

                <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100">{scen.name}</h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                  {scen.description}
                </p>

                <div className="mt-4 p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl space-y-1.5 text-xs font-mono-numbers">
                  <div className="flex justify-between text-slate-600 dark:text-slate-300">
                    <span className="text-slate-400">Revenue:</span>
                    <span>{fmtCr(scen.revenue)}</span>
                  </div>
                  <div className="flex justify-between text-slate-600 dark:text-slate-300">
                    <span className="text-slate-400">Expenses:</span>
                    <span>{fmtCr(scen.expenses)}</span>
                  </div>
                  <div className="flex justify-between text-slate-600 dark:text-slate-300">
                    <span className="text-slate-400">Deductions:</span>
                    <span className="text-emerald-600">{fmtCr(scen.deductions)}</span>
                  </div>
                  <div className="flex justify-between font-bold text-slate-900 dark:text-slate-100 pt-1.5 border-t border-slate-200 dark:border-slate-700">
                    <span>Tax Liability:</span>
                    <span className="text-blue-600 dark:text-blue-400">{fmtCr(scen.estimatedTax)}</span>
                  </div>
                </div>

                {scen.assumptions && scen.assumptions.length > 0 && (
                  <div className="mt-3">
                    <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block mb-1">
                      Assumptions:
                    </span>
                    <ul className="text-[11px] text-slate-500 dark:text-slate-400 space-y-0.5 list-disc list-inside">
                      {scen.assumptions.slice(0, 2).map((a, i) => (
                        <li key={i} className="line-clamp-1">{a}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>

              <div className="mt-5 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => handleOpenEdit(scen)}
                    className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                    title="Edit"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleDuplicate(scen.id)}
                    className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                    title="Duplicate"
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleDelete(scen.id)}
                    className="p-1.5 text-slate-400 hover:text-rose-500 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                    title="Delete"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>

                {scen.taxSavingsVsBaseline > 0 && (
                  <span className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400">
                    +{fmtCr(scen.taxSavingsVsBaseline)} saved
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Mandatory Disclaimer */}
      <div className="p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400 flex items-start gap-3">
        <Info className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
        <p className="leading-relaxed">
          <strong>Mandatory Compliance Notice:</strong> Results are analytical estimates based on configured assumptions and should not be treated as formal legal or tax counsel. All modeling strictly complies with the provisions of the Income Tax Act, 1961 without illegal tax evasion mechanisms.
        </p>
      </div>

      {/* Scenario Create/Edit Modal */}
      <Modal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editingScenario ? 'Edit Strategy Scenario' : 'Create Tax Strategy Scenario'}
        subtitle="Simulate allowable deductions and depreciation write-offs"
      >
        <form onSubmit={handleSave} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Scenario Name
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Strategic Description
            </label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Projected Revenue (₹)
              </label>
              <input
                type="number"
                min="0"
                value={revenue}
                onChange={(e) => setRevenue(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs font-mono-numbers bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Total Expenses (₹)
              </label>
              <input
                type="number"
                min="0"
                value={expenses}
                onChange={(e) => setExpenses(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs font-mono-numbers bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Allowable Deductions (₹)
              </label>
              <input
                type="number"
                min="0"
                value={deductions}
                onChange={(e) => setDeductions(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs font-mono-numbers bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Tax Credits Available (₹)
              </label>
              <input
                type="number"
                min="0"
                value={taxCredits}
                onChange={(e) => setTaxCredits(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs font-mono-numbers bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
              />
            </div>
          </div>

          <div className="flex items-center gap-2 pt-2">
            <input
              type="checkbox"
              id="isOptimizedCheck"
              checked={isOptimized}
              onChange={(e) => setIsOptimized(e.target.checked)}
              className="accent-blue-600 rounded"
            />
            <label htmlFor="isOptimizedCheck" className="text-xs font-semibold text-slate-700 dark:text-slate-300 cursor-pointer">
              Tag as Optimized Strategy (Compares against Baseline)
            </label>
          </div>

          <div className="pt-4 flex justify-end gap-2 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={() => setModalOpen(false)}
              className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs"
            >
              Save Scenario
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
