import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { api } from '../services/api';
import { TaxConfiguration } from '../types';
import {
  Settings,
  User,
  Sliders,
  Shield,
  Bell,
  Sun,
  Moon,
  Save,
  CheckCircle2,
  Calendar,
  Info,
} from 'lucide-react';

export const SettingsPage: React.FC = () => {
  const { user, selectedCompany, darkMode, toggleDarkMode, showToast } = useApp();
  const [activeTab, setActiveTab] = useState<'tax_config' | 'profile' | 'appearance' | 'security'>('tax_config');
  const [taxConfig, setTaxConfig] = useState<TaxConfiguration | null>(null);
  const [loading, setLoading] = useState(true);

  // Editable tax rates
  const [corporateTaxRate, setCorporateTaxRate] = useState<number>(22.0);
  const [surchargeRate, setSurchargeRate] = useState<number>(10.0);
  const [cessRate, setCessRate] = useState<number>(4.0);
  const [matRate, setMatRate] = useState<number>(15.0);

  const loadSettings = async () => {
    setLoading(true);
    try {
      const data = await api.getSettings();
      setTaxConfig(data.taxConfig);
      setCorporateTaxRate(data.taxConfig.corporateTaxRate);
      setSurchargeRate(data.taxConfig.surchargeRate);
      setCessRate(data.taxConfig.cessRate);
      setMatRate(data.taxConfig.matRate);
    } catch (err: any) {
      showToast(err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadSettings();
  }, []);

  const handleSaveTaxConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const updated = await api.updateTaxConfig({
        corporateTaxRate: Number(corporateTaxRate),
        surchargeRate: Number(surchargeRate),
        cessRate: Number(cessRate),
        matRate: Number(matRate),
      });
      setTaxConfig(updated);
      showToast('Configurable tax rules updated successfully.', 'success');
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  // Statutory effective rate computation
  const rateWithSurcharge = corporateTaxRate * (1 + surchargeRate / 100);
  const effectiveRate = rateWithSurcharge * (1 + cessRate / 100);

  return (
    <div className="space-y-8 pb-12">
      {/* Header */}
      <div>
        <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 dark:text-white flex items-center gap-2.5">
          <Settings className="w-7 h-7 text-blue-600" />
          <span>Platform Settings & Tax Configuration</span>
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
          Configure statutory corporate tax multipliers, deduction thresholds, user credentials, and interface preferences.
        </p>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-200 dark:border-slate-800 gap-6 text-xs font-semibold">
        <button
          onClick={() => setActiveTab('tax_config')}
          className={`pb-3 transition-colors cursor-pointer flex items-center gap-2 ${
            activeTab === 'tax_config'
              ? 'text-blue-600 border-b-2 border-blue-600'
              : 'text-slate-500 hover:text-slate-900 dark:hover:text-slate-200'
          }`}
        >
          <Sliders className="w-4 h-4" />
          <span>Statutory Tax Rules</span>
        </button>

        <button
          onClick={() => setActiveTab('profile')}
          className={`pb-3 transition-colors cursor-pointer flex items-center gap-2 ${
            activeTab === 'profile'
              ? 'text-blue-600 border-b-2 border-blue-600'
              : 'text-slate-500 hover:text-slate-900 dark:hover:text-slate-200'
          }`}
        >
          <User className="w-4 h-4" />
          <span>Analyst Profile</span>
        </button>

        <button
          onClick={() => setActiveTab('appearance')}
          className={`pb-3 transition-colors cursor-pointer flex items-center gap-2 ${
            activeTab === 'appearance'
              ? 'text-blue-600 border-b-2 border-blue-600'
              : 'text-slate-500 hover:text-slate-900 dark:hover:text-slate-200'
          }`}
        >
          <Sun className="w-4 h-4" />
          <span>Appearance</span>
        </button>

        <button
          onClick={() => setActiveTab('security')}
          className={`pb-3 transition-colors cursor-pointer flex items-center gap-2 ${
            activeTab === 'security'
              ? 'text-blue-600 border-b-2 border-blue-600'
              : 'text-slate-500 hover:text-slate-900 dark:hover:text-slate-200'
          }`}
        >
          <Shield className="w-4 h-4" />
          <span>Security & Sessions</span>
        </button>
      </div>

      {/* Tab: Tax Configuration */}
      {activeTab === 'tax_config' && (
        <div className="space-y-6 max-w-3xl">
          <form
            onSubmit={handleSaveTaxConfig}
            className="p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-2xs space-y-6"
          >
            <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                  Corporate Income Tax Statutory Schedule
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Parameters applied globally across all company calculators and forecast models
                </p>
              </div>
              <div className="text-right text-[11px] font-mono-numbers text-slate-400">
                <span>Last Updated: </span>
                <span className="font-semibold text-slate-700 dark:text-slate-300">
                  {taxConfig?.lastUpdated || '2026-09-15'}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Section 115BAA Base Corporate Rate (%)
                </label>
                <input
                  type="number"
                  step="0.01"
                  required
                  value={corporateTaxRate}
                  onChange={(e) => setCorporateTaxRate(Number(e.target.value))}
                  className="w-full px-3.5 py-2 text-xs font-mono-numbers bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Statutory Surcharge (%)
                </label>
                <input
                  type="number"
                  step="0.01"
                  required
                  value={surchargeRate}
                  onChange={(e) => setSurchargeRate(Number(e.target.value))}
                  className="w-full px-3.5 py-2 text-xs font-mono-numbers bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Health & Education Cess (%)
                </label>
                <input
                  type="number"
                  step="0.01"
                  required
                  value={cessRate}
                  onChange={(e) => setCessRate(Number(e.target.value))}
                  className="w-full px-3.5 py-2 text-xs font-mono-numbers bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Minimum Alternate Tax (MAT) Rate (%)
                </label>
                <input
                  type="number"
                  step="0.01"
                  required
                  value={matRate}
                  onChange={(e) => setMatRate(Number(e.target.value))}
                  className="w-full px-3.5 py-2 text-xs font-mono-numbers bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
                />
              </div>
            </div>

            {/* Computed Rate Callout */}
            <div className="p-4 bg-blue-50/70 dark:bg-blue-950/30 rounded-2xl border border-blue-200/80 dark:border-blue-900/60 flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-slate-900 dark:text-slate-100 block">
                  Computed Statutory Effective Corporate Tax Rate
                </span>
                <span className="text-[11px] text-slate-500 dark:text-slate-400">
                  Formula: Base × (1 + Surcharge) × (1 + Cess)
                </span>
              </div>
              <span className="text-xl font-extrabold text-blue-700 dark:text-blue-300 font-mono-numbers">
                {effectiveRate.toFixed(3)}%
              </span>
            </div>

            <div className="flex justify-end">
              <button
                type="submit"
                className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs transition-colors flex items-center gap-2 cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>Save Tax Configurations</span>
              </button>
            </div>
          </form>

          {/* Configurable Deduction Rules */}
          <div className="p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-2xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 border-b border-slate-100 dark:border-slate-800 pb-3">
              Standard Allowable Deductions Ruleset
            </h3>

            <div className="space-y-3">
              {taxConfig?.deductionRules.map((rule) => (
                <div
                  key={rule.section}
                  className="p-3.5 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-100 dark:border-slate-800 space-y-1 text-xs"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-900 dark:text-slate-100">
                      {rule.section} · {rule.title}
                    </span>
                    <span className="font-mono-numbers font-semibold text-slate-600 dark:text-slate-400">
                      Cap: ₹{(rule.maxLimit / 100000).toFixed(0)} Lakhs
                    </span>
                  </div>
                  <p className="text-slate-500 leading-relaxed text-[11px]">{rule.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tab: Profile */}
      {activeTab === 'profile' && (
        <div className="p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-2xs max-w-xl space-y-4 text-xs">
          <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 border-b border-slate-100 dark:border-slate-800 pb-3">
            Financial Analyst Information
          </h3>

          <div className="space-y-3">
            <div>
              <span className="text-slate-400 block mb-1">Full Name</span>
              <input
                type="text"
                disabled
                value={user?.name || 'Aditya Sharma'}
                className="w-full px-3 py-2 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
              />
            </div>
            <div>
              <span className="text-slate-400 block mb-1">Email Address</span>
              <input
                type="email"
                disabled
                value={user?.email || 'analyst@taxwise.io'}
                className="w-full px-3 py-2 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
              />
            </div>
            <div>
              <span className="text-slate-400 block mb-1">Assigned Role</span>
              <input
                type="text"
                disabled
                value={user?.role || 'Junior Financial Analyst'}
                className="w-full px-3 py-2 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-slate-100"
              />
            </div>
          </div>
        </div>
      )}

      {/* Tab: Appearance */}
      {activeTab === 'appearance' && (
        <div className="p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-2xs max-w-xl space-y-4 text-xs">
          <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 border-b border-slate-100 dark:border-slate-800 pb-3">
            Theme & Interface Mode
          </h3>

          <div className="flex items-center justify-between p-4 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200 dark:border-slate-700">
            <div>
              <span className="font-bold text-slate-900 dark:text-slate-100 block">
                {darkMode ? 'Dark Mode Active' : 'Light Mode Active'}
              </span>
              <span className="text-slate-500 text-[11px]">
                High-contrast fintech financial styling with tabular numerals
              </span>
            </div>
            <button
              onClick={toggleDarkMode}
              className="px-4 py-2 text-xs font-semibold rounded-xl bg-blue-600 text-white hover:bg-blue-700 transition-colors cursor-pointer"
            >
              Toggle Mode
            </button>
          </div>
        </div>
      )}

      {/* Tab: Security */}
      {activeTab === 'security' && (
        <div className="p-6 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-2xs max-w-xl space-y-4 text-xs">
          <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 border-b border-slate-100 dark:border-slate-800 pb-3">
            Security & Authentication Invariants
          </h3>

          <div className="space-y-3">
            <div className="p-3 bg-emerald-50 dark:bg-emerald-950/30 rounded-xl border border-emerald-200 dark:border-emerald-900/60 text-emerald-800 dark:text-emerald-300">
              <span className="font-bold block">Password Salt & Hash Invariant</span>
              <span className="text-[11px]">All user passwords hashed via Node.js SHA-256 with isolated cryptographic salt. Plain text credentials never stored or exposed.</span>
            </div>
            <div className="p-3 bg-blue-50 dark:bg-blue-950/30 rounded-xl border border-blue-200 dark:border-blue-900/60 text-blue-800 dark:text-blue-300">
              <span className="font-bold block">Multi-Tenant Corporate Data Isolation</span>
              <span className="text-[11px]">Transactions, calculations, and compliance items strictly segregated by active Company ID.</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
